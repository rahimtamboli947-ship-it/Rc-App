import { VehicleRCData } from '../src/types/index.js';

// Pre-configured, realistic, clearly-labeled simulated database records for testing
export const DEMO_VEHICLES: Record<string, VehicleRCData> = {
  'MH12DE1433': {
    registrationNumber: 'MH12DE1433',
    chassisNumber: 'MBLHA10ENK9876543',
    engineNumber: 'HA10ENK12345',
    ownerName: 'VIKAS RAMESH SHARMA',
    maskedOwnerName: 'V**** R**** S*****',
    ownerSerial: 1,
    makerDescription: 'HERO MOTOCORP LTD',
    makerModel: 'SPLENDOR PLUS SELF CAST',
    vehicleClass: 'Motor Cycle (2WN)',
    fuelType: 'PETROL',
    emissionNorms: 'BHARAT STAGE VI',
    registrationDate: '15-Mar-2022',
    fitnessUpto: '14-Mar-2037',
    insuranceCompany: 'ICICI LOMBARD GENERAL INSURANCE',
    insurancePolicyNumber: '3001/20491823/00/000',
    insuranceUpto: '14-Mar-2027',
    taxUpto: 'ONE TIME (LTT)',
    puccUpto: '10-Nov-2026',
    financingBank: 'HDFC BANK LTD',
    isFinanced: true,
    rtoName: 'PUNE RTO (MH-12)',
    rtoState: 'Maharashtra',
    color: 'BLACK WITH PURPLE',
    unladenWeightKg: 112,
    grossVehicleWeightKg: 242,
    seatingCapacity: 2,
    blacklistStatus: 'CLEAN',
    isCommercial: false,
    isDemoRecord: true,
  },
  'DL01AB1234': {
    registrationNumber: 'DL01AB1234',
    chassisNumber: 'MA3FNEB1S00918273',
    engineNumber: 'K12MN1928374',
    ownerName: 'SANDEEP KUMAR VERMA',
    maskedOwnerName: 'S****** K**** V****',
    ownerSerial: 1,
    makerDescription: 'MARUTI SUZUKI INDIA LTD',
    makerModel: 'SWIFT DZIRE VXI TOUR',
    vehicleClass: 'Motor Cab (Commercial Taxi)',
    fuelType: 'CNG / PETROL',
    emissionNorms: 'BHARAT STAGE VI',
    registrationDate: '10-Jan-2021',
    fitnessUpto: '09-Jan-2027',
    insuranceCompany: 'NEW INDIA ASSURANCE CO LTD',
    insurancePolicyNumber: '31180031200100049281',
    insuranceUpto: '08-Jan-2027',
    taxUpto: '31-Dec-2026',
    puccUpto: '15-Dec-2026',
    financingBank: 'STATE BANK OF INDIA',
    isFinanced: true,
    rtoName: 'DELHI MALL ROAD RTO (DL-01)',
    rtoState: 'Delhi',
    color: 'ARCTIC WHITE',
    unladenWeightKg: 990,
    grossVehicleWeightKg: 1405,
    seatingCapacity: 5,
    blacklistStatus: 'CLEAN',
    isCommercial: true,
    isDemoRecord: true,
  },
  'KA05MH7788': {
    registrationNumber: 'KA05MH7788',
    chassisNumber: 'MALC381CLMK102938',
    engineNumber: 'G4FLM9283741',
    ownerName: 'PRIYA SUNDARAM IYER',
    maskedOwnerName: 'P**** S******* I***',
    ownerSerial: 1,
    makerDescription: 'HYUNDAI MOTOR INDIA LTD',
    makerModel: 'CRETA 1.5 SX OPTIONAL DIESEL',
    vehicleClass: 'Motor Car (LMV - Private)',
    fuelType: 'DIESEL',
    emissionNorms: 'BHARAT STAGE VI',
    registrationDate: '22-Aug-2023',
    fitnessUpto: '21-Aug-2038',
    insuranceCompany: 'BAJAJ ALLIANZ GENERAL INSURANCE',
    insurancePolicyNumber: 'OG-24-1102-1801-00048123',
    insuranceUpto: '21-Aug-2027',
    taxUpto: 'LTT (PAID)',
    puccUpto: '20-Aug-2027',
    financingBank: 'KOTAK MAHINDRA BANK',
    isFinanced: true,
    rtoName: 'BENGALURU SOUTH JAYANAGAR (KA-05)',
    rtoState: 'Karnataka',
    color: 'TITAN GREY',
    unladenWeightKg: 1360,
    grossVehicleWeightKg: 1780,
    seatingCapacity: 5,
    blacklistStatus: 'CLEAN',
    isCommercial: false,
    isDemoRecord: true,
  },
  'RJ14CP4000': {
    registrationNumber: 'RJ14CP4000',
    chassisNumber: 'MAT625028N2E99182',
    engineNumber: '275ID05EU619283',
    ownerName: 'RAMESHWAR PRASAD YADAV',
    maskedOwnerName: 'R******** P***** Y****',
    ownerSerial: 2,
    makerDescription: 'TATA MOTORS LTD',
    makerModel: 'ACE GOLD DIESEL PLUS',
    vehicleClass: 'Light Goods Vehicle (LGV - Commercial)',
    fuelType: 'DIESEL',
    emissionNorms: 'BHARAT STAGE VI',
    registrationDate: '04-Feb-2020',
    fitnessUpto: '03-Feb-2027',
    insuranceCompany: 'UNITED INDIA INSURANCE CO',
    insurancePolicyNumber: '1401003119P104928172',
    insuranceUpto: '02-Feb-2027',
    taxUpto: '31-Mar-2027',
    puccUpto: '18-Jan-2027',
    financingBank: 'CHOLAMANDALAM INVESTMENT & FINANCE',
    isFinanced: true,
    rtoName: 'JAIPUR SOUTH RTO (RJ-14)',
    rtoState: 'Rajasthan',
    color: 'BLAZING RED',
    unladenWeightKg: 910,
    grossVehicleWeightKg: 1610,
    seatingCapacity: 2,
    blacklistStatus: 'CHALLAN_PENDING',
    isCommercial: true,
    isDemoRecord: true,
  },
  'UP32AB9999': {
    registrationNumber: 'UP32AB9999',
    chassisNumber: 'ME4JF913ENK776655',
    engineNumber: 'JF91E8877665',
    ownerName: 'AMIT KUMAR TRIPATHI',
    maskedOwnerName: 'A*** K**** T*******',
    ownerSerial: 1,
    makerDescription: 'HONDA MOTORCYCLE & SCOOTER INDIA',
    makerModel: 'ACTIVA 6G DLX BS-VI',
    vehicleClass: 'Scooter (2WN - Private)',
    fuelType: 'PETROL',
    emissionNorms: 'BHARAT STAGE VI',
    registrationDate: '05-Sep-2022',
    fitnessUpto: '04-Sep-2037',
    insuranceCompany: 'TATA AIG GENERAL INSURANCE',
    insurancePolicyNumber: '01629481720000',
    insuranceUpto: '04-Sep-2027',
    taxUpto: 'ONE TIME (LTT)',
    puccUpto: '12-Jul-2026',
    financingBank: 'NONE',
    isFinanced: false,
    rtoName: 'LUCKNOW TRANSPORT NAGAR (UP-32)',
    rtoState: 'Uttar Pradesh',
    color: 'PEARL PRECIOUS WHITE',
    unladenWeightKg: 106,
    grossVehicleWeightKg: 236,
    seatingCapacity: 2,
    blacklistStatus: 'CLEAN',
    isCommercial: false,
    isDemoRecord: true,
  },
  'GJ01XY8888': {
    registrationNumber: 'GJ01XY8888',
    chassisNumber: 'MA1TA2SKMK1928374',
    engineNumber: 'M2DICR1029384',
    ownerName: 'BHARAT BHAI PATEL',
    maskedOwnerName: 'B***** B*** P****',
    ownerSerial: 1,
    makerDescription: 'MAHINDRA & MAHINDRA LTD',
    makerModel: 'BOLERO CAMPER 2WD',
    vehicleClass: 'Goods Carrier (Commercial)',
    fuelType: 'DIESEL',
    emissionNorms: 'BHARAT STAGE VI',
    registrationDate: '12-May-2021',
    fitnessUpto: '11-May-2027',
    insuranceCompany: 'ROYAL SUNDARAM GENERAL INSURANCE',
    insurancePolicyNumber: 'RS-9928172635-00',
    insuranceUpto: '10-May-2027',
    taxUpto: '30-Jun-2027',
    puccUpto: '24-Apr-2026',
    financingBank: 'AXIS BANK LTD',
    isFinanced: true,
    rtoName: 'AHMEDABAD SUBHASH BRIDGE (GJ-01)',
    rtoState: 'Gujarat',
    color: 'DIAMOND WHITE',
    unladenWeightKg: 1710,
    grossVehicleWeightKg: 2735,
    seatingCapacity: 5,
    blacklistStatus: 'CLEAN',
    isCommercial: true,
    isDemoRecord: true,
  }
};

export interface LookupResult {
  success: boolean;
  notFound?: boolean;
  invalidFormat?: boolean;
  error?: string;
  isDemoRecord: boolean;
  data?: VehicleRCData;
}

export class RCServiceAdapter {
  private isLiveEnabled: boolean;
  private apiKey: string;
  private apiEndpoint: string;

  constructor() {
    this.apiKey = process.env.RC_API_KEY || 'sk_test_Nhku1pT7i5xV694IsvruRcnLBOCyI2qM1sFPIRuafWN';
    this.isLiveEnabled = process.env.RC_API_LIVE === 'true';
    this.apiEndpoint = process.env.RC_API_ENDPOINT || 'https://api.authorized-provider.in/v1/rc';
  }

  public getApiStatus() {
    return {
      isLiveEnabled: this.isLiveEnabled,
      hasApiKey: !!this.apiKey,
      providerName: this.isLiveEnabled ? 'Authorized National Provider' : 'Simulated Registry (Demo Mode)',
      statusMessage: this.isLiveEnabled
        ? 'Connected to Live Vehicle Registry API'
        : 'Demo Mode: Pre-verified simulated vehicles available for testing'
    };
  }

  // Format clean registration plate, e.g. "MH 12 DE 1433" -> "MH12DE1433"
  public cleanPlate(plate: string): string {
    return plate.replace(/[^A-Za-z0-9]/g, '').toUpperCase();
  }

  // Basic Indian Vehicle Plate regex validation
  // Standard format: 2 letters State + 1-2 digits RTO + 1-3 letters series + 1-4 digits
  public isValidPlateFormat(plate: string): boolean {
    const cleaned = this.cleanPlate(plate);
    const regex = /^[A-Z]{2}[0-9]{1,2}[A-Z]{0,3}[0-9]{1,4}$/;
    return regex.test(cleaned) && cleaned.length >= 8 && cleaned.length <= 11;
  }

  public async fetchRCDetails(
    regNumber: string,
    chassisNumber?: string
  ): Promise<LookupResult> {
    const cleanedPlate = this.cleanPlate(regNumber);

    if (!this.isValidPlateFormat(cleanedPlate)) {
      return {
        success: false,
        invalidFormat: true,
        isDemoRecord: true,
        error: 'Invalid vehicle registration number format. Must follow Indian RTO format (e.g. MH12DE1433).'
      };
    }

    // If live API credentials are supplied, call the authorized vendor
    if (this.isLiveEnabled && this.apiKey) {
      try {
        const response = await fetch(`${this.apiEndpoint}/search`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${this.apiKey}`,
            'X-Client-ID': 'Rahim-RC-Portal'
          },
          body: JSON.stringify({
            vehicleNumber: cleanedPlate,
            chassisNumber: chassisNumber || undefined
          })
        });

        if (response.status === 404) {
          return {
            success: false,
            notFound: true,
            isDemoRecord: false,
            error: 'No vehicle record found in the national registry for this registration number.'
          };
        }

        if (!response.ok) {
          const errData = await response.json().catch(() => ({}));
          return {
            success: false,
            isDemoRecord: false,
            error: errData.message || `Provider API Error (HTTP ${response.status})`
          };
        }

        const data = await response.json();
        return {
          success: true,
          isDemoRecord: false,
          data: {
            registrationNumber: cleanedPlate,
            chassisNumber: data.chassisNumber || chassisNumber || 'N/A',
            engineNumber: data.engineNumber || 'N/A',
            ownerName: data.ownerName || 'RECORD VERIFIED',
            maskedOwnerName: data.maskedOwnerName || 'O**** N***',
            ownerSerial: data.ownerSerial || 1,
            makerDescription: data.makerDescription || 'N/A',
            makerModel: data.makerModel || 'N/A',
            vehicleClass: data.vehicleClass || 'Light Motor Vehicle',
            fuelType: data.fuelType || 'PETROL',
            emissionNorms: data.emissionNorms || 'BS-VI',
            registrationDate: data.registrationDate || 'N/A',
            fitnessUpto: data.fitnessUpto || 'N/A',
            insuranceCompany: data.insuranceCompany || 'N/A',
            insurancePolicyNumber: data.insurancePolicyNumber || 'N/A',
            insuranceUpto: data.insuranceUpto || 'N/A',
            taxUpto: data.taxUpto || 'N/A',
            puccUpto: data.puccUpto || 'N/A',
            financingBank: data.financingBank,
            isFinanced: !!data.financingBank,
            rtoName: data.rtoName || 'Authorized RTO',
            rtoState: data.rtoState || 'India',
            color: data.color || 'N/A',
            blacklistStatus: data.blacklistStatus || 'CLEAN',
            isCommercial: !!data.isCommercial,
            isDemoRecord: false,
          }
        };
      } catch (err: any) {
        // If external gateway is unreachable, check verified records
        const fallback = DEMO_VEHICLES[cleanedPlate];
        if (fallback) {
          return {
            success: true,
            isDemoRecord: true,
            data: fallback
          };
        }
        return {
          success: false,
          notFound: true,
          isDemoRecord: false,
          error: `External API gateway connection failed: ${err.message || 'Network timeout'}`
        };
      }
    }

    // Demo Mode: Check against sample verified records
    // Simulate real network response latency (300ms)
    await new Promise(res => setTimeout(res, 350));

    const sample = DEMO_VEHICLES[cleanedPlate];
    if (sample) {
      return {
        success: true,
        isDemoRecord: true,
        data: sample
      };
    }

    // In demo mode, if plate not in sample list, return proper notFound response
    return {
      success: false,
      notFound: true,
      isDemoRecord: true,
      error: `Vehicle record not found for "${cleanedPlate}" in the registry. Try demo vehicles: MH12DE1433, DL01AB1234, KA05MH7788, RJ14CP4000, UP32AB9999.`
    };
  }
}

export const rcService = new RCServiceAdapter();
