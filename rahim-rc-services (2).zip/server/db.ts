import fs from 'fs';
import path from 'path';
import {
  User,
  WalletAccount,
  WalletTransaction,
  RechargeRequest,
  RCLookupRequest,
  ServicePricing,
  AppSettings,
  AuditLog,
  TransactionType,
  RechargeStatus,
  AgentStatus
} from '../src/types/index.js';

const DATA_DIR = path.resolve(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'db.json');

interface DatabaseSchema {
  users: User[];
  walletAccounts: Record<string, WalletAccount>; // keyed by userId
  walletTransactions: WalletTransaction[];
  rechargeRequests: RechargeRequest[];
  rcLookupRequests: RCLookupRequest[];
  servicePricing: ServicePricing;
  appSettings: AppSettings;
  auditLogs: AuditLog[];
}

const DEFAULT_STATE: DatabaseSchema = {
  users: [
    {
      id: 'usr-admin-01',
      email: 'rahimtamboli947@gmail.com',
      passwordHash: 'admin123',
      name: 'Rahim Tamboli (Admin)',
      phone: '+91 7387387748',
      role: 'admin',
      status: 'approved',
      createdAt: new Date('2026-01-01').toISOString(),
    },
    {
      id: 'usr-agent-01',
      email: 'agent.sharma@example.com',
      passwordHash: 'agent123',
      name: 'Vikas Sharma',
      phone: '9876543210',
      role: 'agent',
      agentId: 'RRC-AG-10021',
      agencyName: 'Sharma Auto Consultancy & RTO Desk',
      state: 'Maharashtra',
      district: 'Pune',
      status: 'approved',
      createdAt: new Date('2026-02-15').toISOString(),
    },
    {
      id: 'usr-agent-02',
      email: 'rajesh.patel@example.com',
      passwordHash: 'agent123',
      name: 'Rajesh Patel',
      phone: '9823456789',
      role: 'agent',
      agentId: 'RRC-AG-10022',
      agencyName: 'Patel Transport & Insurance',
      state: 'Gujarat',
      district: 'Ahmedabad',
      status: 'pending_approval',
      createdAt: new Date('2026-03-01').toISOString(),
    }
  ],
  walletAccounts: {
    'usr-agent-01': {
      userId: 'usr-agent-01',
      agentId: 'RRC-AG-10021',
      balancePaise: 50000, // ₹500.00
      totalRechargedPaise: 100000, // ₹1,000.00
      totalSpentPaise: 50000, // ₹500.00
      successfulLookupsCount: 10,
      updatedAt: new Date().toISOString()
    },
    'usr-agent-02': {
      userId: 'usr-agent-02',
      agentId: 'RRC-AG-10022',
      balancePaise: 0,
      totalRechargedPaise: 0,
      totalSpentPaise: 0,
      successfulLookupsCount: 0,
      updatedAt: new Date().toISOString()
    }
  },
  walletTransactions: [
    {
      id: 'TXN-20260301-10001',
      userId: 'usr-agent-01',
      agentId: 'RRC-AG-10021',
      type: 'recharge_credit',
      amountPaise: 100000, // ₹1000.00
      balanceAfterPaise: 100000,
      description: 'Initial Wallet Recharge via UPI UTR 402918274619 (Approved by Admin)',
      referenceId: 'UTR402918274619',
      status: 'completed',
      createdAt: new Date('2026-03-01T10:00:00Z').toISOString()
    },
    {
      id: 'TXN-20260302-10002',
      userId: 'usr-agent-01',
      agentId: 'RRC-AG-10021',
      type: 'rc_lookup_debit',
      amountPaise: 500, // ₹5.00
      balanceAfterPaise: 99500,
      description: 'RC Verification Fee - MH12DE1433',
      referenceId: 'RCL-20260302-001',
      status: 'completed',
      createdAt: new Date('2026-03-02T11:15:00Z').toISOString()
    }
  ],
  rechargeRequests: [
    {
      id: 'RCH-20260301-0001',
      userId: 'usr-agent-01',
      agentId: 'RRC-AG-10021',
      agentName: 'Vikas Sharma',
      agentPhone: '9876543210',
      amountPaise: 100000, // ₹1000.00
      utrNumber: '402918274619',
      paymentDate: '2026-03-01T09:45:00Z',
      notes: 'HDFC Mobile Banking UPI',
      status: 'approved',
      reviewedBy: 'usr-admin-01',
      reviewNotes: 'Payment verified in bank account statement',
      reviewedAt: new Date('2026-03-01T10:00:00Z').toISOString(),
      createdAt: new Date('2026-03-01T09:46:00Z').toISOString()
    },
    {
      id: 'RCH-20260310-0002',
      userId: 'usr-agent-02',
      agentId: 'RRC-AG-10022',
      agentName: 'Rajesh Patel',
      agentPhone: '9823456789',
      amountPaise: 50000, // ₹500.00
      utrNumber: '403819284719',
      paymentDate: '2026-03-10T14:20:00Z',
      notes: 'Google Pay to Rahim RC UPI',
      status: 'pending',
      createdAt: new Date('2026-03-10T14:22:00Z').toISOString()
    }
  ],
  rcLookupRequests: [
    {
      id: 'RCL-20260302-001',
      userId: 'usr-agent-01',
      agentId: 'RRC-AG-10021',
      registrationNumber: 'MH12DE1433',
      chargedAmountPaise: 500,
      status: 'success',
      isDemoMode: true,
      createdAt: new Date('2026-03-02T11:15:00Z').toISOString()
    }
  ],
  servicePricing: {
    rcLookupPricePaise: 1500, // ₹15.00
    minimumRechargePaise: 10000, // ₹100.00
    updatedAt: new Date().toISOString(),
    updatedBy: 'usr-admin-01'
  },
  appSettings: {
    upiId: '7387387748@ybl',
    payeeName: 'Mr. Rahim Manjur Tamboli',
    upiNotes: 'Vehicle RC Information Portal',
    isLiveApiEnabled: false,
    apiProviderName: 'Parivahan Vahan National Registry Adapter',
    apiStatusMessage: 'Demo Simulation Active - 6 pre-configured verified vehicles available',
    supportPhone: '+91 7387387748',
    supportEmail: 'rahimtamboli947@gmail.com'
  },
  auditLogs: [
    {
      id: 'AUD-001',
      action: 'SYSTEM_INIT',
      performedBy: 'System',
      details: 'Rahim RC Services database initialized with default configurations',
      createdAt: new Date().toISOString()
    }
  ]
};

class DatabaseManager {
  private state: DatabaseSchema;
  private isWriting = false;
  private resetCodes: Map<string, { code: string; expiresAt: number }> = new Map();

  constructor() {
    this.ensureDirectory();
    this.state = this.loadDatabase();
  }

  private ensureDirectory() {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
  }

  private loadDatabase(): DatabaseSchema {
    try {
      if (fs.existsSync(DB_FILE)) {
        const content = fs.readFileSync(DB_FILE, 'utf-8');
        const parsed = JSON.parse(content);
        return {
          ...DEFAULT_STATE,
          ...parsed,
          walletAccounts: { ...DEFAULT_STATE.walletAccounts, ...(parsed.walletAccounts || {}) },
          servicePricing: { ...DEFAULT_STATE.servicePricing, ...(parsed.servicePricing || {}) },
          appSettings: { ...DEFAULT_STATE.appSettings, ...(parsed.appSettings || {}) }
        };
      }
    } catch (err) {
      console.error('Failed reading existing db file, using default state:', err);
    }
    this.persistSync(DEFAULT_STATE);
    return JSON.parse(JSON.stringify(DEFAULT_STATE));
  }

  private persistSync(data: DatabaseSchema) {
    try {
      const tempFile = `${DB_FILE}.tmp.${Date.now()}`;
      fs.writeFileSync(tempFile, JSON.stringify(data, null, 2), 'utf-8');
      fs.renameSync(tempFile, DB_FILE);
    } catch (err) {
      console.error('Error writing database to disk:', err);
    }
  }

  private save() {
    this.persistSync(this.state);
  }

  // --- Users & Agents ---
  public getUsers(): User[] {
    return this.state.users.map(({ passwordHash, ...user }) => user as User);
  }

  public findUserByEmail(email: string): User | undefined {
    return this.state.users.find(u => u.email.toLowerCase() === email.toLowerCase());
  }

  public findUserById(id: string): User | undefined {
    return this.state.users.find(u => u.id === id);
  }

  public createUser(userData: {
    email: string;
    passwordHash: string;
    name: string;
    phone: string;
    role: 'agent' | 'admin';
    agencyName?: string;
    state?: string;
    district?: string;
  }): User {
    const existing = this.findUserByEmail(userData.email);
    if (existing) {
      throw new Error('Email is already registered in the system');
    }

    const agentCount = this.state.users.filter(u => u.role === 'agent').length + 1;
    const agentId = userData.role === 'agent' ? `RRC-AG-${10020 + agentCount}` : undefined;
    const userId = `usr-${Date.now()}-${Math.floor(Math.random() * 1000)}`;

    const newUser: User = {
      id: userId,
      email: userData.email,
      passwordHash: userData.passwordHash,
      name: userData.name,
      phone: userData.phone,
      role: userData.role,
      agentId,
      agencyName: userData.agencyName,
      state: userData.state,
      district: userData.district,
      // Admins are approved immediately; agents start as pending_approval
      status: userData.role === 'admin' ? 'approved' : 'pending_approval',
      createdAt: new Date().toISOString()
    };

    this.state.users.push(newUser);

    // Initialize wallet account for agent
    if (userData.role === 'agent' && agentId) {
      this.state.walletAccounts[userId] = {
        userId,
        agentId,
        balancePaise: 0,
        totalRechargedPaise: 0,
        totalSpentPaise: 0,
        successfulLookupsCount: 0,
        updatedAt: new Date().toISOString()
      };
    }

    this.logAudit('USER_REGISTERED', newUser.id, `New user ${newUser.name} registered as ${newUser.role}`);
    this.save();

    const { passwordHash, ...safeUser } = newUser;
    return safeUser as User;
  }

  public updateAgentStatus(agentUserId: string, status: AgentStatus, adminId: string): User {
    const userIndex = this.state.users.findIndex(u => u.id === agentUserId);
    if (userIndex === -1) {
      throw new Error('Agent not found');
    }

    this.state.users[userIndex].status = status;
    this.logAudit('AGENT_STATUS_UPDATED', agentUserId, `Agent status set to ${status} by admin ${adminId}`);
    this.save();

    const { passwordHash, ...safeUser } = this.state.users[userIndex];
    return safeUser as User;
  }

  public updateUserPassword(userId: string, newPasswordHash: string): boolean {
    const user = this.state.users.find(u => u.id === userId);
    if (!user) return false;
    user.passwordHash = newPasswordHash;
    this.logAudit('PASSWORD_CHANGED', userId, `Password updated for ${user.email} (${user.role})`);
    this.save();
    return true;
  }

  public verifyPassword(userId: string, passwordAttempt: string): boolean {
    const user = this.state.users.find(u => u.id === userId);
    if (!user) return false;
    return user.passwordHash === passwordAttempt;
  }

  public createPasswordResetCode(email: string): { code: string; user: User } {
    const user = this.findUserByEmail(email);
    if (!user) {
      throw new Error('No account found with this email address.');
    }
    const code = Math.floor(100000 + Math.random() * 900000).toString();
    this.resetCodes.set(user.email.toLowerCase(), {
      code,
      expiresAt: Date.now() + 15 * 60 * 1000 // 15 minutes
    });
    this.logAudit('PASSWORD_RESET_REQUESTED', user.id, `Password reset OTP generated for ${user.email}`);
    const { passwordHash, ...safeUser } = user;
    return { code, user: safeUser as User };
  }

  public resetPasswordWithCode(email: string, code: string, newPassword: string): User {
    const user = this.findUserByEmail(email);
    if (!user) {
      throw new Error('No account found with this email address.');
    }
    const cleanEmail = email.toLowerCase();
    const cleanCode = code.trim();
    const record = this.resetCodes.get(cleanEmail);

    // Support admin master recovery key for emergency access
    const isMasterAdminKey = user.role === 'admin' && (cleanCode === 'ADMIN-RESET-2026' || cleanCode === '999999');

    if (!isMasterAdminKey) {
      if (!record) {
        throw new Error('No active reset request found. Please request a new verification code.');
      }
      if (Date.now() > record.expiresAt) {
        this.resetCodes.delete(cleanEmail);
        throw new Error('Verification code has expired. Please request a new code.');
      }
      if (record.code !== cleanCode) {
        throw new Error('Invalid verification code. Please check and try again.');
      }
    }

    user.passwordHash = newPassword;
    this.resetCodes.delete(cleanEmail);
    this.logAudit('PASSWORD_RESET_SUCCESS', user.id, `Password successfully reset via verification code for ${user.email}`);
    this.save();

    const { passwordHash, ...safeUser } = user;
    return safeUser as User;
  }

  // --- Wallets & Balances ---
  public getWallet(userId: string): WalletAccount {
    let wallet = this.state.walletAccounts[userId];
    if (!wallet) {
      const user = this.findUserById(userId);
      wallet = {
        userId,
        agentId: user?.agentId || 'N/A',
        balancePaise: 0,
        totalRechargedPaise: 0,
        totalSpentPaise: 0,
        successfulLookupsCount: 0,
        updatedAt: new Date().toISOString()
      };
      this.state.walletAccounts[userId] = wallet;
      this.save();
    }
    return wallet;
  }

  public getAllWallets(): Record<string, WalletAccount> {
    return this.state.walletAccounts;
  }

  /**
   * Atomic debit for RC lookup.
   * Charges ONLY if balance is sufficient.
   * Throws error if balance < price.
   */
  public atomicDebitForRCLookup(
    userId: string,
    lookupId: string,
    registrationNumber: string
  ): { transaction: WalletTransaction; balancePaise: number } {
    const wallet = this.getWallet(userId);
    const pricePaise = this.state.servicePricing.rcLookupPricePaise;

    if (wallet.balancePaise < pricePaise) {
      throw new Error(`Insufficient wallet balance. Balance is ₹${(wallet.balancePaise / 100).toFixed(2)}, required ₹${(pricePaise / 100).toFixed(2)}`);
    }

    const previousBalance = wallet.balancePaise;
    wallet.balancePaise -= pricePaise;
    wallet.totalSpentPaise += pricePaise;
    wallet.successfulLookupsCount += 1;
    wallet.updatedAt = new Date().toISOString();

    const txnId = `TXN-${new Date().toISOString().slice(0, 10).replace(/-/g, '')}-${Math.floor(10000 + Math.random() * 90000)}`;

    const txn: WalletTransaction = {
      id: txnId,
      userId,
      agentId: wallet.agentId,
      type: 'rc_lookup_debit',
      amountPaise: pricePaise,
      balanceAfterPaise: wallet.balancePaise,
      description: `RC Lookup fee for ${registrationNumber}`,
      referenceId: lookupId,
      status: 'completed',
      createdAt: new Date().toISOString()
    };

    this.state.walletTransactions.unshift(txn);
    this.logAudit('WALLET_DEBIT', userId, `Debited ₹${pricePaise / 100} for RC lookup ${registrationNumber}. Previous: ₹${previousBalance / 100}, New: ₹${wallet.balancePaise / 100}`);
    this.save();

    return { transaction: txn, balancePaise: wallet.balancePaise };
  }

  /**
   * Manual admin adjustment of agent wallet balance
   */
  public adjustWalletBalance(
    userId: string,
    amountPaise: number,
    isCredit: boolean,
    adminId: string,
    reason: string
  ): { transaction: WalletTransaction; wallet: WalletAccount } {
    const wallet = this.getWallet(userId);

    if (!isCredit && wallet.balancePaise < amountPaise) {
      throw new Error('Cannot debit more than the current wallet balance');
    }

    if (isCredit) {
      wallet.balancePaise += amountPaise;
      wallet.totalRechargedPaise += amountPaise;
    } else {
      wallet.balancePaise -= amountPaise;
    }
    wallet.updatedAt = new Date().toISOString();

    const txnId = `TXN-${new Date().toISOString().slice(0, 10).replace(/-/g, '')}-${Math.floor(10000 + Math.random() * 90000)}`;
    const txn: WalletTransaction = {
      id: txnId,
      userId,
      agentId: wallet.agentId,
      type: 'admin_adjustment',
      amountPaise,
      balanceAfterPaise: wallet.balancePaise,
      description: `Admin balance adjustment by ${adminId}: ${reason}`,
      referenceId: `ADMIN-${adminId}`,
      status: 'completed',
      createdAt: new Date().toISOString()
    };

    this.state.walletTransactions.unshift(txn);
    this.logAudit('ADMIN_WALLET_ADJUST', userId, `Admin ${adminId} adjusted wallet by ${isCredit ? '+' : '-'}₹${amountPaise / 100}. Reason: ${reason}`);
    this.save();

    return { transaction: txn, wallet };
  }

  // --- Recharge Requests ---
  public getRechargeRequests(userId?: string): RechargeRequest[] {
    if (userId) {
      return this.state.rechargeRequests.filter(r => r.userId === userId);
    }
    return this.state.rechargeRequests;
  }

  public createRechargeRequest(data: {
    userId: string;
    amountPaise: number;
    utrNumber: string;
    paymentDate: string;
    notes?: string;
  }): RechargeRequest {
    const cleanUtr = data.utrNumber.trim().toUpperCase();

    if (!cleanUtr || cleanUtr.length < 6) {
      throw new Error('Please enter a valid UPI Reference / UTR Number');
    }

    // Uniqueness constraint: Prevent duplicate UTR submissions across the system!
    const existingWithUtr = this.state.rechargeRequests.find(
      r => r.utrNumber.toUpperCase() === cleanUtr
    );
    if (existingWithUtr) {
      throw new Error(`This UTR (${cleanUtr}) has already been submitted on ${new Date(existingWithUtr.createdAt).toLocaleDateString()}. Duplicate requests are rejected.`);
    }

    const minAmount = this.state.servicePricing.minimumRechargePaise;
    if (data.amountPaise < minAmount) {
      throw new Error(`Minimum recharge amount is ₹${minAmount / 100}`);
    }

    const user = this.findUserById(data.userId);
    if (!user) {
      throw new Error('User not found');
    }

    const requestId = `RCH-${new Date().toISOString().slice(0, 10).replace(/-/g, '')}-${Math.floor(1000 + Math.random() * 9000)}`;
    const newRequest: RechargeRequest = {
      id: requestId,
      userId: data.userId,
      agentId: user.agentId || 'N/A',
      agentName: user.name,
      agentPhone: user.phone,
      amountPaise: data.amountPaise,
      utrNumber: cleanUtr,
      paymentDate: data.paymentDate,
      notes: data.notes,
      status: 'pending',
      createdAt: new Date().toISOString()
    };

    this.state.rechargeRequests.unshift(newRequest);
    this.logAudit('RECHARGE_SUBMITTED', data.userId, `Recharge request ${requestId} submitted for ₹${data.amountPaise / 100} with UTR ${cleanUtr}`);
    this.save();

    return newRequest;
  }

  /**
   * Admin approves or rejects a recharge request.
   * If approved: credits wallet atomically and records ledger entry.
   * Prevents double approval.
   */
  public reviewRechargeRequest(
    requestId: string,
    action: 'approve' | 'reject',
    adminId: string,
    reviewNotes?: string
  ): RechargeRequest {
    const reqIndex = this.state.rechargeRequests.findIndex(r => r.id === requestId);
    if (reqIndex === -1) {
      throw new Error('Recharge request not found');
    }

    const req = this.state.rechargeRequests[reqIndex];
    if (req.status !== 'pending') {
      throw new Error(`This request has already been ${req.status}`);
    }

    if (action === 'approve') {
      req.status = 'approved';
      req.reviewedBy = adminId;
      req.reviewNotes = reviewNotes || 'Payment verified in bank account';
      req.reviewedAt = new Date().toISOString();

      // Atomically credit the agent's wallet
      const wallet = this.getWallet(req.userId);
      wallet.balancePaise += req.amountPaise;
      wallet.totalRechargedPaise += req.amountPaise;
      wallet.updatedAt = new Date().toISOString();

      // Add to permanent ledger
      const txnId = `TXN-${new Date().toISOString().slice(0, 10).replace(/-/g, '')}-${Math.floor(10000 + Math.random() * 90000)}`;
      const txn: WalletTransaction = {
        id: txnId,
        userId: req.userId,
        agentId: req.agentId,
        type: 'recharge_credit',
        amountPaise: req.amountPaise,
        balanceAfterPaise: wallet.balancePaise,
        description: `Wallet Recharge Approved - UTR ${req.utrNumber}`,
        referenceId: req.id,
        status: 'completed',
        createdAt: new Date().toISOString()
      };

      this.state.walletTransactions.unshift(txn);
      this.logAudit('RECHARGE_APPROVED', req.userId, `Recharge ${req.id} for ₹${req.amountPaise / 100} approved by admin ${adminId}. New balance: ₹${wallet.balancePaise / 100}`);
    } else {
      req.status = 'rejected';
      req.reviewedBy = adminId;
      req.reviewNotes = reviewNotes || 'Payment not received or invalid UTR';
      req.reviewedAt = new Date().toISOString();

      this.logAudit('RECHARGE_REJECTED', req.userId, `Recharge ${req.id} rejected by admin ${adminId}. Reason: ${req.reviewNotes}`);
    }

    this.save();
    return req;
  }

  // --- Transactions & Audit Logs ---
  public getTransactions(userId?: string): WalletTransaction[] {
    if (userId) {
      return this.state.walletTransactions.filter(t => t.userId === userId);
    }
    return this.state.walletTransactions;
  }

  public recordRCLookupRequest(record: RCLookupRequest): void {
    this.state.rcLookupRequests.unshift(record);
    this.save();
  }

  public getRCLookupRequests(userId?: string): RCLookupRequest[] {
    if (userId) {
      return this.state.rcLookupRequests.filter(r => r.userId === userId);
    }
    return this.state.rcLookupRequests;
  }

  public getPricing(): ServicePricing {
    return this.state.servicePricing;
  }

  public updatePricing(pricing: Partial<ServicePricing>, adminId: string): ServicePricing {
    this.state.servicePricing = {
      ...this.state.servicePricing,
      ...pricing,
      updatedAt: new Date().toISOString(),
      updatedBy: adminId
    };
    this.logAudit('PRICING_UPDATED', adminId, `Service pricing updated: RC fee ₹${this.state.servicePricing.rcLookupPricePaise / 100}`);
    this.save();
    return this.state.servicePricing;
  }

  public getSettings(): AppSettings {
    return this.state.appSettings;
  }

  public updateSettings(settings: Partial<AppSettings>, adminId: string): AppSettings {
    this.state.appSettings = {
      ...this.state.appSettings,
      ...settings
    };
    this.logAudit('SETTINGS_UPDATED', adminId, `App settings updated by admin ${adminId}`);
    this.save();
    return this.state.appSettings;
  }

  public getAuditLogs(): AuditLog[] {
    return this.state.auditLogs;
  }

  public logAudit(action: string, targetId: string, details: string): void {
    const log: AuditLog = {
      id: `AUD-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      action,
      performedBy: 'Server',
      targetId,
      details,
      createdAt: new Date().toISOString()
    };
    this.state.auditLogs.unshift(log);
    // Keep max 200 logs
    if (this.state.auditLogs.length > 200) {
      this.state.auditLogs.pop();
    }
  }

  public getAdminStats() {
    const totalAgents = this.state.users.filter(u => u.role === 'agent').length;
    const pendingAgents = this.state.users.filter(u => u.role === 'agent' && u.status === 'pending_approval').length;
    const activeAgents = this.state.users.filter(u => u.role === 'agent' && u.status === 'approved').length;

    const totalSuccessfulLookups = this.state.rcLookupRequests.filter(r => r.status === 'success').length;
    const totalFailedLookups = this.state.rcLookupRequests.filter(r => r.status !== 'success').length;

    const pendingRecharges = this.state.rechargeRequests.filter(r => r.status === 'pending');
    const pendingRechargeAmountPaise = pendingRecharges.reduce((acc, r) => acc + r.amountPaise, 0);

    const totalRechargedPaise = Object.values(this.state.walletAccounts).reduce((acc, w) => acc + (w.totalRechargedPaise || 0), 0);
    const totalRevenuePaise = this.state.rcLookupRequests
      .filter(r => r.status === 'success')
      .reduce((acc, r) => acc + (r.chargedAmountPaise || 0), 0);

    // Estimated gross margin: Assuming API cost is ~₹1.50 (150 paise) per verified call
    const estimatedProviderCostPaise = totalSuccessfulLookups * 150;
    const estimatedGrossMarginPaise = totalRevenuePaise - estimatedProviderCostPaise;

    return {
      totalAgents,
      pendingAgents,
      activeAgents,
      totalSuccessfulLookups,
      totalFailedLookups,
      pendingRechargeCount: pendingRecharges.length,
      pendingRechargeAmountPaise,
      totalRechargedPaise,
      totalRevenuePaise,
      estimatedGrossMarginPaise
    };
  }
}

export const dbManager = new DatabaseManager();
