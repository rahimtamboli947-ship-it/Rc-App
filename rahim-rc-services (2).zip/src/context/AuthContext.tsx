import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, WalletAccount, AppSettings, ServicePricing } from '../types/index.js';
import { translations, Language } from '../i18n/translations.js';

interface PublicConfig {
  upiId: string;
  payeeName: string;
  upiNotes: string;
  rcLookupPricePaise: number;
  minimumRechargePaise: number;
  supportPhone: string;
  supportEmail: string;
  isLiveApiEnabled: boolean;
  apiStatus: {
    isLiveEnabled: boolean;
    hasApiKey: boolean;
    providerName: string;
    statusMessage: string;
  };
  demoVehiclesAvailable: string[];
}

interface AuthContextType {
  user: User | null;
  wallet: WalletAccount | null;
  token: string | null;
  language: Language;
  t: typeof translations['en'];
  publicConfig: PublicConfig | null;
  isLoading: boolean;
  setLanguage: (lang: Language) => void;
  toggleLanguage: () => void;
  login: (email: string, password: string) => Promise<void>;
  register: (data: {
    email: string;
    password: string;
    name: string;
    phone: string;
    agencyName?: string;
    state?: string;
    district?: string;
  }) => Promise<void>;
  logout: () => void;
  refreshWallet: () => Promise<void>;
  refreshConfig: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [wallet, setWallet] = useState<WalletAccount | null>(null);
  const [token, setToken] = useState<string | null>(localStorage.getItem('rrc_token'));
  const [language, setLanguageState] = useState<Language>(
    (localStorage.getItem('rrc_lang') as Language) || 'en'
  );
  const [publicConfig, setPublicConfig] = useState<PublicConfig | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  const t = translations[language];

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    localStorage.setItem('rrc_lang', lang);
  };

  const toggleLanguage = () => {
    setLanguage(language === 'en' ? 'hi' : 'en');
  };

  const refreshConfig = async () => {
    try {
      const res = await fetch('/api/config/public');
      if (res.ok) {
        const data = await res.json();
        setPublicConfig(data);
      }
    } catch (err) {
      console.error('Failed to load public configuration', err);
    }
  };

  const refreshWallet = async () => {
    if (!token) return;
    try {
      const res = await fetch('/api/agent/wallet', {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.ok) {
        const data = await res.json();
        setWallet(data.wallet);
      }
    } catch (err) {
      console.error('Failed to refresh wallet', err);
    }
  };

  const fetchCurrentUser = async (authToken: string) => {
    try {
      const res = await fetch('/api/auth/me', {
        headers: { Authorization: `Bearer ${authToken}` }
      });
      if (res.ok) {
        const data = await res.json();
        setUser(data.user);
        setWallet(data.wallet);
      } else {
        localStorage.removeItem('rrc_token');
        setToken(null);
        setUser(null);
      }
    } catch (err) {
      console.error('Failed to restore session', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    refreshConfig();
    if (token) {
      fetchCurrentUser(token);
    } else {
      setIsLoading(false);
    }
  }, []);

  const login = async (email: string, password: string) => {
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    });

    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || 'Login failed');
    }

    setUser(data.user);
    setWallet(data.wallet);
    setToken(data.token);
    localStorage.setItem('rrc_token', data.token);
    localStorage.removeItem('rrc_logged_out');
  };

  const register = async (formData: {
    email: string;
    password: string;
    name: string;
    phone: string;
    agencyName?: string;
    state?: string;
    district?: string;
  }) => {
    const res = await fetch('/api/auth/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(formData)
    });

    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || 'Registration failed');
    }

    setUser(data.user);
    setWallet(data.wallet);
    setToken(data.token);
    localStorage.setItem('rrc_token', data.token);
    localStorage.removeItem('rrc_logged_out');
  };

  const logout = () => {
    setUser(null);
    setWallet(null);
    setToken(null);
    localStorage.removeItem('rrc_token');
    localStorage.setItem('rrc_logged_out', 'true');
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        wallet,
        token,
        language,
        t,
        publicConfig,
        isLoading,
        setLanguage,
        toggleLanguage,
        login,
        register,
        logout,
        refreshWallet,
        refreshConfig
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
