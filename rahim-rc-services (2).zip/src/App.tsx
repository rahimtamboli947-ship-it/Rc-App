import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext.js';
import { Navbar } from './components/Navbar.js';
import { AgentDashboard } from './components/AgentDashboard.js';
import { AdminPanel } from './components/AdminPanel.js';
import { TestRunnerView } from './components/TestRunnerView.js';
import { RCSearchModal } from './components/RCSearchModal.js';
import { WalletRechargeModal } from './components/WalletRechargeModal.js';
import { SetupGuideModal } from './components/SetupGuideModal.js';
import { DownloadAppModal } from './components/DownloadAppModal.js';
import { MobileBottomNav } from './components/MobileBottomNav.js';
import { AdminAccessModal } from './components/AdminAccessModal.js';
import { AgentLogsModal } from './components/AgentLogsModal.js';
import { AgentAuthModal } from './components/AgentAuthModal.js';
import { ChangePasswordModal } from './components/ChangePasswordModal.js';
import { VehicleRCData } from './types/index.js';
import { Shield, Phone, Mail, HelpCircle, Lock, FileText, UserCheck, KeyRound } from 'lucide-react';

function MainApp() {
  const { user, t, publicConfig, isLoading } = useAuth();
  const [currentTab, setCurrentTab] = useState<'dashboard' | 'admin' | 'tests'>('dashboard');

  // Modals for public users
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isRechargeOpen, setIsRechargeOpen] = useState(false);
  const [isSetupGuideOpen, setIsSetupGuideOpen] = useState(false);
  const [isDownloadOpen, setIsDownloadOpen] = useState(false);

  // Dedicated separate modals for Agent Log, Agent Auth, Admin & Change Password
  const [isAgentLogsOpen, setIsAgentLogsOpen] = useState(false);
  const [isAgentAuthOpen, setIsAgentAuthOpen] = useState(false);
  const [isAdminAccessOpen, setIsAdminAccessOpen] = useState(false);
  const [isChangePasswordOpen, setIsChangePasswordOpen] = useState(false);

  // Active selected RC for display if opened from logs
  const [activeRCRecord, setActiveRCRecord] = useState<VehicleRCData | null>(null);

  // Check URL hash for direct routes (#admin, #agent, #logs)
  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash.toLowerCase();
      if (hash === '#admin' || hash === '#staff') {
        if (user?.role === 'admin') {
          setCurrentTab('admin');
        } else {
          setIsAdminAccessOpen(true);
        }
      } else if (hash === '#agent' || hash === '#agent-login' || hash === '#agent-portal') {
        if (user?.role === 'agent') {
          setCurrentTab('dashboard');
        } else {
          setIsAgentAuthOpen(true);
        }
      } else if (hash === '#logs' || hash === '#agent-log' || hash === '#agent-logs') {
        setIsAgentLogsOpen(true);
      } else if (hash === '#change-password' || hash === '#password') {
        if (user) {
          setIsChangePasswordOpen(true);
        } else {
          setIsAgentAuthOpen(true);
        }
      }
    };

    handleHashChange();
    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, [user]);

  const handleSetTab = (tab: string) => {
    if (tab === 'search') {
      setIsSearchOpen(true);
    } else if (tab === 'logs') {
      setIsAgentLogsOpen(true);
    } else if (tab === 'admin' && user?.role !== 'admin') {
      setIsAdminAccessOpen(true);
    } else {
      setCurrentTab(tab as any);
    }
  };

  const handleOpenAdminAccess = () => {
    if (user?.role === 'admin') {
      setCurrentTab('admin');
    } else {
      setIsAdminAccessOpen(true);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-100 flex items-center justify-center p-4">
        <div className="text-center space-y-3">
          <div className="w-12 h-12 rounded-2xl bg-orange-600 flex items-center justify-center text-white mx-auto animate-pulse">
            <Shield className="w-6 h-6" />
          </div>
          <div className="font-extrabold text-slate-800 text-sm">Loading Rahim RC Services...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-100/90 text-slate-900 flex flex-col font-sans selection:bg-orange-500 selection:text-white pb-16 md:pb-0">
      {/* Top Navbar with separate Agent Log & Agent Portal entry points */}
      <Navbar
        currentTab={currentTab}
        setCurrentTab={handleSetTab}
        openSearchModal={() => setIsSearchOpen(true)}
        openSetupGuide={() => setIsSetupGuideOpen(true)}
        openDownloadModal={() => setIsDownloadOpen(true)}
        openAgentLogs={() => setIsAgentLogsOpen(true)}
        openRechargeModal={() => setIsRechargeOpen(true)}
        openChangePassword={() => setIsChangePasswordOpen(true)}
      />

      {/* Main View Area */}
      <main className="flex-1">
        {currentTab === 'dashboard' && (
          <AgentDashboard
            openSearchModal={() => setIsSearchOpen(true)}
            openAgentLogs={() => setIsAgentLogsOpen(true)}
            openChangePassword={() => setIsChangePasswordOpen(true)}
            openRechargeModal={() => setIsRechargeOpen(true)}
            initialRCData={activeRCRecord}
          />
        )}

        {currentTab === 'admin' && user?.role === 'admin' && (
          <AdminPanel openChangePassword={() => setIsChangePasswordOpen(true)} />
        )}

        {currentTab === 'tests' && user?.role === 'admin' && <TestRunnerView />}
      </main>

      {/* Dedicated Separate Agent Log Modal */}
      <AgentLogsModal
        isOpen={isAgentLogsOpen}
        onClose={() => {
          setIsAgentLogsOpen(false);
          if (['#logs', '#agent-log', '#agent-logs'].includes(window.location.hash.toLowerCase())) {
            history.replaceState(null, '', ' ');
          }
        }}
        openAgentLogin={() => setIsAgentAuthOpen(true)}
        onSelectRC={(rc) => {
          setActiveRCRecord(rc);
          setCurrentTab('dashboard');
        }}
      />

      {/* Dedicated Separate Agent Login & Registration Portal */}
      <AgentAuthModal
        isOpen={isAgentAuthOpen}
        onClose={() => {
          setIsAgentAuthOpen(false);
          if (['#agent', '#agent-login', '#agent-portal'].includes(window.location.hash.toLowerCase())) {
            history.replaceState(null, '', ' ');
          }
        }}
        onSuccess={() => {
          setCurrentTab('dashboard');
        }}
      />

      {/* Dedicated Secure Admin Access Modal */}
      <AdminAccessModal
        isOpen={isAdminAccessOpen}
        onClose={() => {
          setIsAdminAccessOpen(false);
          if (['#admin', '#staff'].includes(window.location.hash.toLowerCase())) {
            history.replaceState(null, '', ' ');
          }
        }}
        onSuccess={() => {
          setCurrentTab('admin');
        }}
      />

      {/* Dedicated Separate Change Password Modal */}
      <ChangePasswordModal
        isOpen={isChangePasswordOpen}
        onClose={() => {
          setIsChangePasswordOpen(false);
          if (['#change-password', '#password'].includes(window.location.hash.toLowerCase())) {
            history.replaceState(null, '', ' ');
          }
        }}
      />

      {/* Public Search & Info Modals */}
      <RCSearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        openRechargeModal={() => setIsRechargeOpen(true)}
      />

      <WalletRechargeModal
        isOpen={isRechargeOpen}
        onClose={() => setIsRechargeOpen(false)}
      />

      <SetupGuideModal
        isOpen={isSetupGuideOpen}
        onClose={() => setIsSetupGuideOpen(false)}
      />

      <DownloadAppModal
        isOpen={isDownloadOpen}
        onClose={() => setIsDownloadOpen(false)}
      />

      {/* Mobile Bottom Navigation */}
      <MobileBottomNav
        currentTab={currentTab}
        setCurrentTab={handleSetTab}
        openSearchModal={() => setIsSearchOpen(true)}
        openSetupGuide={() => setIsSetupGuideOpen(true)}
        openDownloadModal={() => setIsDownloadOpen(true)}
        openAgentLogs={() => setIsAgentLogsOpen(true)}
      />

      {/* Footer with separate Agent Log & Portal Links */}
      <footer className="bg-white border-t border-slate-200 mt-12 py-8 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 rounded-lg bg-orange-600 flex items-center justify-center text-white font-black text-xs">
              RC
            </div>
            <div>
              <span className="font-extrabold text-slate-800 text-sm">{t.appName}</span>
              <span className="text-slate-500 block text-[11px]">{t.tagline}</span>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-4 text-xs font-medium">
            <button
              onClick={() => setIsAgentLogsOpen(true)}
              className="text-orange-700 hover:text-orange-900 font-bold flex items-center gap-1.5 cursor-pointer"
            >
              <FileText className="w-3.5 h-3.5 text-orange-600" />
              <span>Agent Log</span>
            </button>
            <span className="text-slate-300">|</span>
            <button
              onClick={() => setIsSetupGuideOpen(true)}
              className="hover:text-orange-600 flex items-center gap-1 cursor-pointer"
            >
              <HelpCircle className="w-3.5 h-3.5" />
              <span>Production Setup Guide</span>
            </button>
            <span className="text-slate-300">|</span>
            <a
              href={`tel:${(publicConfig?.supportPhone || '+91 7387387748').replace(/\s+/g, '')}`}
              className="flex items-center gap-1 hover:text-orange-600 transition"
            >
              <Phone className="w-3.5 h-3.5 text-slate-400" />
              <span>{publicConfig?.supportPhone || '+91 7387387748'}</span>
            </a>
            <span className="text-slate-300">|</span>
            <span className="flex items-center gap-1">
              <Mail className="w-3.5 h-3.5 text-slate-400" />
              <span>{publicConfig?.supportEmail || 'rahimtamboli947@gmail.com'}</span>
            </span>
          </div>

          <div className="flex items-center gap-3 text-[11px] text-slate-400 text-center md:text-right">
            <span>© {new Date().getFullYear()} Rahim RC Services. All Rights Reserved.</span>
            <span>•</span>
            <button
              onClick={handleOpenAdminAccess}
              className="text-slate-400 hover:text-slate-600 transition flex items-center gap-1 cursor-pointer"
              title="Administrative Staff Portal"
            >
              <Lock className="w-3 h-3 text-slate-400" />
              <span>Staff Portal</span>
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <MainApp />
    </AuthProvider>
  );
}
