import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext.js';
import { RCLookupRequest, VehicleRCData } from '../types/index.js';
import {
  FileText,
  Search,
  Calendar,
  CheckCircle2,
  XCircle,
  AlertCircle,
  Download,
  Printer,
  ShieldCheck,
  LogIn,
  Car,
  Clock,
  ExternalLink,
  ChevronRight,
  Filter,
  RefreshCw
} from 'lucide-react';

interface AgentLogsModalProps {
  isOpen: boolean;
  onClose: () => void;
  openAgentLogin?: () => void;
  onSelectRC?: (rc: VehicleRCData) => void;
}

export const AgentLogsModal: React.FC<AgentLogsModalProps> = ({
  isOpen,
  onClose,
  openAgentLogin,
  onSelectRC,
}) => {
  const { user, token, publicConfig } = useAuth();
  const [logs, setLogs] = useState<RCLookupRequest[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'success' | 'not_found' | 'error'>('all');
  const [selectedLog, setSelectedLog] = useState<RCLookupRequest | null>(null);

  // Unauthenticated reference lookup state
  const [refSearchId, setRefSearchId] = useState('');
  const [refSearchResult, setRefSearchResult] = useState<any | null>(null);
  const [refError, setRefError] = useState<string | null>(null);
  const [isSearchingRef, setIsSearchingRef] = useState(false);

  useEffect(() => {
    if (isOpen && token && user) {
      fetchAgentLogs();
    }
  }, [isOpen, token, user]);

  const fetchAgentLogs = async () => {
    if (!token) return;
    setIsLoading(true);
    try {
      const res = await fetch('/api/agent/rc-history', {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.ok) {
        const data = await res.json();
        setLogs(data.history || []);
      }
    } catch (err) {
      console.error('Failed to load agent logs', err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleLookupByRef = async (e: React.FormEvent) => {
    e.preventDefault();
    const query = refSearchId.trim().toUpperCase();
    if (!query) return;

    setIsSearchingRef(true);
    setRefError(null);
    setRefSearchResult(null);

    try {
      const res = await fetch(`/api/public/lookup-receipt/${encodeURIComponent(query)}`);
      const data = await res.json();
      if (!res.ok || !data.success) {
        setRefError(data.error || 'No search record found for this Reference ID or Vehicle Plate.');
      } else {
        setRefSearchResult(data.record);
      }
    } catch (err: any) {
      setRefError(err.message || 'Failed to retrieve search record.');
    } finally {
      setIsSearchingRef(false);
    }
  };

  const handleExportCSV = () => {
    if (filteredLogs.length === 0) return;
    const headers = ['Lookup ID', 'Date & Time', 'Plate Number', 'Status', 'Charged (INR)', 'Owner', 'Maker/Model'];
    const rows = filteredLogs.map(l => [
      l.id,
      new Date(l.createdAt).toLocaleString(),
      l.registrationNumber,
      l.status,
      (l.chargedAmountPaise / 100).toFixed(2),
      l.rcData?.ownerName || 'N/A',
      l.rcData?.makerModel || 'N/A'
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' +
      [headers.join(','), ...rows.map(e => e.map(item => `"${String(item).replace(/"/g, '""')}"`).join(','))].join('\n');

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `Agent_RC_Logs_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  if (!isOpen) return null;

  const filteredLogs = logs.filter(log => {
    const matchesSearch =
      log.registrationNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (log.rcData?.makerModel && log.rcData.makerModel.toLowerCase().includes(searchTerm.toLowerCase()));

    const matchesStatus = statusFilter === 'all' || log.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/70 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-4xl bg-white rounded-3xl shadow-2xl border border-slate-200 flex flex-col max-h-[92vh] overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-orange-950 px-6 py-5 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-orange-600 flex items-center justify-center text-white shadow-md shadow-orange-600/30">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-extrabold text-base text-white">Agent RC Search Logs</h3>
                <span className="bg-orange-500/30 text-orange-300 text-[10px] font-bold px-2 py-0.5 rounded-full border border-orange-500/40 uppercase">
                  Audit History
                </span>
              </div>
              <p className="text-xs text-slate-300">
                Official lookup timestamps, vehicle records, verification status & fee receipts
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {token && (
              <button
                onClick={fetchAgentLogs}
                disabled={isLoading}
                className="p-2 text-slate-300 hover:text-white hover:bg-white/10 rounded-xl transition"
                title="Refresh Logs"
              >
                <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
              </button>
            )}
            <button
              onClick={onClose}
              className="text-slate-400 hover:text-white p-2 rounded-xl hover:bg-white/10 transition text-sm font-bold"
            >
              ✕
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
          {/* If user is an authenticated Agent or Admin: show full personal search logs */}
          {token && user ? (
            <div className="space-y-4">
              {/* Filter and Search Bar */}
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-slate-50 p-3.5 rounded-2xl border border-slate-200">
                <div className="relative flex-1">
                  <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input
                    type="text"
                    value={searchTerm}
                    onChange={e => setSearchTerm(e.target.value)}
                    placeholder="Filter by plate number or ID (e.g. MH12, RCL-2026...)"
                    className="w-full pl-9 pr-3 py-2 bg-white border border-slate-200 rounded-xl text-xs sm:text-sm focus:outline-hidden focus:ring-2 focus:ring-orange-500"
                  />
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <div className="flex items-center gap-1 bg-white border border-slate-200 rounded-xl p-1 text-xs">
                    <Filter className="w-3.5 h-3.5 text-slate-400 ml-1.5" />
                    <select
                      value={statusFilter}
                      onChange={e => setStatusFilter(e.target.value as any)}
                      className="bg-transparent text-xs font-semibold text-slate-700 pr-2 py-1 focus:outline-hidden"
                    >
                      <option value="all">All Statuses</option>
                      <option value="success">Verified (Success)</option>
                      <option value="not_found">Not Found</option>
                      <option value="error">Error</option>
                    </select>
                  </div>

                  <button
                    onClick={handleExportCSV}
                    disabled={filteredLogs.length === 0}
                    className="bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 font-bold px-3 py-2 rounded-xl text-xs transition flex items-center gap-1.5 shadow-xs disabled:opacity-50"
                  >
                    <Download className="w-3.5 h-3.5 text-orange-600" />
                    <span className="hidden sm:inline">Export CSV</span>
                  </button>
                </div>
              </div>

              {/* Stats overview banner */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="bg-slate-50 border border-slate-200 rounded-2xl p-3">
                  <div className="text-[11px] text-slate-500 font-medium">Total Searches</div>
                  <div className="text-lg font-black text-slate-800">{logs.length}</div>
                </div>
                <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-3">
                  <div className="text-[11px] text-emerald-700 font-medium">Verified Records</div>
                  <div className="text-lg font-black text-emerald-800">
                    {logs.filter(l => l.status === 'success').length}
                  </div>
                </div>
                <div className="bg-orange-50 border border-orange-200 rounded-2xl p-3">
                  <div className="text-[11px] text-orange-700 font-medium">Total Deducted</div>
                  <div className="text-lg font-black text-orange-800">
                    ₹{((logs.reduce((acc, l) => acc + (l.chargedAmountPaise || 0), 0)) / 100).toFixed(0)}
                  </div>
                </div>
                <div className="bg-slate-50 border border-slate-200 rounded-2xl p-3">
                  <div className="text-[11px] text-slate-500 font-medium">Agent ID</div>
                  <div className="text-xs font-mono font-bold text-slate-700 truncate">
                    {user.agentId || user.email}
                  </div>
                </div>
              </div>

              {/* Logs Table / List */}
              {isLoading ? (
                <div className="py-12 text-center text-slate-500 space-y-2">
                  <div className="w-8 h-8 border-2 border-orange-500 border-t-transparent rounded-full animate-spin mx-auto" />
                  <div className="text-xs font-medium">Loading RC Search Logs...</div>
                </div>
              ) : filteredLogs.length === 0 ? (
                <div className="py-12 text-center bg-slate-50 rounded-2xl border border-dashed border-slate-300 p-8 space-y-3">
                  <FileText className="w-10 h-10 text-slate-300 mx-auto" />
                  <div className="font-bold text-slate-700 text-sm">No Search Records Found</div>
                  <p className="text-xs text-slate-500 max-w-sm mx-auto">
                    {searchTerm
                      ? `No search records match "${searchTerm}".`
                      : 'You have not conducted any vehicle lookups yet.'}
                  </p>
                </div>
              ) : (
                <div className="border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 uppercase font-bold text-[10px] tracking-wider">
                        <tr>
                          <th className="py-3 px-4">Date & Time</th>
                          <th className="py-3 px-4">Registration No.</th>
                          <th className="py-3 px-4">Maker / Model</th>
                          <th className="py-3 px-4">Status</th>
                          <th className="py-3 px-4">Charge</th>
                          <th className="py-3 px-4 text-right">Action</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {filteredLogs.map(item => (
                          <tr key={item.id} className="hover:bg-orange-50/50 transition">
                            <td className="py-3 px-4 whitespace-nowrap text-slate-600">
                              <div className="font-medium text-slate-900">
                                {new Date(item.createdAt).toLocaleDateString()}
                              </div>
                              <div className="text-[10px] text-slate-400">
                                {new Date(item.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                              </div>
                            </td>
                            <td className="py-3 px-4 whitespace-nowrap">
                              <span className="font-mono font-bold text-slate-900 bg-slate-100 px-2 py-0.5 rounded-md border border-slate-200">
                                {item.registrationNumber}
                              </span>
                              <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                                {item.id}
                              </div>
                            </td>
                            <td className="py-3 px-4 text-slate-700 max-w-[200px] truncate">
                              <div className="font-medium text-slate-800 truncate">
                                {item.rcData?.makerModel || '—'}
                              </div>
                              <div className="text-[10px] text-slate-400 truncate">
                                {item.rcData?.maskedOwnerName || item.rcData?.ownerName || '—'}
                              </div>
                            </td>
                            <td className="py-3 px-4 whitespace-nowrap">
                              {item.status === 'success' ? (
                                <span className="inline-flex items-center gap-1 bg-emerald-50 text-emerald-700 px-2 py-0.5 rounded-full font-bold text-[10px] border border-emerald-200">
                                  <CheckCircle2 className="w-3 h-3" />
                                  Verified
                                </span>
                              ) : item.status === 'not_found' ? (
                                <span className="inline-flex items-center gap-1 bg-amber-50 text-amber-700 px-2 py-0.5 rounded-full font-bold text-[10px] border border-amber-200">
                                  <AlertCircle className="w-3 h-3" />
                                  Not Found
                                </span>
                              ) : (
                                <span className="inline-flex items-center gap-1 bg-rose-50 text-rose-700 px-2 py-0.5 rounded-full font-bold text-[10px] border border-rose-200">
                                  <XCircle className="w-3 h-3" />
                                  Error
                                </span>
                              )}
                            </td>
                            <td className="py-3 px-4 whitespace-nowrap font-bold text-slate-800">
                              {item.chargedAmountPaise > 0 ? (
                                <span className="text-emerald-700">₹{(item.chargedAmountPaise / 100).toFixed(0)}</span>
                              ) : (
                                <span className="text-slate-400">₹0 (Free)</span>
                              )}
                            </td>
                            <td className="py-3 px-4 whitespace-nowrap text-right">
                              {item.rcData ? (
                                <button
                                  onClick={() => {
                                    if (onSelectRC) onSelectRC(item.rcData!);
                                    setSelectedLog(item);
                                  }}
                                  className="text-orange-600 hover:text-orange-800 font-bold hover:underline inline-flex items-center gap-1"
                                >
                                  <span>View Slip</span>
                                  <ChevronRight className="w-3 h-3" />
                                </button>
                              ) : (
                                <span className="text-slate-300">—</span>
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </div>
          ) : (
            /* Unauthenticated Visitor View: Clean option to search log receipt OR log in */
            <div className="space-y-6">
              {/* Explanation Banner */}
              <div className="bg-gradient-to-r from-orange-50 via-amber-50 to-orange-50 border border-orange-200 rounded-2xl p-5 text-slate-800 space-y-2">
                <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-orange-950">
                  <ShieldCheck className="w-4 h-4 text-orange-600" />
                  <span>Official Agent Search Ledger & Receipt Desk</span>
                </div>
                <h4 className="font-extrabold text-base text-slate-900">
                  Access Your Vehicle Lookup History & Verification Receipts
                </h4>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Every vehicle search processed by registered RTO agents is recorded with an official reference code, timestamp, and verification slip. You can look up any past search record below or sign in to your dedicated agent ledger.
                </p>
              </div>

              {/* Public Receipt / Reference Lookup Form */}
              <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-4">
                <div className="space-y-1">
                  <h5 className="font-bold text-sm text-slate-900 flex items-center gap-2">
                    <Search className="w-4 h-4 text-orange-600" />
                    <span>Quick Receipt & Log Lookup</span>
                  </h5>
                  <p className="text-xs text-slate-500">
                    Enter your Lookup Reference ID (e.g. <span className="font-mono font-bold text-slate-700">RCL-20261027-1433</span>) or Vehicle Plate Number:
                  </p>
                </div>

                <form onSubmit={handleLookupByRef} className="flex flex-col sm:flex-row gap-2">
                  <div className="relative flex-1">
                    <input
                      type="text"
                      value={refSearchId}
                      onChange={e => setRefSearchId(e.target.value.toUpperCase())}
                      placeholder="Enter Reference ID or Vehicle Plate (e.g. MH12DE1433)"
                      className="w-full px-4 py-2.5 bg-slate-50 border border-slate-300 rounded-xl font-mono text-xs sm:text-sm uppercase font-bold focus:outline-hidden focus:ring-2 focus:ring-orange-500"
                    />
                  </div>
                  <button
                    type="submit"
                    disabled={isSearchingRef}
                    className="bg-orange-600 hover:bg-orange-700 text-white font-bold px-5 py-2.5 rounded-xl text-xs sm:text-sm transition flex items-center justify-center gap-1.5 shadow-md shadow-orange-600/20 shrink-0 disabled:opacity-75"
                  >
                    <Search className="w-4 h-4" />
                    <span>{isSearchingRef ? 'Searching...' : 'Find Log Record'}</span>
                  </button>
                </form>

                {refError && (
                  <div className="bg-rose-50 border border-rose-200 text-rose-700 px-4 py-2.5 rounded-xl text-xs flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 shrink-0" />
                    <span>{refError}</span>
                  </div>
                )}

                {/* Found Record Result */}
                {refSearchResult && (
                  <div className="mt-4 bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-3">
                    <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                      <div className="flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                        <span className="font-black text-sm text-slate-900 font-mono">
                          {refSearchResult.registrationNumber}
                        </span>
                        <span className="bg-emerald-100 text-emerald-800 text-[10px] font-bold px-2 py-0.5 rounded-full">
                          Verified Record
                        </span>
                      </div>
                      <span className="text-[11px] text-slate-500 font-mono">
                        {refSearchResult.id}
                      </span>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs">
                      <div>
                        <div className="text-[10px] text-slate-400">Maker & Model</div>
                        <div className="font-bold text-slate-800">{refSearchResult.rcData?.makerModel || 'Verified Vehicle'}</div>
                      </div>
                      <div>
                        <div className="text-[10px] text-slate-400">Owner Name</div>
                        <div className="font-bold text-slate-800">{refSearchResult.rcData?.maskedOwnerName || refSearchResult.rcData?.ownerName || 'Verified'}</div>
                      </div>
                      <div>
                        <div className="text-[10px] text-slate-400">RTO Office</div>
                        <div className="font-bold text-slate-800">{refSearchResult.rcData?.rtoName || 'National Register'}</div>
                      </div>
                      <div>
                        <div className="text-[10px] text-slate-400">Insurance Valid</div>
                        <div className="font-bold text-emerald-700">{refSearchResult.rcData?.insuranceUpto || 'Valid'}</div>
                      </div>
                      <div>
                        <div className="text-[10px] text-slate-400">Date Searched</div>
                        <div className="font-medium text-slate-700">{new Date(refSearchResult.createdAt).toLocaleString()}</div>
                      </div>
                      <div>
                        <div className="text-[10px] text-slate-400">Official Fee</div>
                        <div className="font-bold text-slate-800">₹{(refSearchResult.chargedAmountPaise / 100).toFixed(0)} Paid</div>
                      </div>
                    </div>

                    {refSearchResult.rcData && (
                      <div className="pt-2 flex justify-end">
                        <button
                          onClick={() => {
                            if (onSelectRC) onSelectRC(refSearchResult.rcData);
                            onClose();
                          }}
                          className="bg-orange-600 hover:bg-orange-700 text-white font-bold px-4 py-2 rounded-xl text-xs transition flex items-center gap-1.5 shadow-xs"
                        >
                          <Printer className="w-3.5 h-3.5" />
                          <span>View Full Printable Certificate</span>
                        </button>
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Dedicated Agent Portal Sign In card */}
              <div className="bg-slate-900 rounded-2xl p-6 text-white flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div className="space-y-1">
                  <div className="inline-flex items-center gap-1.5 bg-orange-500/20 text-orange-400 px-2.5 py-0.5 rounded-full text-[10px] font-bold border border-orange-500/30">
                    <ShieldCheck className="w-3 h-3" />
                    <span>Agent Login & Registration Portal</span>
                  </div>
                  <h4 className="font-bold text-base text-white">
                    Are you a registered RTO Agent?
                  </h4>
                  <p className="text-xs text-slate-300">
                    Sign in to your authorized agent account to view all past searches, maintain your wallet, and run bulk lookups.
                  </p>
                </div>

                <button
                  onClick={() => {
                    onClose();
                    if (openAgentLogin) openAgentLogin();
                  }}
                  className="bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-600 hover:to-amber-600 text-white font-bold px-5 py-2.5 rounded-xl text-xs transition flex items-center gap-2 shadow-lg shadow-orange-500/30 shrink-0"
                >
                  <LogIn className="w-4 h-4" />
                  <span>Open Agent Login</span>
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="bg-slate-50 border-t border-slate-200 px-6 py-3.5 flex items-center justify-between text-xs text-slate-500">
          <span className="flex items-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
            <span>Parivahan Vahan National Registry Records</span>
          </span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-white border border-slate-300 hover:bg-slate-100 rounded-lg font-bold text-slate-700 transition"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
