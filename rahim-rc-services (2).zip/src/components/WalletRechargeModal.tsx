import React, { useState, useEffect, useRef } from 'react';
import QRCode from 'qrcode';
import { useAuth } from '../context/AuthContext.js';
import { RechargeRequest } from '../types/index.js';
import {
  Wallet,
  X,
  Copy,
  Check,
  QrCode,
  ShieldAlert,
  ArrowRight,
  Clock,
  CheckCircle2,
  XCircle,
  ExternalLink,
  Info
} from 'lucide-react';

interface WalletRechargeModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const WalletRechargeModal: React.FC<WalletRechargeModalProps> = ({
  isOpen,
  onClose
}) => {
  const { user, wallet, token, t, refreshWallet, publicConfig } = useAuth();
  const [selectedAmount, setSelectedAmount] = useState<number>(500);
  const [customAmount, setCustomAmount] = useState<string>('');
  const [utrNumber, setUtrNumber] = useState<string>('');
  const [paymentDate, setPaymentDate] = useState<string>(new Date().toISOString().slice(0, 16));
  const [notes, setNotes] = useState<string>('');
  const [copied, setCopied] = useState<boolean>(false);
  const [qrDataUrl, setQrDataUrl] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [myRecharges, setMyRecharges] = useState<RechargeRequest[]>([]);

  const upiId = publicConfig?.upiId || '7387387748@ybl';
  const payeeName = publicConfig?.payeeName || 'Mr. Rahim Manjur Tamboli';
  const minRechargeRs = (publicConfig?.minimumRechargePaise || 10000) / 100;

  const currentAmountRs = customAmount ? parseFloat(customAmount) || 0 : selectedAmount;

  // Generate UPI string and QR code
  useEffect(() => {
    if (!isOpen) return;

    const amount = currentAmountRs > 0 ? currentAmountRs : minRechargeRs;
    const upiUri = `upi://pay?pa=${encodeURIComponent(upiId)}&pn=${encodeURIComponent(
      payeeName
    )}&am=${amount.toFixed(2)}&cu=INR&tn=${encodeURIComponent('Rahim RC Wallet Recharge')}`;

    QRCode.toDataURL(upiUri, {
      width: 220,
      margin: 1,
      color: {
        dark: '#1e293b',
        light: '#ffffff'
      }
    })
      .then(url => setQrDataUrl(url))
      .catch(err => console.error('QR code generation error:', err));
  }, [isOpen, currentAmountRs, upiId, payeeName, minRechargeRs]);

  // Fetch agent's recharge requests
  const fetchRecharges = async () => {
    if (!token) return;
    try {
      const res = await fetch('/api/agent/recharges', {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.ok) {
        const data = await res.json();
        setMyRecharges(data.recharges || []);
      }
    } catch (err) {
      console.error('Failed to load recharge history', err);
    }
  };

  useEffect(() => {
    if (isOpen) {
      fetchRecharges();
      setError(null);
      setSuccessMessage(null);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleCopyUPI = () => {
    navigator.clipboard.writeText(upiId);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSubmitRecharge = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanUtr = utrNumber.trim().toUpperCase();

    if (!cleanUtr) {
      setError('Please enter the 12-digit UPI Reference / UTR Number');
      return;
    }

    if (currentAmountRs < minRechargeRs) {
      setError(`Minimum recharge amount is ₹${minRechargeRs}`);
      return;
    }

    setIsSubmitting(true);
    setError(null);
    setSuccessMessage(null);

    try {
      const res = await fetch('/api/agent/recharge', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({
          amountPaise: Math.round(currentAmountRs * 100),
          utrNumber: cleanUtr,
          paymentDate: new Date(paymentDate).toISOString(),
          notes
        })
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to submit recharge request');
      }

      setSuccessMessage(data.message || t.rechargeSuccessNotice);
      setUtrNumber('');
      setNotes('');
      await fetchRecharges();
      await refreshWallet();
    } catch (err: any) {
      setError(err.message || 'Error submitting request');
    } finally {
      setIsSubmitting(false);
    }
  };

  const presetAmounts = [100, 200, 500, 1000];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-auto max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="bg-gradient-to-r from-orange-600 via-orange-500 to-amber-600 px-5 py-4 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-white/20 flex items-center justify-center text-white">
              <Wallet className="w-5 h-5 stroke-[2.5]" />
            </div>
            <div>
              <h3 className="font-extrabold text-base sm:text-lg leading-tight">
                {t.rechargeWalletTitle}
              </h3>
              <p className="text-xs text-orange-100 font-medium">
                Instant UPI Payment with 12-Digit UTR Bank Verification
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-white/80 hover:text-white hover:bg-white/20 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-5">
          {/* Messages */}
          {error && (
            <div className="bg-rose-50 border border-rose-200 text-rose-800 p-3.5 rounded-xl text-xs font-medium flex items-start gap-2.5">
              <ShieldAlert className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {successMessage && (
            <div className="bg-emerald-50 border border-emerald-200 text-emerald-900 p-3.5 rounded-xl text-xs font-semibold flex items-start gap-2.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <span>{successMessage}</span>
            </div>
          )}

          {/* Amount Selection */}
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
              {t.selectAmount}
            </label>
            <div className="grid grid-cols-4 gap-2 mb-2">
              {presetAmounts.map(amt => (
                <button
                  key={amt}
                  type="button"
                  onClick={() => {
                    setSelectedAmount(amt);
                    setCustomAmount('');
                  }}
                  className={`py-2 px-3 rounded-xl text-sm font-extrabold border transition ${
                    selectedAmount === amt && !customAmount
                      ? 'bg-orange-600 text-white border-orange-600 shadow-sm'
                      : 'bg-white text-slate-800 border-slate-200 hover:border-orange-400'
                  }`}
                >
                  ₹{amt}
                </button>
              ))}
            </div>

            <div className="relative">
              <input
                type="number"
                placeholder={t.customAmount}
                value={customAmount}
                onChange={e => {
                  setCustomAmount(e.target.value);
                  setSelectedAmount(0);
                }}
                min={minRechargeRs}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-sm text-slate-900 focus:outline-hidden focus:border-orange-500"
              />
            </div>
          </div>

          {/* Step 1: Scan QR or Copy UPI */}
          <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-3">
            <div className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
              <span className="w-5 h-5 rounded-full bg-orange-600 text-white text-[11px] flex items-center justify-center font-bold">
                1
              </span>
              <span>Scan QR Code or Pay via UPI ID</span>
            </div>

            <div className="flex flex-col sm:flex-row items-center gap-5">
              {/* PhonePe Merchant QR Code */}
              <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-sm flex flex-col items-center shrink-0">
                <div className="relative group">
                  <img
                    src="/assets/aistudio/IMG_20261027_092901_770e3a57.png"
                    alt="PhonePe QR Code - Mr. Rahim Manjur Tamboli"
                    className="w-48 h-auto rounded-lg object-contain shadow-xs border border-slate-100"
                  />
                  <div className="absolute top-2 right-2 bg-purple-700 text-white text-[9px] font-bold px-2 py-0.5 rounded-full shadow-xs">
                    PhonePe
                  </div>
                </div>
                <div className="text-[11px] font-extrabold text-slate-900 mt-2 text-center">
                  Mr. Rahim Manjur Tamboli
                </div>
                <div className="text-[10px] font-bold text-orange-600">
                  Amount: ₹{currentAmountRs.toFixed(2)}
                </div>
              </div>

              {/* UPI ID Details */}
              <div className="space-y-2.5 flex-1 w-full text-xs">
                <div>
                  <span className="text-slate-500 text-[11px] font-semibold block">Official UPI ID:</span>
                  <div className="flex items-center gap-2 mt-1">
                    <code className="bg-white px-3 py-1.5 rounded-lg border border-slate-300 text-slate-900 font-mono font-bold text-xs flex-1">
                      {upiId}
                    </code>
                    <button
                      type="button"
                      onClick={handleCopyUPI}
                      className="bg-orange-100 hover:bg-orange-200 text-orange-800 p-2 rounded-lg transition shrink-0"
                      title="Copy UPI ID"
                    >
                      {copied ? <Check className="w-4 h-4 text-green-700" /> : <Copy className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <div>
                  <span className="text-slate-500 text-[11px] font-semibold block">Account Holder:</span>
                  <div className="font-bold text-slate-900 text-xs">{payeeName}</div>
                </div>

                {/* Mobile Deep Link */}
                <a
                  href={`upi://pay?pa=${encodeURIComponent(upiId)}&pn=${encodeURIComponent(
                    payeeName
                  )}&am=${currentAmountRs.toFixed(2)}&cu=INR`}
                  className="sm:hidden inline-flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-700 text-white px-3 py-1.5 rounded-lg font-bold text-xs shadow-xs"
                >
                  <span>Open in UPI App (GPay / PhonePe / Paytm)</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>

                <div className="text-[11px] text-slate-500 leading-tight">
                  Compatible with Google Pay, PhonePe, Paytm, BHIM, CRED, Amazon Pay, and all Indian banking apps.
                </div>
              </div>
            </div>
          </div>

          {/* Step 2: Submit UTR Reference */}
          <form onSubmit={handleSubmitRecharge} className="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-3.5">
            <div className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
              <span className="w-5 h-5 rounded-full bg-orange-600 text-white text-[11px] flex items-center justify-center font-bold">
                2
              </span>
              <span>Submit Payment UTR / Reference Details</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {t.utrLabel} <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={utrNumber}
                  onChange={e => setUtrNumber(e.target.value.toUpperCase())}
                  placeholder={t.utrPlaceholder}
                  className="w-full px-3 py-2 bg-white border border-slate-300 focus:border-orange-500 rounded-xl text-sm font-mono font-bold text-slate-900 focus:outline-hidden"
                />
                <span className="text-[10px] text-slate-500 mt-0.5 block">
                  Find this in your payment receipt (12 digits)
                </span>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Payment Date & Time
                </label>
                <input
                  type="datetime-local"
                  value={paymentDate}
                  onChange={e => setPaymentDate(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-slate-300 focus:border-orange-500 rounded-xl text-xs text-slate-800 focus:outline-hidden"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Bank / App Name / Notes (Optional)
                </label>
                <input
                  type="text"
                  value={notes}
                  onChange={e => setNotes(e.target.value)}
                  placeholder="e.g. Paid via HDFC Mobile Banking or GPay"
                  className="w-full px-3 py-2 bg-white border border-slate-300 focus:border-orange-500 rounded-xl text-xs text-slate-800 focus:outline-hidden"
                />
              </div>
            </div>

            {/* Anti-fraud Notice */}
            <div className="bg-amber-50 border border-amber-200 rounded-xl p-3 text-[11px] text-amber-900 leading-relaxed flex items-start gap-2">
              <ShieldAlert className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold">Strict Accounting Policy: </span>
                {t.rechargeRules}
              </div>
            </div>

            <button
              type="submit"
              disabled={isSubmitting || !utrNumber.trim()}
              className="w-full bg-gradient-to-r from-orange-600 to-orange-500 hover:from-orange-700 hover:to-orange-600 disabled:opacity-50 text-white font-bold py-2.5 px-4 rounded-xl shadow-md shadow-orange-600/20 transition flex items-center justify-center gap-2 text-sm"
            >
              {isSubmitting ? t.submitting : t.submitRecharge}
            </button>
          </form>

          {/* Past Recharge Requests */}
          {myRecharges.length > 0 && (
            <div className="space-y-2">
              <div className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                My Recent Recharge Requests
              </div>
              <div className="divide-y divide-slate-100 border border-slate-200 rounded-xl overflow-hidden bg-white text-xs">
                {myRecharges.slice(0, 5).map(req => (
                  <div key={req.id} className="p-3 flex items-center justify-between gap-3">
                    <div>
                      <div className="font-extrabold text-slate-900">
                        ₹{(req.amountPaise / 100).toFixed(2)}
                      </div>
                      <div className="text-[11px] text-slate-500 font-mono">
                        UTR: {req.utrNumber} • {new Date(req.createdAt).toLocaleDateString()}
                      </div>
                      {req.reviewNotes && (
                        <div className="text-[10px] text-slate-600 italic">
                          Admin note: {req.reviewNotes}
                        </div>
                      )}
                    </div>
                    <div>
                      {req.status === 'approved' && (
                        <span className="inline-flex items-center gap-1 bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full text-[10px] font-bold">
                          <CheckCircle2 className="w-3 h-3" />
                          Approved
                        </span>
                      )}
                      {req.status === 'pending' && (
                        <span className="inline-flex items-center gap-1 bg-amber-100 text-amber-800 px-2 py-0.5 rounded-full text-[10px] font-bold">
                          <Clock className="w-3 h-3" />
                          Pending Review
                        </span>
                      )}
                      {req.status === 'rejected' && (
                        <span className="inline-flex items-center gap-1 bg-rose-100 text-rose-800 px-2 py-0.5 rounded-full text-[10px] font-bold">
                          <XCircle className="w-3 h-3" />
                          Rejected
                        </span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="bg-slate-50 border-t border-slate-200 px-5 py-3 text-right shrink-0">
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-800 rounded-lg text-xs font-bold transition"
          >
            {t.close}
          </button>
        </div>
      </div>
    </div>
  );
};
