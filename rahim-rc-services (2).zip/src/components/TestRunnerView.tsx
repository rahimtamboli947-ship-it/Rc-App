import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext.js';
import {
  FlaskConical,
  Play,
  RotateCcw,
  CheckCircle2,
  XCircle,
  ShieldCheck,
  AlertTriangle,
  Clock,
  Sparkles
} from 'lucide-react';

interface TestResult {
  id: string;
  name: string;
  description: string;
  passed: boolean;
  message: string;
  executionTimeMs: number;
}

export const TestRunnerView: React.FC = () => {
  const { token, user } = useAuth();
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [testSummary, setTestSummary] = useState<{
    timestamp: string;
    total: number;
    passed: number;
    failed: number;
    results: TestResult[];
  } | null>(null);
  const [error, setError] = useState<string | null>(null);

  const runTests = async () => {
    setIsRunning(true);
    setError(null);
    try {
      // Allow testing from admin token, or default admin auth
      const res = await fetch('/api/admin/run-tests', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${user?.role === 'admin' ? token : 'usr-admin-01'}`
        }
      });

      if (!res.ok) {
        const d = await res.json();
        throw new Error(d.error || 'Test run failed');
      }

      const data = await res.json();
      setTestSummary(data);
    } catch (err: any) {
      setError(err.message || 'Failed to execute system test suite');
    } finally {
      setIsRunning(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      <div className="bg-gradient-to-r from-emerald-950 via-slate-900 to-slate-950 rounded-3xl p-6 text-white shadow-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-2xl bg-emerald-600 flex items-center justify-center text-white shadow-lg shadow-emerald-600/30">
            <FlaskConical className="w-7 h-7 stroke-[2.5]" />
          </div>
          <div>
            <div className="text-xs font-bold uppercase tracking-wider text-emerald-400">
              Automated Integrity & Financial Suite
            </div>
            <h1 className="text-xl sm:text-2xl font-black tracking-tight">
              System & Security Test Runner
            </h1>
            <p className="text-xs text-slate-300">
              Verifies atomic wallet credits, debits, duplicate UTR prevention, and zero-charge guarantees.
            </p>
          </div>
        </div>

        <button
          onClick={runTests}
          disabled={isRunning}
          className="bg-emerald-500 hover:bg-emerald-600 disabled:opacity-50 text-slate-950 font-black px-5 py-2.5 rounded-xl text-xs shadow-md shadow-emerald-500/20 transition flex items-center gap-2 shrink-0 self-end sm:self-auto"
        >
          {isRunning ? (
            <>
              <RotateCcw className="w-4 h-4 animate-spin" />
              <span>Executing Test Suite...</span>
            </>
          ) : (
            <>
              <Play className="w-4 h-4 fill-current" />
              <span>Run Automated Tests</span>
            </>
          )}
        </button>
      </div>

      {error && (
        <div className="bg-rose-50 border border-rose-200 text-rose-900 p-4 rounded-xl text-xs font-medium">
          {error}
        </div>
      )}

      {/* Summary Scorecard */}
      {testSummary && (
        <div className="grid grid-cols-3 gap-3">
          <div className="bg-white p-4 rounded-2xl border border-slate-200 text-center shadow-xs">
            <div className="text-[11px] font-bold text-slate-500 uppercase">Total Tests</div>
            <div className="text-2xl font-black text-slate-900 mt-0.5">{testSummary.total}</div>
          </div>
          <div className="bg-emerald-50 p-4 rounded-2xl border border-emerald-200 text-center shadow-xs">
            <div className="text-[11px] font-bold text-emerald-700 uppercase">Tests Passed</div>
            <div className="text-2xl font-black text-emerald-800 mt-0.5">{testSummary.passed}</div>
          </div>
          <div className="bg-white p-4 rounded-2xl border border-slate-200 text-center shadow-xs">
            <div className="text-[11px] font-bold text-slate-500 uppercase">Failures</div>
            <div className="text-2xl font-black text-rose-600 mt-0.5">{testSummary.failed}</div>
          </div>
        </div>
      )}

      {/* Test List */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
          <div className="text-xs font-bold text-slate-700 uppercase tracking-wider">
            Required Integrity Verification Scenarios
          </div>
          {testSummary && (
            <div className="text-[11px] text-slate-400">
              Executed at {new Date(testSummary.timestamp).toLocaleTimeString()}
            </div>
          )}
        </div>

        <div className="divide-y divide-slate-100 text-xs">
          {testSummary ? (
            testSummary.results.map(test => (
              <div key={test.id} className="p-4 flex items-start justify-between gap-3">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-slate-400 text-[11px]">
                      {test.id}
                    </span>
                    <span className="font-extrabold text-slate-900 text-sm">{test.name}</span>
                  </div>
                  <div className="text-slate-600 text-xs">{test.description}</div>
                  <div className="text-[11px] text-slate-500 italic font-mono pt-1">
                    Assertion: {test.message}
                  </div>
                </div>

                <div className="text-right shrink-0">
                  {test.passed ? (
                    <span className="inline-flex items-center gap-1 bg-emerald-100 text-emerald-800 px-2.5 py-1 rounded-full text-xs font-bold">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                      PASSED
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 bg-rose-100 text-rose-800 px-2.5 py-1 rounded-full text-xs font-bold">
                      <XCircle className="w-3.5 h-3.5 text-rose-600" />
                      FAILED
                    </span>
                  )}
                  <div className="text-[10px] text-slate-400 mt-1 font-mono">
                    {test.executionTimeMs}ms
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="p-8 text-center text-slate-400 space-y-3">
              <FlaskConical className="w-8 h-8 mx-auto text-slate-300" />
              <div className="text-xs">
                Click <strong>"Run Automated Tests"</strong> to test atomic wallet balances, duplicate UTR rejections, failed lookup zero-charge protections, and role boundaries.
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
