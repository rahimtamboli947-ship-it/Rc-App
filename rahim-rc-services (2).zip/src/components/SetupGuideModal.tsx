import React from 'react';
import {
  HelpCircle,
  X,
  ShieldCheck,
  Server,
  QrCode,
  FileCheck,
  AlertTriangle,
  ExternalLink,
  Lock,
  KeyRound
} from 'lucide-react';

interface SetupGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SetupGuideModal: React.FC<SetupGuideModalProps> = ({ isOpen, onClose }) => {
  const [lang, setLang] = React.useState<'en' | 'hi'>('hi');

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
      <div className="relative w-full max-w-3xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-auto max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="bg-gradient-to-r from-orange-600 to-amber-600 px-5 py-4 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-white/20 flex items-center justify-center text-white">
              <HelpCircle className="w-5 h-5 stroke-[2.5]" />
            </div>
            <div>
              <h3 className="font-extrabold text-base sm:text-lg leading-tight">
                {lang === 'hi' ? 'प्रोडक्शन परिनियोजन एवं वॉलेट रियल मोड गाइड' : 'Production Deployment & Wallet Setup Guide'}
              </h3>
              <p className="text-xs text-orange-100 font-medium">
                {lang === 'hi'
                  ? 'वॉलेट रीचार्ज, बैंक समाधान, और अधिकृत RC API सेटअप'
                  : 'Step-by-step instructions for Wallet, UPI Gateway, and Authorized RC APIs'}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <div className="bg-white/20 p-0.5 rounded-lg flex items-center text-[11px] font-bold">
              <button
                onClick={() => setLang('hi')}
                className={`px-2 py-0.5 rounded-md transition ${lang === 'hi' ? 'bg-white text-orange-700 shadow-xs' : 'text-white/80 hover:text-white'}`}
              >
                हिंदी
              </button>
              <button
                onClick={() => setLang('en')}
                className={`px-2 py-0.5 rounded-md transition ${lang === 'en' ? 'bg-white text-orange-700 shadow-xs' : 'text-white/80 hover:text-white'}`}
              >
                English
              </button>
            </div>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-white/80 hover:text-white hover:bg-white/20 transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-6 text-xs sm:text-sm text-slate-700 leading-relaxed">
          {/* Section 1: Pre-launch Production Notice */}
          <div className="bg-amber-50 border-2 border-amber-300 rounded-2xl p-4 flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" />
            <div className="space-y-1 text-xs">
              <span className="font-bold text-amber-950 block text-sm">
                Production Readiness Standard
              </span>
              <p className="text-amber-900">
                This platform is running in a fully functional server-backed demonstration mode with verified simulated vehicles. <strong>Do NOT accept real customer payments</strong> until you have completed the security checklist below, passed the automated system tests, and contracted with an authorized RC data provider.
              </p>
            </div>
          </div>

          {/* Section 2: Authorized RC API Integration */}
          <div className="space-y-3">
            <div className="flex items-center gap-2 text-slate-900 font-extrabold text-sm sm:text-base border-b border-slate-200 pb-2">
              <Server className="w-4 h-4 text-orange-600" />
              <span>1. How to Connect an Authorized Vehicle Information API</span>
            </div>
            <p className="text-xs text-slate-600">
              In India, real-time Vehicle Registration Certificate data must be accessed through licensed government service providers or authorized aggregators compliant with Parivahan Vahan guidelines.
            </p>
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 space-y-2 text-xs">
              <div className="font-bold text-slate-800">Supported Authorized Gateways:</div>
              <ul className="list-disc pl-4 space-y-1 text-slate-600">
                <li><strong>Surepass.io</strong>: Vehicle RC Lite & Detailed API</li>
                <li><strong>Signzy Technologies</strong>: Parivahan Vahan Verification API</li>
                <li><strong>Sandbox.co.in</strong>: Indian Vehicle Registration & Challan API</li>
                <li><strong>IDfy</strong>: Vehicle RC & Hypothecation Check API</li>
              </ul>
              <div className="font-bold text-slate-800 pt-2">Environment Variables Configuration:</div>
              <div className="bg-slate-900 text-slate-200 p-3 rounded-lg font-mono text-[11px] overflow-x-auto">
                <div># Set these in your secure server environment (.env)</div>
                <div>RC_API_LIVE="true"</div>
                <div>RC_API_KEY="your_production_api_token_here"</div>
                <div>RC_API_ENDPOINT="https://kyc-api.surepass.io/api/v1/rc/rc-full"</div>
              </div>
            </div>
          </div>

          {/* Section 3: Manual UPI Recharge Configuration */}
          <div className="space-y-3">
            <div className="flex items-center gap-2 text-slate-900 font-extrabold text-sm sm:text-base border-b border-slate-200 pb-2">
              <QrCode className="w-4 h-4 text-emerald-600" />
              <span>2. UPI Payment & Manual Bank Reconciliation Flow</span>
            </div>
            <div className="space-y-2 text-xs text-slate-600">
              <p>
                To collect wallet deposits from agents without expensive payment gateway gateway transaction fees (1.8% to 2% MDR):
              </p>
              <ol className="list-decimal pl-4 space-y-1.5">
                <li>
                  Open the <strong>Admin Panel → Pricing & UPI Config</strong> tab.
                </li>
                <li>
                  Enter your current business UPI ID (e.g. <code className="bg-slate-100 px-1 py-0.5 rounded font-mono font-bold">youragency@okhdfcbank</code>) and Payee Name.
                </li>
                <li>
                  The dynamic QR code generator will automatically update to generate Bharat QR / NPCI compliant URI links with prefilled amounts.
                </li>
                <li>
                  <strong>Reconciliation Rule</strong>: When an agent submits a 12-digit UTR, the Administrator must log in to their HDFC/ICICI/SBI NetBanking or UPI app, verify that the funds have cleared, and only then click <strong>"Approve & Credit"</strong>.
                </li>
                <li>
                  The server strictly blocks duplicate UTR numbers across all users to prevent double-spending or fraudulent submissions.
                </li>
              </ol>
            </div>
          </div>

          {/* Section 4: Firebase Configuration */}
          <div className="space-y-3">
            <div className="flex items-center gap-2 text-slate-900 font-extrabold text-sm sm:text-base border-b border-slate-200 pb-2">
              <Lock className="w-4 h-4 text-sky-600" />
              <span>3. How to Connect Google Cloud Firestore & Firebase Auth</span>
            </div>
            <div className="space-y-2 text-xs text-slate-600">
              <p>
                If you choose to synchronize the current high-performance Express/Node backend with Cloud Firestore:
              </p>
              <ol className="list-decimal pl-4 space-y-1">
                <li>Create a Firebase Project in the Firebase Console (console.firebase.google.com).</li>
                <li>Enable Firebase Authentication with Email/Password and Google Sign-in.</li>
                <li>Create a Cloud Firestore database in Production Mode.</li>
                <li>Deploy the collections: <code className="bg-slate-100 px-1 rounded">users, agentProfiles, walletAccounts, walletTransactions, rechargeRequests, rcLookupRequests, servicePricing, appSettings, auditLogs</code>.</li>
                <li>Apply strict security rules disallowing client-side modifications of <code className="bg-slate-100 px-1 rounded">walletAccounts</code> and <code className="bg-slate-100 px-1 rounded">walletTransactions</code> (server-only write permissions).</li>
              </ol>
            </div>
          </div>

          {/* Section 5: Wallet Real Mode Setup & Reconciliation */}
          <div className="space-y-3">
            <div className="flex items-center gap-2 text-slate-900 font-extrabold text-sm sm:text-base border-b border-slate-200 pb-2">
              <KeyRound className="w-4 h-4 text-orange-600" />
              <span>
                {lang === 'hi'
                  ? '4. वॉलेट रियल मोड सेटअप व बैंक मिलान (Wallet Real Mode Setup)'
                  : '4. Wallet Real Mode Setup & Bank Reconciliation Guide'}
              </span>
            </div>

            <div className="bg-gradient-to-br from-amber-50 to-orange-50 border border-amber-300 rounded-xl p-4 space-y-3 text-xs">
              <div className="flex items-center gap-2 text-amber-950 font-bold text-sm">
                <ShieldCheck className="w-4 h-4 text-amber-700" />
                <span>
                  {lang === 'hi'
                    ? 'सख्त सुरक्षा नियम (Strict Reconciliation Rule)'
                    : 'Critical Bank Reconciliation Rule'}
                </span>
              </div>
              <p className="text-amber-900 leading-relaxed">
                {lang === 'hi'
                  ? 'एजेंट द्वारा यूटीआर (UTR) दर्ज करना या स्क्रीनशॉट अपलोड करना भुगतान का प्रमाण नहीं है। व्यवस्थापक (Admin) को पहले अपने बैंक खाते (HDFC / ICICI / SBI / Bank Statement) में पैसे जमा होने की पुष्टि करनी चाहिए, उसके बाद ही "Approve" पर क्लिक करना चाहिए।'
                  : 'Recharge requests are NOT proof of payment. An administrator must verify the incoming funds in the receiving bank account before approving any request. Never credit a wallet only because a user typed a 12-digit UTR or uploaded a receipt.'}
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1 font-mono text-[11px]">
                <div className="bg-white p-2.5 rounded-lg border border-amber-200">
                  <div className="font-bold text-slate-800 mb-1">Agent Recharge API:</div>
                  <div className="text-slate-600">POST /api/agent/recharge</div>
                  <div className="text-slate-500 text-[10px] mt-0.5">amountPaise, utrNumber, paymentDate</div>
                </div>
                <div className="bg-white p-2.5 rounded-lg border border-amber-200">
                  <div className="font-bold text-slate-800 mb-1">Admin Approval API:</div>
                  <div className="text-slate-600">POST /api/admin/recharges/:id/review</div>
                  <div className="text-slate-500 text-[10px] mt-0.5">{`{ action: "approve" | "reject", reviewNotes }`}</div>
                </div>
              </div>

              <div className="text-[11px] text-slate-700 space-y-1 pt-1">
                <div className="font-bold text-slate-900">
                  {lang === 'hi' ? 'असली पैसों के उपयोग पूर्व 8 जरूरी कदम:' : '8 Mandatory Pre-launch Security Safeguards:'}
                </div>
                <ul className="list-disc pl-4 space-y-0.5 text-slate-600">
                  <li>{lang === 'hi' ? 'पासवर्ड को Argon2id या Bcrypt में सुरक्षित रखें।' : 'Hash passwords using Argon2id or Bcrypt.'}</li>
                  <li>{lang === 'hi' ? 'सत्रों (Sessions) के लिए समय-सीमित टोकन और HTTPS का उपयोग करें।' : 'Enforce signed, expiring session tokens over HTTPS.'}</li>
                  <li>{lang === 'hi' ? 'कंकरेंट वॉलेट कटौती के लिए एटॉमिक डेटाबेस लॉकिंग लागू करें।' : 'Enforce atomic balance updates and transactional locks.'}</li>
                  <li>{lang === 'hi' ? 'त्वरित ऑटो-क्रेडिट हेतु अधिकृत पेमेंट गेटवे वेबहुक कनेक्ट करें।' : 'Integrate verified server-side payment gateway webhooks.'}</li>
                </ul>
              </div>
            </div>
          </div>

          {/* Section 6: Pre-Launch Testing Checklist */}
          <div className="space-y-3">
            <div className="flex items-center gap-2 text-slate-900 font-extrabold text-sm sm:text-base border-b border-slate-200 pb-2">
              <FileCheck className="w-4 h-4 text-purple-600" />
              <span>
                {lang === 'hi'
                  ? '5. लॉन्च से पहले अनिवार्य परीक्षण चेकलिस्ट'
                  : '5. Mandatory Pre-Launch Testing Checklist'}
              </span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
              <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-2.5 text-emerald-900">
                ✔ <strong>{lang === 'hi' ? 'स्वचालित टेस्ट चलाएं' : 'Run Automated Tests'}</strong>: {lang === 'hi' ? 'सिस्टम टेस्ट टैब में 6/6 टेस्ट पास होने की पुष्टि करें।' : 'Visit System Tests tab and verify 6/6 tests pass.'}
              </div>
              <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-2.5 text-emerald-900">
                ✔ <strong>{lang === 'hi' ? 'शून्य-चार्ज सत्यापन' : 'Test Zero-Charge'}</strong>: {lang === 'hi' ? 'यादृच्छिक प्लेट खोजें; बिना रिजल्ट वॉलेट नहीं कटना चाहिए।' : 'Search a non-existent plate; ensure wallet is not debited.'}
              </div>
              <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-2.5 text-emerald-900">
                ✔ <strong>{lang === 'hi' ? 'डुप्लीकेट यूटीआर जांच' : 'Test Duplicate UTR'}</strong>: {lang === 'hi' ? 'समान यूटीआर दोबारा दर्ज करें; अस्वीकार होना अनिवार्य है।' : 'Submit an existing UTR and confirm strict server rejection.'}
              </div>
              <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-2.5 text-emerald-900">
                ✔ <strong>{lang === 'hi' ? 'लाइव टेस्ट भुगतान' : 'Test Small Payment'}</strong>: {lang === 'hi' ? '₹100 का टेस्ट ट्रांसफर करें और बैंक मिलान करके स्वीकृत करें।' : 'Execute a ₹100 live test transfer and verify approval flow.'}
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="bg-slate-50 border-t border-slate-200 px-5 py-3 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-1.5 text-xs text-slate-500 font-medium">
            <span>Guide:</span>
            <span className="font-mono text-slate-700 bg-slate-200/80 px-1.5 py-0.5 rounded text-[11px]">
              WALLET_REAL_MODE_SETUP_HI.md
            </span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-orange-600 hover:bg-orange-700 text-white rounded-lg text-xs font-bold transition"
          >
            {lang === 'hi' ? 'समझ लिया और बंद करें' : 'I Understand & Close'}
          </button>
        </div>
      </div>
    </div>
  );
};
