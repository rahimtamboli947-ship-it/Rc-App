import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext.js';
import { VehicleRCData } from '../types/index.js';
import {
  Search,
  X,
  Printer,
  ShieldCheck,
  AlertCircle,
  CheckCircle2,
  Car,
  Fuel,
  Calendar,
  Building2,
  FileText,
  AlertTriangle,
  RotateCcw,
  Sparkles,
  Info
} from 'lucide-react';

interface RCSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  openRechargeModal: () => void;
}

export const RCSearchModal: React.FC<RCSearchModalProps> = ({
  isOpen,
  onClose,
  openRechargeModal
}) => {
  const { user, wallet, token, t, refreshWallet, publicConfig } = useAuth();
  const [regNumber, setRegNumber] = useState('');
  const [chassisNumber, setChassisNumber] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [searchStep, setSearchStep] = useState<string>('');
  const [error, setError] = useState<string | null>(null);
  const [rcResult, setRcResult] = useState<VehicleRCData | null>(null);
  const [lastChargedPaise, setLastChargedPaise] = useState<number | null>(null);
  const [showFullOwner, setShowFullOwner] = useState(false);

  if (!isOpen) return null;

  const pricePaise = publicConfig?.rcLookupPricePaise || 1500;
  const currentBalance = wallet?.balancePaise || 0;
  const hasSufficientBalance = currentBalance >= pricePaise;

  const demoVehicles = [
    { plate: 'MH12DE1433', name: 'Hero Splendor Plus', type: '2-Wheeler' },
    { plate: 'DL01AB1234', name: 'Maruti Swift Dzire Taxi', type: 'Cab' },
    { plate: 'KA05MH7788', name: 'Hyundai Creta SX', type: 'Car' },
    { plate: 'RJ14CP4000', name: 'Tata Ace Gold', type: 'Goods' },
    { plate: 'UP32AB9999', name: 'Honda Activa 6G', type: 'Scooter' },
  ];

  const handleSearch = async (plateToSearch?: string) => {
    const targetPlate = (plateToSearch || regNumber).trim().toUpperCase().replace(/[^A-Za-z0-9]/g, '');

    if (!targetPlate) {
      setError('Please enter a vehicle registration number');
      return;
    }

    if (user?.role === 'agent') {
      if (user.status !== 'approved') {
        setError('Your agent account is pending administrator approval. RC lookups cannot be performed until approved.');
        return;
      }

      if (!hasSufficientBalance) {
        setError(`Insufficient balance. Minimum ₹${(pricePaise / 100).toFixed(2)} required. Current balance: ₹${(currentBalance / 100).toFixed(2)}.`);
        return;
      }
    }

    setIsLoading(true);
    setError(null);
    setRcResult(null);
    setLastChargedPaise(null);

    // Realistic progress animation
    setSearchStep('Connecting to National Vahan 4.0 API...');
    await new Promise(r => setTimeout(r, 200));

    try {
      setSearchStep('Fetching vehicle specifications & insurance records...');
      const endpoint = token ? '/api/agent/rc-lookup' : '/api/public/rc-lookup';
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      if (token) headers['Authorization'] = `Bearer ${token}`;

      const res = await fetch(endpoint, {
        method: 'POST',
        headers,
        body: JSON.stringify({
          registrationNumber: targetPlate,
          chassisNumber: chassisNumber || undefined
        })
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || 'RC search request failed');
      }

      if (!data.success) {
        setError(data.error || 'Vehicle record not found in the national registry.');
      } else {
        setRcResult(data.rcData);
        if (data.chargedAmountPaise) {
          setLastChargedPaise(data.chargedAmountPaise);
        }
        if (token) {
          await refreshWallet();
        }
      }
    } catch (err: any) {
      setError(err.message || 'Connection to RC database failed');
    } finally {
      setIsLoading(false);
      setSearchStep('');
    }
  };

  const handlePrintSlip = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-auto max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="bg-gradient-to-r from-orange-600 via-orange-500 to-amber-600 px-5 py-4 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-white/20 flex items-center justify-center text-white">
              <Search className="w-5 h-5 stroke-[2.5]" />
            </div>
            <div>
              <h3 className="font-extrabold text-base sm:text-lg leading-tight">
                {t.vehicleSearchTitle}
              </h3>
              <p className="text-xs text-orange-100 font-medium">
                Parivahan Vahan National Registry • Instant Online Verification
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-white/80 hover:text-white hover:bg-white/20 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-4">
          {/* Status Banners */}
          {user?.status === 'pending_approval' && (
            <div className="bg-amber-50 border border-amber-200 rounded-xl p-3.5 flex items-start gap-3">
              <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
              <div className="text-xs text-amber-900">
                <span className="font-bold block text-sm">Account Pending Admin Approval</span>
                {t.pendingApprovalNotice}
              </div>
            </div>
          )}

          {!hasSufficientBalance && user?.status === 'approved' && (
            <div className="bg-rose-50 border border-rose-200 rounded-xl p-3.5 flex items-center justify-between gap-3">
              <div className="flex items-center gap-2.5 text-xs text-rose-900">
                <AlertCircle className="w-5 h-5 text-rose-600 shrink-0" />
                <div>
                  <span className="font-bold">Low Wallet Balance (₹{(currentBalance / 100).toFixed(2)})</span>
                  <p>Minimum ₹{(pricePaise / 100).toFixed(2)} required to search vehicle RC.</p>
                </div>
              </div>
              <button
                onClick={() => {
                  onClose();
                  openRechargeModal();
                }}
                className="bg-rose-600 hover:bg-rose-700 text-white px-3 py-1.5 rounded-lg text-xs font-bold transition shrink-0"
              >
                Recharge Now
              </button>
            </div>
          )}

          {/* Search Input Box */}
          <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-3.5">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                {t.vehicleNumberLabel} <span className="text-rose-500">*</span>
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <span className="bg-amber-400 text-slate-950 font-black text-[11px] px-1.5 py-0.5 rounded-sm">
                    IND
                  </span>
                </div>
                <input
                  type="text"
                  value={regNumber}
                  onChange={e => setRegNumber(e.target.value.toUpperCase())}
                  onKeyDown={e => e.key === 'Enter' && handleSearch()}
                  placeholder={t.vehicleNumberPlaceholder}
                  className="w-full pl-14 pr-4 py-2.5 bg-white border-2 border-slate-300 focus:border-orange-500 rounded-xl text-base font-mono font-bold tracking-wider text-slate-900 focus:outline-hidden transition shadow-xs"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 items-end">
              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1">
                  {t.chassisNumberLabel}
                </label>
                <input
                  type="text"
                  value={chassisNumber}
                  onChange={e => setChassisNumber(e.target.value.toUpperCase())}
                  placeholder={t.chassisPlaceholder}
                  className="w-full px-3 py-2 bg-white border border-slate-300 focus:border-orange-500 rounded-xl text-sm font-mono text-slate-800 focus:outline-hidden"
                />
              </div>

              <button
                onClick={() => handleSearch()}
                disabled={isLoading || !regNumber.trim() || !hasSufficientBalance}
                className="w-full bg-gradient-to-r from-orange-600 to-orange-500 hover:from-orange-700 hover:to-orange-600 disabled:opacity-50 text-white font-bold py-2.5 px-4 rounded-xl shadow-md shadow-orange-600/20 transition flex items-center justify-center gap-2 text-sm"
              >
                {isLoading ? (
                  <>
                    <RotateCcw className="w-4 h-4 animate-spin" />
                    <span>{t.searchingBtn}</span>
                  </>
                ) : (
                  <>
                    <Search className="w-4 h-4 stroke-[2.5]" />
                    <span>{t.searchBtn}</span>
                  </>
                )}
              </button>
            </div>

            {/* Quick Demo Vehicles selector */}
            <div>
              <div className="flex items-center justify-between text-[11px] font-bold text-slate-500 mb-1.5">
                <span className="flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5 text-orange-500" />
                  Quick Test Vehicles (Click to test):
                </span>
                <span className="text-[10px] text-orange-600 font-semibold">Authorized Sample Records</span>
              </div>
              <div className="flex flex-wrap gap-1.5">
                {demoVehicles.map(demo => (
                  <button
                    key={demo.plate}
                    type="button"
                    onClick={() => {
                      setRegNumber(demo.plate);
                      handleSearch(demo.plate);
                    }}
                    className="bg-white hover:bg-orange-50 hover:border-orange-400 border border-slate-200 text-slate-800 px-2.5 py-1 rounded-lg text-xs font-mono font-medium transition flex items-center gap-1.5 shadow-2xs"
                  >
                    <span className="font-bold text-orange-800">{demo.plate}</span>
                    <span className="text-[10px] text-slate-500 hidden sm:inline">({demo.name})</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Financial Guarantee Note */}
            <div className="flex items-start gap-2 bg-emerald-50/80 border border-emerald-200 rounded-xl p-2.5 text-xs text-emerald-900">
              <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold">Zero-Risk Guarantee: </span>
                <span>
                  {t.chargeNotice.replace('{price}', (pricePaise / 100).toFixed(2))}
                </span>
              </div>
            </div>
          </div>

          {/* Loading Indicator */}
          {isLoading && (
            <div className="bg-orange-50 border border-orange-200 rounded-2xl p-6 text-center space-y-3 animate-pulse">
              <div className="w-12 h-12 rounded-full bg-orange-100 border-2 border-orange-500 flex items-center justify-center mx-auto text-orange-600 animate-spin">
                <RotateCcw className="w-6 h-6" />
              </div>
              <div>
                <div className="font-bold text-slate-900 text-sm">
                  {searchStep}
                </div>
                <div className="text-xs text-orange-700 mt-0.5">
                  Securely querying authorized transport databases
                </div>
              </div>
            </div>
          )}

          {/* Error Notice */}
          {error && !isLoading && (
            <div className="bg-rose-50 border border-rose-200 rounded-2xl p-4 flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
              <div className="space-y-1">
                <div className="text-sm font-bold text-rose-900">Lookup Result</div>
                <div className="text-xs text-rose-800">{error}</div>
                <div className="text-[11px] font-semibold text-emerald-700 flex items-center gap-1 pt-1">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  Your wallet was NOT charged (₹0.00 deducted).
                </div>
              </div>
            </div>
          )}

          {/* Successful RC Details Card */}
          {rcResult && !isLoading && (
            <div id="printable-rc-slip" className="space-y-4">
              {/* Charge Success Pill */}
              {lastChargedPaise !== null && (
                <div className="bg-emerald-100 border border-emerald-300 text-emerald-900 rounded-xl px-4 py-2 text-xs flex items-center justify-between font-semibold">
                  <span className="flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    Verified Parivahan RC Record Found!
                  </span>
                  <span>Fee Charged: ₹{(lastChargedPaise / 100).toFixed(2)}</span>
                </div>
              )}

              {/* Parivahan Style RC Verification Card */}
              <div className="border-2 border-slate-300 rounded-2xl bg-white shadow-sm overflow-hidden">
                {/* Certificate Header */}
                <div className="bg-slate-900 text-white p-4 flex items-center justify-between border-b border-slate-800">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-orange-500 flex items-center justify-center font-black text-white text-lg">
                      RC
                    </div>
                    <div>
                      <div className="text-xs uppercase tracking-widest text-slate-300 font-bold">
                        Government of India • Ministry of Road Transport & Highways
                      </div>
                      <div className="font-extrabold text-base sm:text-lg text-amber-400">
                        Certificate of Registration Verification
                      </div>
                    </div>
                  </div>
                  <div className="text-right hidden sm:block">
                    <span className="inline-block px-2 py-0.5 text-[11px] bg-emerald-500/20 text-emerald-400 font-bold rounded-sm border border-emerald-500/30">
                      STATUS: ACTIVE
                    </span>
                    <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                      Rahim RC Portal
                    </div>
                  </div>
                </div>

                {/* Number Plate Visual Hero */}
                <div className="bg-gradient-to-b from-amber-50 to-orange-50/50 p-4 border-b border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3">
                  <div className="inline-flex items-center border-3 border-slate-900 bg-white rounded-lg shadow-md overflow-hidden">
                    <div className="bg-amber-400 text-slate-950 font-black px-2.5 py-2 text-xs flex flex-col items-center justify-center border-r-2 border-slate-900">
                      <span>IND</span>
                      <div className="w-2 h-2 rounded-full border border-slate-900 mt-0.5"></div>
                    </div>
                    <div className="px-5 py-1 text-xl sm:text-2xl font-black font-mono tracking-widest text-slate-950">
                      {rcResult.registrationNumber}
                    </div>
                  </div>

                  <div className="text-center sm:text-right">
                    <div className="text-xs font-bold text-slate-800">{rcResult.makerModel}</div>
                    <div className="text-[11px] text-slate-600">{rcResult.makerDescription}</div>
                  </div>
                </div>

                {/* Grid of Verified Specifications */}
                <div className="p-4 grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 space-y-1">
                    <div className="text-[10px] uppercase font-bold text-slate-500">{t.ownerName}</div>
                    <div className="font-extrabold text-slate-900 text-sm flex items-center justify-between">
                      <span>{showFullOwner ? rcResult.ownerName : rcResult.maskedOwnerName}</span>
                      <button
                        onClick={() => setShowFullOwner(!showFullOwner)}
                        className="text-[10px] text-orange-600 hover:underline font-semibold"
                      >
                        {showFullOwner ? 'Mask' : 'Reveal'}
                      </button>
                    </div>
                    <div className="text-[11px] text-slate-500">
                      Owner Serial: #{rcResult.ownerSerial || 1}
                    </div>
                  </div>

                  <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 space-y-1">
                    <div className="text-[10px] uppercase font-bold text-slate-500">{t.vehicleClass}</div>
                    <div className="font-bold text-slate-900 text-sm">{rcResult.vehicleClass}</div>
                    <div className="text-[11px] text-slate-500">
                      Commercial: {rcResult.isCommercial ? 'Yes (Taxi / Goods)' : 'Private Non-Transport'}
                    </div>
                  </div>

                  <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 space-y-1">
                    <div className="text-[10px] uppercase font-bold text-slate-500">{t.fuelType} & Emission</div>
                    <div className="font-bold text-slate-900">{rcResult.fuelType} • {rcResult.emissionNorms}</div>
                    <div className="text-[11px] text-slate-500">Color: {rcResult.color}</div>
                  </div>

                  <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 space-y-1">
                    <div className="text-[10px] uppercase font-bold text-slate-500">{t.regDate} & Fitness</div>
                    <div className="font-bold text-slate-900">Reg: {rcResult.registrationDate}</div>
                    <div className="text-[11px] text-emerald-700 font-semibold">
                      Fitness Valid: {rcResult.fitnessUpto}
                    </div>
                  </div>

                  <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 space-y-1">
                    <div className="text-[10px] uppercase font-bold text-slate-500">{t.insuranceDetails}</div>
                    <div className="font-bold text-slate-900">{rcResult.insuranceCompany}</div>
                    <div className="text-[11px] text-slate-600">
                      Policy: {rcResult.insurancePolicyNumber} • Valid Upto:{' '}
                      <span className="font-bold text-emerald-700">{rcResult.insuranceUpto}</span>
                    </div>
                  </div>

                  <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 space-y-1">
                    <div className="text-[10px] uppercase font-bold text-slate-500">{t.financed}</div>
                    <div className="font-bold text-slate-900">
                      {rcResult.isFinanced ? `YES - ${rcResult.financingBank}` : 'NO HYPOTHECATION'}
                    </div>
                    <div className="text-[11px] text-slate-500">
                      Road Tax: {rcResult.taxUpto} | PUCC: {rcResult.puccUpto}
                    </div>
                  </div>

                  <div className="sm:col-span-2 bg-slate-50 p-3 rounded-xl border border-slate-200 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
                    <div>
                      <div className="text-[10px] uppercase font-bold text-slate-500">{t.rto}</div>
                      <div className="font-bold text-slate-900">{rcResult.rtoName}, {rcResult.rtoState}</div>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-[11px] font-bold text-slate-600">Challan / Blacklist:</span>
                      <span
                        className={`px-2 py-0.5 rounded-full text-[11px] font-bold ${
                          rcResult.blacklistStatus === 'CLEAN'
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-rose-100 text-rose-800'
                        }`}
                      >
                        {rcResult.blacklistStatus === 'CLEAN' ? 'CLEAN / NO BLACKLIST' : 'PENDING CHALLAN'}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Printable Footer / Watermark */}
                <div className="bg-slate-100 px-4 py-2.5 border-t border-slate-200 flex items-center justify-between text-[11px] text-slate-500 font-mono">
                  <span>Verified by Rahim RC Services • Authorized Portal</span>
                  <span>Date: {new Date().toLocaleDateString('en-IN')}</span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center justify-end gap-2.5 pt-2">
                <button
                  onClick={handlePrintSlip}
                  className="bg-slate-900 hover:bg-slate-800 text-white px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-xs"
                >
                  <Printer className="w-4 h-4" />
                  <span>{t.printSlip}</span>
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="bg-slate-50 border-t border-slate-200 px-5 py-3 text-right shrink-0">
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-800 rounded-lg text-xs font-bold transition"
          >
            {t.close}
          </button>
        </div>
      </div>
    </div>
  );
};
