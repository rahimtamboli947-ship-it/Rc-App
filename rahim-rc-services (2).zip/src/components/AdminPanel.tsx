import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext.js';
import {
  User,
  RechargeRequest,
  WalletTransaction,
  RCLookupRequest,
  AppSettings,
  ServicePricing,
  AuditLog
} from '../types/index.js';
import {
  ShieldCheck,
  Users,
  CreditCard,
  History,
  FileSearch,
  Settings,
  CheckCircle,
  XCircle,
  AlertTriangle,
  Search,
  Download,
  RotateCcw,
  Plus,
  Minus,
  Edit2,
  DollarSign,
  TrendingUp,
  Shield,
  Clock,
  Sparkles,
  KeyRound,
  QrCode,
  FileCheck
} from 'lucide-react';

interface AgentWithWallet extends User {
  wallet: {
    balancePaise: number;
    totalRechargedPaise: number;
    totalSpentPaise: number;
    successfulLookupsCount: number;
  };
}

interface AdminPanelProps {
  openChangePassword?: () => void;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({ openChangePassword }) => {
  const { token, t, refreshConfig } = useAuth();
  const [activeTab, setActiveTab] = useState<'overview' | 'agents' | 'recharges' | 'ledger' | 'rclogs' | 'config' | 'walletsetup'>('overview');
  const [guideLang, setGuideLang] = useState<'en' | 'hi'>('hi');
  const [stats, setStats] = useState<any>(null);
  const [agents, setAgents] = useState<AgentWithWallet[]>([]);
  const [recharges, setRecharges] = useState<RechargeRequest[]>([]);
  const [transactions, setTransactions] = useState<WalletTransaction[]>([]);
  const [rcLogs, setRcLogs] = useState<RCLookupRequest[]>([]);
  const [pricing, setPricing] = useState<ServicePricing | null>(null);
  const [settings, setSettings] = useState<AppSettings | null>(null);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  // Filter states
  const [agentSearch, setAgentSearch] = useState<string>('');
  const [rechargeFilter, setRechargeFilter] = useState<'all' | 'pending' | 'approved' | 'rejected'>('pending');

  // Modals / Actions
  const [selectedAgentForAdjustment, setSelectedAgentForAdjustment] = useState<AgentWithWallet | null>(null);
  const [adjustAmountRs, setAdjustAmountRs] = useState<string>('100');
  const [adjustIsCredit, setAdjustIsCredit] = useState<boolean>(true);
  const [adjustReason, setAdjustReason] = useState<string>('');
  const [isAdjusting, setIsAdjusting] = useState<boolean>(false);

  // Agent Password Reset by Admin
  const [selectedAgentForPasswordReset, setSelectedAgentForPasswordReset] = useState<AgentWithWallet | null>(null);
  const [agentNewPassword, setAgentNewPassword] = useState<string>('agent123');
  const [isResettingAgentPassword, setIsResettingAgentPassword] = useState<boolean>(false);

  // Reject modal
  const [selectedRechargeForReject, setSelectedRechargeForReject] = useState<RechargeRequest | null>(null);
  const [rejectReason, setRejectReason] = useState<string>('Payment not received in bank account statement');

  const [message, setMessage] = useState<{ text: string; type: 'success' | 'error' } | null>(null);

  const fetchAdminData = async () => {
    if (!token) return;
    setIsLoading(true);
    try {
      const headers = { Authorization: `Bearer ${token}` };
      const [
        statsRes,
        agentsRes,
        rechargesRes,
        txnsRes,
        logsRes,
        pricingRes,
        settingsRes
      ] = await Promise.all([
        fetch('/api/admin/stats', { headers }),
        fetch('/api/admin/agents', { headers }),
        fetch('/api/admin/recharges', { headers }),
        fetch('/api/admin/transactions', { headers }),
        fetch('/api/admin/rc-logs', { headers }),
        fetch('/api/admin/pricing', { headers }),
        fetch('/api/config/public')
      ]);

      if (statsRes.ok) setStats((await statsRes.json()).stats);
      if (agentsRes.ok) setAgents((await agentsRes.json()).agents || []);
      if (rechargesRes.ok) setRecharges((await rechargesRes.json()).recharges || []);
      if (txnsRes.ok) setTransactions((await txnsRes.json()).transactions || []);
      if (logsRes.ok) setRcLogs((await logsRes.json()).logs || []);
      if (pricingRes.ok) setPricing((await pricingRes.json()).pricing);
      if (settingsRes.ok) {
        const pub = await settingsRes.json();
        setSettings({
          upiId: pub.upiId,
          payeeName: pub.payeeName,
          upiNotes: pub.upiNotes,
          isLiveApiEnabled: pub.isLiveApiEnabled,
          apiProviderName: pub.apiStatus?.providerName || 'Simulated Adapter',
          apiStatusMessage: pub.apiStatus?.statusMessage || '',
          supportPhone: pub.supportPhone,
          supportEmail: pub.supportEmail
        });
      }
    } catch (err) {
      console.error('Failed to load admin data', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchAdminData();
  }, [token]);

  // Handle Agent Status Change
  const handleUpdateAgentStatus = async (agentId: string, status: 'approved' | 'suspended' | 'pending_approval') => {
    try {
      const res = await fetch(`/api/admin/agents/${agentId}/status`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ status })
      });
      if (res.ok) {
        setMessage({ text: `Agent status updated to ${status}`, type: 'success' });
        await fetchAdminData();
      } else {
        const d = await res.json();
        setMessage({ text: d.error || 'Failed to update status', type: 'error' });
      }
    } catch (err: any) {
      setMessage({ text: err.message, type: 'error' });
    }
  };

  // Handle Recharge Review (Approve or Reject)
  const handleReviewRecharge = async (requestId: string, action: 'approve' | 'reject', reviewNotes?: string) => {
    try {
      const res = await fetch(`/api/admin/recharges/${requestId}/review`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ action, reviewNotes })
      });

      const d = await res.json();
      if (res.ok) {
        setMessage({ text: d.message, type: 'success' });
        setSelectedRechargeForReject(null);
        await fetchAdminData();
      } else {
        setMessage({ text: d.error || 'Failed to review request', type: 'error' });
      }
    } catch (err: any) {
      setMessage({ text: err.message, type: 'error' });
    }
  };

  // Handle Manual Wallet Balance Adjustment
  const handleAdjustWallet = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedAgentForAdjustment) return;

    const amountRs = parseFloat(adjustAmountRs);
    if (isNaN(amountRs) || amountRs <= 0 || !adjustReason.trim()) {
      setMessage({ text: 'Please enter a valid amount and audit reason', type: 'error' });
      return;
    }

    setIsAdjusting(true);
    try {
      const res = await fetch(`/api/admin/agents/${selectedAgentForAdjustment.id}/adjust-wallet`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({
          amountPaise: Math.round(amountRs * 100),
          isCredit: adjustIsCredit,
          reason: adjustReason.trim()
        })
      });

      const d = await res.json();
      if (res.ok) {
        setMessage({ text: d.message, type: 'success' });
        setSelectedAgentForAdjustment(null);
        setAdjustReason('');
        await fetchAdminData();
      } else {
        setMessage({ text: d.error || 'Failed to adjust balance', type: 'error' });
      }
    } catch (err: any) {
      setMessage({ text: err.message, type: 'error' });
    } finally {
      setIsAdjusting(false);
    }
  };

  // Handle Admin direct agent password reset
  const handleResetAgentPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedAgentForPasswordReset) return;
    setIsResettingAgentPassword(true);

    try {
      const res = await fetch(`/api/admin/agents/${selectedAgentForPasswordReset.id}/reset-password`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ newPassword: agentNewPassword })
      });

      const d = await res.json();
      if (res.ok) {
        setMessage({
          text: `Password updated for ${selectedAgentForPasswordReset.name} (${selectedAgentForPasswordReset.email}) to '${agentNewPassword}'`,
          type: 'success'
        });
        setSelectedAgentForPasswordReset(null);
      } else {
        setMessage({ text: d.error || 'Failed to update agent password', type: 'error' });
      }
    } catch (err: any) {
      setMessage({ text: err.message, type: 'error' });
    } finally {
      setIsResettingAgentPassword(false);
    }
  };

  // Handle Pricing & Settings Update
  const handleSavePricingAndSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!pricing || !settings) return;

    try {
      const pRes = await fetch('/api/admin/pricing', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify(pricing)
      });

      const sRes = await fetch('/api/admin/settings', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify(settings)
      });

      if (pRes.ok && sRes.ok) {
        setMessage({ text: 'Pricing and application settings saved successfully!', type: 'success' });
        await refreshConfig();
        await fetchAdminData();
      } else {
        setMessage({ text: 'Failed to update configurations', type: 'error' });
      }
    } catch (err: any) {
      setMessage({ text: err.message, type: 'error' });
    }
  };

  // CSV Export utility
  const exportToCsv = (filename: string, rows: any[]) => {
    if (!rows.length) return;
    const separator = ',';
    const keys = Object.keys(rows[0]);
    const csvContent =
      keys.join(separator) +
      '\n' +
      rows
        .map(row => {
          return keys
            .map(k => {
              let cell = row[k] === null || row[k] === undefined ? '' : row[k];
              cell = cell instanceof Date ? cell.toLocaleString() : cell.toString().replace(/"/g, '""');
              if (cell.search(/("|,|\n)/g) >= 0) {
                cell = `"${cell}"`;
              }
              return cell;
            })
            .join(separator);
        })
        .join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.setAttribute('download', `${filename}_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const filteredAgents = agents.filter(
    a =>
      a.name.toLowerCase().includes(agentSearch.toLowerCase()) ||
      (a.agentId && a.agentId.toLowerCase().includes(agentSearch.toLowerCase())) ||
      a.phone.includes(agentSearch) ||
      (a.agencyName && a.agencyName.toLowerCase().includes(agentSearch.toLowerCase()))
  );

  const filteredRecharges = recharges.filter(r => {
    if (rechargeFilter === 'all') return true;
    return r.status === rechargeFilter;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      {/* Admin Header */}
      <div className="bg-gradient-to-r from-slate-900 via-orange-950 to-slate-900 rounded-3xl p-6 text-white shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-2xl bg-orange-600 flex items-center justify-center text-white shadow-lg shadow-orange-600/30">
            <ShieldCheck className="w-7 h-7 stroke-[2.5]" />
          </div>
          <div>
            <div className="text-xs font-bold uppercase tracking-wider text-orange-400">
              Administrative Control Console
            </div>
            <h1 className="text-2xl font-black tracking-tight">{t.adminDashboardTitle}</h1>
            <p className="text-xs text-slate-300">
              Logged in as Admin: <span className="text-white font-mono font-bold">rahimtamboli947@gmail.com</span>
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 self-end md:self-auto">
          {openChangePassword && (
            <button
              onClick={openChangePassword}
              className="bg-orange-600 hover:bg-orange-700 text-white px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-md shadow-orange-600/30 cursor-pointer"
              title="Change Administrator Password (पासवर्ड बदलें)"
            >
              <KeyRound className="w-3.5 h-3.5" />
              <span>Change Password</span>
            </button>
          )}

          <button
            onClick={fetchAdminData}
            className="bg-white/10 hover:bg-white/20 text-white px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 border border-white/20 cursor-pointer"
          >
            <RotateCcw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
            <span>Refresh Data</span>
          </button>
        </div>
      </div>

      {/* Alert / Toast Messages */}
      {message && (
        <div
          className={`p-4 rounded-xl text-xs font-bold flex items-center justify-between ${
            message.type === 'success'
              ? 'bg-emerald-50 border border-emerald-300 text-emerald-900'
              : 'bg-rose-50 border border-rose-300 text-rose-900'
          }`}
        >
          <span>{message.text}</span>
          <button onClick={() => setMessage(null)} className="text-slate-400 hover:text-slate-700">
            ×
          </button>
        </div>
      )}

      {/* Admin Navigation Tabs */}
      <div className="flex flex-wrap gap-2 border-b border-slate-200 pb-2">
        <button
          onClick={() => setActiveTab('overview')}
          className={`px-4 py-2 rounded-xl text-xs font-extrabold transition flex items-center gap-2 ${
            activeTab === 'overview'
              ? 'bg-orange-600 text-white shadow-sm'
              : 'bg-white text-slate-700 hover:bg-orange-50 border border-slate-200'
          }`}
        >
          <TrendingUp className="w-4 h-4" />
          <span>Revenue & Overview</span>
        </button>

        <button
          onClick={() => setActiveTab('agents')}
          className={`px-4 py-2 rounded-xl text-xs font-extrabold transition flex items-center gap-2 ${
            activeTab === 'agents'
              ? 'bg-orange-600 text-white shadow-sm'
              : 'bg-white text-slate-700 hover:bg-orange-50 border border-slate-200'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>{t.agentsManagement} ({agents.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('recharges')}
          className={`px-4 py-2 rounded-xl text-xs font-extrabold transition flex items-center gap-2 relative ${
            activeTab === 'recharges'
              ? 'bg-orange-600 text-white shadow-sm'
              : 'bg-white text-slate-700 hover:bg-orange-50 border border-slate-200'
          }`}
        >
          <CreditCard className="w-4 h-4" />
          <span>{t.rechargeApprovals}</span>
          {stats?.pendingRechargeCount > 0 && (
            <span className="bg-amber-400 text-slate-950 font-black text-[10px] px-1.5 py-0.2 rounded-full">
              {stats.pendingRechargeCount}
            </span>
          )}
        </button>

        <button
          onClick={() => setActiveTab('ledger')}
          className={`px-4 py-2 rounded-xl text-xs font-extrabold transition flex items-center gap-2 ${
            activeTab === 'ledger'
              ? 'bg-orange-600 text-white shadow-sm'
              : 'bg-white text-slate-700 hover:bg-orange-50 border border-slate-200'
          }`}
        >
          <History className="w-4 h-4" />
          <span>{t.transactionLedger}</span>
        </button>

        <button
          onClick={() => setActiveTab('rclogs')}
          className={`px-4 py-2 rounded-xl text-xs font-extrabold transition flex items-center gap-2 ${
            activeTab === 'rclogs'
              ? 'bg-orange-600 text-white shadow-sm'
              : 'bg-white text-slate-700 hover:bg-orange-50 border border-slate-200'
          }`}
        >
          <FileSearch className="w-4 h-4" />
          <span>{t.rcLogs}</span>
        </button>

        <button
          onClick={() => setActiveTab('config')}
          className={`px-4 py-2 rounded-xl text-xs font-extrabold transition flex items-center gap-2 ${
            activeTab === 'config'
              ? 'bg-orange-600 text-white shadow-sm'
              : 'bg-white text-slate-700 hover:bg-orange-50 border border-slate-200'
          }`}
        >
          <Settings className="w-4 h-4" />
          <span>{t.pricingSettings}</span>
        </button>

        <button
          onClick={() => setActiveTab('walletsetup')}
          className={`px-4 py-2 rounded-xl text-xs font-extrabold transition flex items-center gap-2 ${
            activeTab === 'walletsetup'
              ? 'bg-orange-600 text-white shadow-sm'
              : 'bg-white text-slate-700 hover:bg-orange-50 border border-slate-200'
          }`}
        >
          <KeyRound className="w-4 h-4 text-amber-500" />
          <span>Wallet Real Mode Setup (गाइड)</span>
        </button>
      </div>

      {/* TAB 1: OVERVIEW & FINANCIAL STATS */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs">
              <div className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">
                Total Revenue (RC Fees)
              </div>
              <div className="text-2xl sm:text-3xl font-black text-slate-900">
                ₹{((stats?.totalRevenuePaise || 0) / 100).toFixed(2)}
              </div>
              <div className="text-[11px] text-emerald-700 font-semibold mt-1">
                Estimated Gross Margin: ₹{((stats?.estimatedGrossMarginPaise || 0) / 100).toFixed(2)}
              </div>
            </div>

            <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs">
              <div className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">
                Recharged Volume
              </div>
              <div className="text-2xl sm:text-3xl font-black text-slate-900">
                ₹{((stats?.totalRechargedPaise || 0) / 100).toFixed(2)}
              </div>
              <div className="text-[11px] text-slate-500 mt-1">
                Pending Verification: ₹{((stats?.pendingRechargeAmountPaise || 0) / 100).toFixed(2)}
              </div>
            </div>

            <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs">
              <div className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">
                Total Verified RC Lookups
              </div>
              <div className="text-2xl sm:text-3xl font-black text-slate-900">
                {stats?.totalSuccessfulLookups || 0}
              </div>
              <div className="text-[11px] text-slate-500 mt-1">
                Failed/Not Found (Uncharged): {stats?.totalFailedLookups || 0}
              </div>
            </div>

            <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs">
              <div className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">
                Agent Accounts
              </div>
              <div className="text-2xl sm:text-3xl font-black text-slate-900">
                {stats?.totalAgents || 0}
              </div>
              <div className="text-[11px] text-amber-700 font-bold mt-1">
                {stats?.pendingAgents || 0} Pending Admin Approval
              </div>
            </div>
          </div>

          {/* Quick Review Action Card for Pending Recharges */}
          {stats?.pendingRechargeCount > 0 && (
            <div className="bg-amber-50 border-2 border-amber-300 rounded-2xl p-5 flex items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <Clock className="w-6 h-6 text-amber-600 shrink-0" />
                <div>
                  <div className="font-extrabold text-amber-950 text-sm sm:text-base">
                    Action Required: {stats.pendingRechargeCount} Pending Recharge Request(s)
                  </div>
                  <div className="text-xs text-amber-800">
                    Agents are waiting for UTR verification before their wallets are credited.
                  </div>
                </div>
              </div>
              <button
                onClick={() => setActiveTab('recharges')}
                className="bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs px-4 py-2.5 rounded-xl transition shadow-xs shrink-0"
              >
                Review Requests Now
              </button>
            </div>
          )}
        </div>
      )}

      {/* TAB 2: AGENT MANAGEMENT */}
      {activeTab === 'agents' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
            <div className="relative w-full sm:w-80">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
              <input
                type="text"
                placeholder="Search by agent name, ID, or phone..."
                value={agentSearch}
                onChange={e => setAgentSearch(e.target.value)}
                className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:outline-hidden focus:border-orange-500"
              />
            </div>

            <button
              onClick={() => exportToCsv('Rahim_RC_Agents', agents)}
              className="bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold px-3 py-2 rounded-xl transition flex items-center gap-1.5 self-end sm:self-auto"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export Agents CSV</span>
            </button>
          </div>

          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 uppercase font-bold text-[10px]">
                  <tr>
                    <th className="px-4 py-3">Agent ID & Name</th>
                    <th className="px-4 py-3">Agency / Contact</th>
                    <th className="px-4 py-3">Wallet Balance</th>
                    <th className="px-4 py-3">Lookups Done</th>
                    <th className="px-4 py-3">Status</th>
                    <th className="px-4 py-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredAgents.map(agent => (
                    <tr key={agent.id} className="hover:bg-slate-50/80">
                      <td className="px-4 py-3">
                        <div className="font-extrabold text-slate-900">{agent.name}</div>
                        <div className="font-mono text-[10px] text-orange-700 font-bold">
                          {agent.agentId || 'NO ID'}
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <div className="font-semibold text-slate-800">{agent.agencyName || 'Direct Agent'}</div>
                        <div className="text-[11px] text-slate-500">
                          {agent.phone} • {agent.district || ''} {agent.state || ''}
                        </div>
                      </td>
                      <td className="px-4 py-3 font-mono font-bold text-slate-900 text-sm">
                        ₹{((agent.wallet?.balancePaise || 0) / 100).toFixed(2)}
                      </td>
                      <td className="px-4 py-3 font-semibold text-slate-700">
                        {agent.wallet?.successfulLookupsCount || 0}
                      </td>
                      <td className="px-4 py-3">
                        {agent.status === 'approved' && (
                          <span className="bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full text-[10px] font-bold">
                            Active / Approved
                          </span>
                        )}
                        {agent.status === 'pending_approval' && (
                          <span className="bg-amber-100 text-amber-800 px-2 py-0.5 rounded-full text-[10px] font-bold">
                            Pending Approval
                          </span>
                        )}
                        {agent.status === 'suspended' && (
                          <span className="bg-rose-100 text-rose-800 px-2 py-0.5 rounded-full text-[10px] font-bold">
                            Suspended
                          </span>
                        )}
                      </td>
                      <td className="px-4 py-3 text-right space-x-1.5 whitespace-nowrap">
                        {agent.status === 'pending_approval' && (
                          <button
                            onClick={() => handleUpdateAgentStatus(agent.id, 'approved')}
                            className="bg-emerald-600 hover:bg-emerald-700 text-white px-2.5 py-1 rounded-lg text-xs font-bold transition"
                          >
                            Approve
                          </button>
                        )}
                        {agent.status === 'approved' && (
                          <button
                            onClick={() => handleUpdateAgentStatus(agent.id, 'suspended')}
                            className="bg-rose-100 hover:bg-rose-200 text-rose-800 px-2.5 py-1 rounded-lg text-xs font-bold transition"
                          >
                            Suspend
                          </button>
                        )}
                        {agent.status === 'suspended' && (
                          <button
                            onClick={() => handleUpdateAgentStatus(agent.id, 'approved')}
                            className="bg-emerald-100 hover:bg-emerald-200 text-emerald-800 px-2.5 py-1 rounded-lg text-xs font-bold transition"
                          >
                            Reactivate
                          </button>
                        )}
                        <button
                          onClick={() => setSelectedAgentForAdjustment(agent)}
                          className="bg-slate-100 hover:bg-slate-200 text-slate-800 px-2.5 py-1 rounded-lg text-xs font-bold transition cursor-pointer"
                        >
                          Adjust Wallet
                        </button>
                        <button
                          onClick={() => {
                            setSelectedAgentForPasswordReset(agent);
                            setAgentNewPassword('agent123');
                          }}
                          className="bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-200/80 px-2.5 py-1 rounded-lg text-xs font-bold transition inline-flex items-center gap-1 cursor-pointer"
                          title="Admin Reset Agent Password"
                        >
                          <KeyRound className="w-3 h-3 text-amber-600" />
                          <span>Reset Password</span>
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: RECHARGE APPROVALS */}
      {activeTab === 'recharges' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
            <div className="flex items-center gap-1.5">
              {(['pending', 'approved', 'rejected', 'all'] as const).map(tab => (
                <button
                  key={tab}
                  onClick={() => setRechargeFilter(tab)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold capitalize transition ${
                    rechargeFilter === tab
                      ? 'bg-orange-600 text-white'
                      : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                  }`}
                >
                  {tab}
                </button>
              ))}
            </div>

            <button
              onClick={() => exportToCsv('Rahim_RC_Recharges', recharges)}
              className="bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold px-3 py-1.5 rounded-xl transition flex items-center gap-1.5"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export CSV</span>
            </button>
          </div>

          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 uppercase font-bold text-[10px]">
                  <tr>
                    <th className="px-4 py-3">Agent</th>
                    <th className="px-4 py-3">Amount</th>
                    <th className="px-4 py-3">UTR / Reference</th>
                    <th className="px-4 py-3">Payment Time</th>
                    <th className="px-4 py-3">Notes</th>
                    <th className="px-4 py-3">Status</th>
                    <th className="px-4 py-3 text-right">Verification</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredRecharges.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="p-8 text-center text-slate-400">
                        No recharge requests found in this filter.
                      </td>
                    </tr>
                  ) : (
                    filteredRecharges.map(req => (
                      <tr key={req.id} className="hover:bg-slate-50/80">
                        <td className="px-4 py-3">
                          <div className="font-extrabold text-slate-900">{req.agentName}</div>
                          <div className="font-mono text-[10px] text-slate-500">{req.agentId} • {req.agentPhone}</div>
                        </td>
                        <td className="px-4 py-3 font-mono font-black text-slate-900 text-sm">
                          ₹{(req.amountPaise / 100).toFixed(2)}
                        </td>
                        <td className="px-4 py-3">
                          <span className="font-mono font-bold text-orange-950 bg-orange-50 px-2 py-0.5 rounded border border-orange-200">
                            {req.utrNumber}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-slate-600">
                          {new Date(req.paymentDate).toLocaleString()}
                        </td>
                        <td className="px-4 py-3 text-slate-600 max-w-xs truncate">
                          {req.notes || 'UPI Payment'}
                          {req.reviewNotes && (
                            <div className="text-[10px] text-slate-500 italic">
                              Review: {req.reviewNotes}
                            </div>
                          )}
                        </td>
                        <td className="px-4 py-3">
                          {req.status === 'approved' && (
                            <span className="bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full text-[10px] font-bold">
                              Approved
                            </span>
                          )}
                          {req.status === 'pending' && (
                            <span className="bg-amber-100 text-amber-800 px-2 py-0.5 rounded-full text-[10px] font-bold">
                              Pending Bank Check
                            </span>
                          )}
                          {req.status === 'rejected' && (
                            <span className="bg-rose-100 text-rose-800 px-2 py-0.5 rounded-full text-[10px] font-bold">
                              Rejected
                            </span>
                          )}
                        </td>
                        <td className="px-4 py-3 text-right space-x-1.5 whitespace-nowrap">
                          {req.status === 'pending' && (
                            <>
                              <button
                                onClick={() => handleReviewRecharge(req.id, 'approve')}
                                className="bg-emerald-600 hover:bg-emerald-700 text-white px-2.5 py-1 rounded-lg text-xs font-bold transition"
                              >
                                Approve & Credit
                              </button>
                              <button
                                onClick={() => setSelectedRechargeForReject(req)}
                                className="bg-rose-100 hover:bg-rose-200 text-rose-800 px-2.5 py-1 rounded-lg text-xs font-bold transition"
                              >
                                Reject
                              </button>
                            </>
                          )}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: TRANSACTION LEDGER */}
      {activeTab === 'ledger' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
            <div className="text-xs font-bold text-slate-800">
              Permanent Financial Audit Trail ({transactions.length} records)
            </div>
            <button
              onClick={() => exportToCsv('Rahim_RC_Transactions', transactions)}
              className="bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold px-3 py-1.5 rounded-xl transition flex items-center gap-1.5"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export Ledger CSV</span>
            </button>
          </div>

          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 uppercase font-bold text-[10px]">
                  <tr>
                    <th className="px-4 py-3">Txn ID</th>
                    <th className="px-4 py-3">Agent ID</th>
                    <th className="px-4 py-3">Type</th>
                    <th className="px-4 py-3">Amount</th>
                    <th className="px-4 py-3">Balance After</th>
                    <th className="px-4 py-3">Description</th>
                    <th className="px-4 py-3">Timestamp</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {transactions.map(txn => {
                    const isCredit = txn.type === 'recharge_credit' || (txn.type === 'admin_adjustment' && txn.description.includes('credit'));
                    return (
                      <tr key={txn.id} className="hover:bg-slate-50/80">
                        <td className="px-4 py-3 font-mono font-bold text-slate-900">{txn.id}</td>
                        <td className="px-4 py-3 font-mono text-slate-600">{txn.agentId}</td>
                        <td className="px-4 py-3">
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                              isCredit
                                ? 'bg-emerald-100 text-emerald-800'
                                : 'bg-orange-100 text-orange-800'
                            }`}
                          >
                            {txn.type}
                          </span>
                        </td>
                        <td className="px-4 py-3 font-mono font-bold text-sm">
                          <span className={isCredit ? 'text-emerald-700' : 'text-slate-900'}>
                            {isCredit ? '+' : '-'}₹{(txn.amountPaise / 100).toFixed(2)}
                          </span>
                        </td>
                        <td className="px-4 py-3 font-mono text-slate-600">
                          ₹{(txn.balanceAfterPaise / 100).toFixed(2)}
                        </td>
                        <td className="px-4 py-3 text-slate-700 max-w-sm truncate">
                          {txn.description}
                        </td>
                        <td className="px-4 py-3 text-slate-500">
                          {new Date(txn.createdAt).toLocaleString()}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 5: RC LOOKUP AUDIT LOGS */}
      {activeTab === 'rclogs' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
            <div className="text-xs font-bold text-slate-800">
              National Vahan Registry Requests Audit ({rcLogs.length} searches)
            </div>
            <button
              onClick={() => exportToCsv('Rahim_RC_Lookup_Audit', rcLogs)}
              className="bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold px-3 py-1.5 rounded-xl transition flex items-center gap-1.5"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export Audit CSV</span>
            </button>
          </div>

          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 uppercase font-bold text-[10px]">
                  <tr>
                    <th className="px-4 py-3">Lookup ID</th>
                    <th className="px-4 py-3">Agent ID</th>
                    <th className="px-4 py-3">Plate Number</th>
                    <th className="px-4 py-3">Charged Fee</th>
                    <th className="px-4 py-3">Status</th>
                    <th className="px-4 py-3">Vehicle / Message</th>
                    <th className="px-4 py-3">Timestamp</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {rcLogs.map(log => (
                    <tr key={log.id} className="hover:bg-slate-50/80">
                      <td className="px-4 py-3 font-mono text-slate-900 font-bold">{log.id}</td>
                      <td className="px-4 py-3 font-mono text-slate-600">{log.agentId}</td>
                      <td className="px-4 py-3 font-mono font-extrabold text-orange-950">
                        {log.registrationNumber}
                      </td>
                      <td className="px-4 py-3 font-mono font-bold">
                        ₹{(log.chargedAmountPaise / 100).toFixed(2)}
                      </td>
                      <td className="px-4 py-3">
                        {log.status === 'success' ? (
                          <span className="bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full text-[10px] font-bold">
                            SUCCESS
                          </span>
                        ) : (
                          <span className="bg-rose-100 text-rose-800 px-2 py-0.5 rounded-full text-[10px] font-bold">
                            {log.status.toUpperCase()}
                          </span>
                        )}
                      </td>
                      <td className="px-4 py-3 text-slate-700 max-w-sm truncate">
                        {log.rcData?.makerModel || log.errorMessage || 'N/A'}
                      </td>
                      <td className="px-4 py-3 text-slate-500">
                        {new Date(log.createdAt).toLocaleString()}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 6: PRICING & UPI CONFIGURATION */}
      {activeTab === 'config' && pricing && settings && (
        <form onSubmit={handleSavePricingAndSettings} className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-6">
          <div className="flex items-center gap-2 border-b border-slate-200 pb-3">
            <Settings className="w-5 h-5 text-orange-600" />
            <h3 className="font-extrabold text-slate-900 text-base">Service Pricing & UPI Gateway Settings</h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {/* RC Lookup Price */}
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                RC Lookup Price per Search (₹)
              </label>
              <input
                type="number"
                step="0.5"
                value={pricing.rcLookupPricePaise / 100}
                onChange={e =>
                  setPricing({
                    ...pricing,
                    rcLookupPricePaise: Math.round(parseFloat(e.target.value || '0') * 100)
                  })
                }
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-sm font-bold text-slate-900 focus:outline-hidden focus:border-orange-500"
              />
              <span className="text-[11px] text-slate-500 mt-1 block">
                Current: ₹{(pricing.rcLookupPricePaise / 100).toFixed(2)} ({pricing.rcLookupPricePaise} paise)
              </span>
            </div>

            {/* Minimum Recharge Amount */}
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                Minimum Recharge Amount (₹)
              </label>
              <input
                type="number"
                step="10"
                value={pricing.minimumRechargePaise / 100}
                onChange={e =>
                  setPricing({
                    ...pricing,
                    minimumRechargePaise: Math.round(parseFloat(e.target.value || '0') * 100)
                  })
                }
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-sm font-bold text-slate-900 focus:outline-hidden focus:border-orange-500"
              />
              <span className="text-[11px] text-slate-500 mt-1 block">
                Agents cannot submit recharge requests below this amount.
              </span>
            </div>

            {/* Official UPI ID */}
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                Official Business UPI ID (VPA)
              </label>
              <input
                type="text"
                value={settings.upiId}
                onChange={e => setSettings({ ...settings, upiId: e.target.value })}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-sm font-mono font-bold text-slate-900 focus:outline-hidden focus:border-orange-500"
              />
              <span className="text-[11px] text-slate-500 mt-1 block">
                Displayed to agents on QR code and copy button.
              </span>
            </div>

            {/* Payee Name */}
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                Payee / Beneficiary Name
              </label>
              <input
                type="text"
                value={settings.payeeName}
                onChange={e => setSettings({ ...settings, payeeName: e.target.value })}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-sm font-bold text-slate-900 focus:outline-hidden focus:border-orange-500"
              />
            </div>

            {/* Support Phone */}
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                Support Phone Number
              </label>
              <input
                type="text"
                value={settings.supportPhone}
                onChange={e => setSettings({ ...settings, supportPhone: e.target.value })}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs text-slate-900"
              />
            </div>

            {/* Support Email */}
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                Support Email Address
              </label>
              <input
                type="email"
                value={settings.supportEmail}
                onChange={e => setSettings({ ...settings, supportEmail: e.target.value })}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs text-slate-900"
              />
            </div>
          </div>

          {/* API Status Card */}
          <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-800">External RC Provider Adapter Status:</span>
              <span className="bg-slate-200 text-slate-800 px-2 py-0.5 rounded text-[10px] font-bold">
                {settings.isLiveApiEnabled ? 'LIVE GATEWAY' : 'DEMO SIMULATION ACTIVE'}
              </span>
            </div>
            <p className="text-xs text-slate-600">
              When external credentials (e.g. Surepass, Sandbox, or Parivahan Vahan endpoint) are configured in server environment secrets, live mode can be toggled. Currently operating safely in certified DEMO MODE.
            </p>
          </div>

          <div className="flex justify-end pt-2">
            <button
              type="submit"
              className="bg-orange-600 hover:bg-orange-700 text-white font-bold px-6 py-2.5 rounded-xl text-xs shadow-md shadow-orange-600/20 transition"
            >
              Save Pricing & Config
            </button>
          </div>
        </form>
      )}

      {/* TAB 7: WALLET REAL MODE SETUP GUIDE (WALLET_REAL_MODE_SETUP_HI.md) */}
      {activeTab === 'walletsetup' && (
        <div className="space-y-6">
          {/* Top Banner & Language Selector */}
          <div className="bg-gradient-to-r from-amber-600 via-orange-600 to-amber-700 rounded-3xl p-6 text-white shadow-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-white/20 flex items-center justify-center text-white shrink-0">
                <KeyRound className="w-6 h-6 stroke-[2.5]" />
              </div>
              <div>
                <h3 className="font-extrabold text-lg sm:text-xl leading-tight">
                  {guideLang === 'hi' ? 'वॉलेट रियल मोड सेटअप दिशानिर्देश' : 'Wallet Real Mode Setup & Reconciliation'}
                </h3>
                <p className="text-xs text-orange-100 font-medium mt-0.5">
                  {guideLang === 'hi'
                    ? 'दस्तावेज़: WALLET_REAL_MODE_SETUP_HI.md • सुरक्षा चेकलिस्ट और एपीआई प्रारूप'
                    : 'Document: WALLET_REAL_MODE_SETUP_HI.md • Production safety checklist & API payload formats'}
                </p>
              </div>
            </div>

            <div className="bg-black/20 p-1 rounded-xl flex items-center text-xs font-bold self-end sm:self-auto">
              <button
                type="button"
                onClick={() => setGuideLang('hi')}
                className={`px-3 py-1 rounded-lg transition ${
                  guideLang === 'hi' ? 'bg-white text-orange-800 shadow-sm' : 'text-white/80 hover:text-white'
                }`}
              >
                हिंदी संस्करण
              </button>
              <button
                type="button"
                onClick={() => setGuideLang('en')}
                className={`px-3 py-1 rounded-lg transition ${
                  guideLang === 'en' ? 'bg-white text-orange-800 shadow-sm' : 'text-white/80 hover:text-white'
                }`}
              >
                English Version
              </button>
            </div>
          </div>

          {/* Section 1: Strict Bank Reconciliation Directive */}
          <div className="bg-amber-50 border-2 border-amber-300 rounded-2xl p-5 shadow-xs flex items-start gap-3.5">
            <AlertTriangle className="w-6 h-6 text-amber-700 shrink-0 mt-0.5" />
            <div className="space-y-1.5 text-xs text-amber-950">
              <span className="font-extrabold text-sm block">
                {guideLang === 'hi' ? 'सख्त बैंक समाधान अनिवार्य नियम (Zero Fraud Rule)' : 'Critical Bank Reconciliation Standard'}
              </span>
              <p className="leading-relaxed">
                {guideLang === 'hi'
                  ? 'एजेंट द्वारा यूटीआर (UTR) संख्या दर्ज करना या स्क्रीनशॉट देना भुगतान का प्रमाण नहीं है। व्यवस्थापक (Admin) को अपने बैंक खाते (HDFC, SBI, ICICI आदि) में राशि जमा होने की पुष्टि करने के बाद ही आवेदन को "Approve" करना चाहिए। बिना बैंक सत्यापन के किसी भी वॉलेट में बैलेंस न जोड़ें।'
                  : 'Recharge requests are not proof of payment. An admin must verify the payment in the receiving bank account before approving a request. Never credit a wallet only because a user typed a UTR/reference number or uploaded a screenshot.'}
              </p>
            </div>
          </div>

          {/* Section 2: Endpoints Table */}
          <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs space-y-3">
            <h4 className="font-extrabold text-sm text-slate-900 flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <span>{guideLang === 'hi' ? 'सक्रिय वॉलेट एपीआई एंडपॉइंट्स (Active Wallet Endpoints)' : 'Operational Wallet Endpoints'}</span>
            </h4>
            <div className="divide-y divide-slate-100 border border-slate-200 rounded-xl overflow-hidden font-mono text-xs">
              <div className="p-3 bg-slate-50 font-sans font-bold text-slate-700 grid grid-cols-1 md:grid-cols-3 gap-2">
                <div>Endpoint</div>
                <div>Role</div>
                <div>Purpose</div>
              </div>
              <div className="p-3 grid grid-cols-1 md:grid-cols-3 gap-2 hover:bg-slate-50">
                <span className="text-emerald-700 font-bold">GET /api/agent/wallet</span>
                <span className="text-slate-600 font-sans">Agent</span>
                <span className="text-slate-700 font-sans">Current balance in paise & spent statistics</span>
              </div>
              <div className="p-3 grid grid-cols-1 md:grid-cols-3 gap-2 hover:bg-slate-50">
                <span className="text-emerald-700 font-bold">GET /api/agent/transactions</span>
                <span className="text-slate-600 font-sans">Agent</span>
                <span className="text-slate-700 font-sans">Immutable transaction ledger and lookup debits</span>
              </div>
              <div className="p-3 grid grid-cols-1 md:grid-cols-3 gap-2 hover:bg-slate-50">
                <span className="text-emerald-700 font-bold">GET /api/agent/recharges</span>
                <span className="text-slate-600 font-sans">Agent</span>
                <span className="text-slate-700 font-sans">Recent recharge requests and approval status</span>
              </div>
              <div className="p-3 grid grid-cols-1 md:grid-cols-3 gap-2 hover:bg-slate-50">
                <span className="text-blue-700 font-bold">POST /api/agent/recharge</span>
                <span className="text-slate-600 font-sans">Agent</span>
                <span className="text-slate-700 font-sans">Submits amountPaise, 12-digit UTR, date & note</span>
              </div>
              <div className="p-3 grid grid-cols-1 md:grid-cols-3 gap-2 hover:bg-slate-50">
                <span className="text-purple-700 font-bold">GET /api/admin/recharges</span>
                <span className="text-slate-600 font-sans">Admin</span>
                <span className="text-slate-700 font-sans">Admin review queue for pending/processed requests</span>
              </div>
              <div className="p-3 grid grid-cols-1 md:grid-cols-3 gap-2 hover:bg-slate-50">
                <span className="text-purple-700 font-bold">POST /api/admin/recharges/:id/review</span>
                <span className="text-slate-600 font-sans">Admin</span>
                <span className="text-slate-700 font-sans">Approves/Rejects request and atomically credits wallet</span>
              </div>
              <div className="p-3 grid grid-cols-1 md:grid-cols-3 gap-2 hover:bg-slate-50">
                <span className="text-purple-700 font-bold">POST /api/admin/agents/:id/adjust-wallet</span>
                <span className="text-slate-600 font-sans">Admin</span>
                <span className="text-slate-700 font-sans">Manual credit/debit with mandatory audit reason</span>
              </div>
            </div>
          </div>

          {/* Section 3: API Request / Response Payloads */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-slate-900 text-slate-100 rounded-2xl p-5 space-y-2.5">
              <div className="font-extrabold text-xs text-orange-400 uppercase tracking-wider flex items-center justify-between">
                <span>Agent Recharge Request</span>
                <span className="text-[10px] text-slate-400">POST /api/agent/recharge</span>
              </div>
              <pre className="font-mono text-[11px] bg-slate-950 p-3 rounded-xl overflow-x-auto text-emerald-400 border border-slate-800">
{`{
  "amountPaise": 50000,
  "utrNumber": "428712345678",
  "paymentDate": "2026-10-27T12:00:00.000Z",
  "notes": "Paid via PhonePe / GPay"
}`}
              </pre>
              <p className="text-[11px] text-slate-400">
                {guideLang === 'hi'
                  ? 'राशि पैसे (paise) में होती है। 50000 पैसे = ₹500.00। यूटीआर 12 अक्षरों का होना चाहिए।'
                  : 'Amount is strictly in paise. 50000 paise = ₹500.00. 12-digit UTR is checked for uniqueness.'}
              </p>
            </div>

            <div className="bg-slate-900 text-slate-100 rounded-2xl p-5 space-y-2.5">
              <div className="font-extrabold text-xs text-emerald-400 uppercase tracking-wider flex items-center justify-between">
                <span>Admin Approval / Rejection</span>
                <span className="text-[10px] text-slate-400">POST /api/admin/recharges/:id/review</span>
              </div>
              <pre className="font-mono text-[11px] bg-slate-950 p-3 rounded-xl overflow-x-auto text-sky-400 border border-slate-800">
{`{
  "action": "approve", // or "reject"
  "reviewNotes": "Verified in HDFC Bank NetBanking statement"
}`}
              </pre>
              <p className="text-[11px] text-slate-400">
                {guideLang === 'hi'
                  ? 'अप्रूव करने पर तुरंत एजेंट के लेजर में क्रेडिट प्रविष्टि जुड़ती है और बैलेंस अपडेट होता है।'
                  : 'Approving automatically creates an immutable audit transaction and increments agent balance.'}
              </p>
            </div>
          </div>

          {/* Section 4: Production Checklist */}
          <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs space-y-3">
            <h4 className="font-extrabold text-sm text-slate-900 flex items-center gap-2">
              <FileCheck className="w-4 h-4 text-purple-600" />
              <span>{guideLang === 'hi' ? 'असली पैसों से पूर्व 8 सुरक्षा शर्तें (Security Checklist)' : 'Pre-launch Security Safeguards'}</span>
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs text-slate-700">
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
                <span className="font-bold text-slate-900 block">1. Authentication Hardening</span>
                <p className="text-slate-600 text-[11px]">Enforce signed, expiring session tokens or HTTP-only cookies.</p>
              </div>
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
                <span className="font-bold text-slate-900 block">2. Password Security</span>
                <p className="text-slate-600 text-[11px]">Hash passwords with Argon2id or bcrypt; never store plain passwords.</p>
              </div>
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
                <span className="font-bold text-slate-900 block">3. Transactional Database Locks</span>
                <p className="text-slate-600 text-[11px]">Enforce ACID atomic balance updates so concurrent searches cannot overdraw.</p>
              </div>
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
                <span className="font-bold text-slate-900 block">4. Payment Gateway Webhooks</span>
                <p className="text-slate-600 text-[11px]">Connect server-side webhooks for automated reconciliation (Cashfree, Razorpay, PhonePe).</p>
              </div>
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
                <span className="font-bold text-slate-900 block">5. Authorized RC Data Provider</span>
                <p className="text-slate-600 text-[11px]">Set production credentials for an authorized Parivahan Vahan aggregator.</p>
              </div>
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
                <span className="font-bold text-slate-900 block">6. Settlement Reconciliation</span>
                <p className="text-slate-600 text-[11px]">Reconcile every wallet credit with the bank settlement batch.</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: ADJUST AGENT WALLET BALANCE */}
      {selectedAgentForAdjustment && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <form
            onSubmit={handleAdjustWallet}
            className="w-full max-w-md bg-white rounded-2xl shadow-2xl border border-slate-200 p-5 space-y-4"
          >
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h4 className="font-extrabold text-sm text-slate-900">
                Adjust Wallet: {selectedAgentForAdjustment.name}
              </h4>
              <button
                type="button"
                onClick={() => setSelectedAgentForAdjustment(null)}
                className="text-slate-400 hover:text-slate-600"
              >
                ×
              </button>
            </div>

            <div className="text-xs text-slate-600">
              Current balance: ₹{((selectedAgentForAdjustment.wallet?.balancePaise || 0) / 100).toFixed(2)}
            </div>

            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setAdjustIsCredit(true)}
                className={`flex-1 py-2 rounded-xl text-xs font-bold transition ${
                  adjustIsCredit ? 'bg-emerald-600 text-white' : 'bg-slate-100 text-slate-700'
                }`}
              >
                + Credit Balance
              </button>
              <button
                type="button"
                onClick={() => setAdjustIsCredit(false)}
                className={`flex-1 py-2 rounded-xl text-xs font-bold transition ${
                  !adjustIsCredit ? 'bg-rose-600 text-white' : 'bg-slate-100 text-slate-700'
                }`}
              >
                - Debit Balance
              </button>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Amount (₹)</label>
              <input
                type="number"
                step="1"
                min="1"
                value={adjustAmountRs}
                onChange={e => setAdjustAmountRs(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-sm font-bold text-slate-900"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Mandatory Audit Reason <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                required
                placeholder="e.g. Offline cash collected at desk, or bank correction"
                value={adjustReason}
                onChange={e => setAdjustReason(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs text-slate-800"
              />
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setSelectedAgentForAdjustment(null)}
                className="px-3 py-1.5 bg-slate-100 text-slate-700 rounded-lg text-xs font-bold"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isAdjusting}
                className="px-4 py-1.5 bg-orange-600 text-white rounded-lg text-xs font-bold hover:bg-orange-700 transition"
              >
                {isAdjusting ? 'Processing...' : 'Confirm Adjustment'}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* MODAL: REJECT RECHARGE */}
      {selectedRechargeForReject && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="w-full max-w-md bg-white rounded-2xl shadow-2xl border border-slate-200 p-5 space-y-4">
            <h4 className="font-extrabold text-sm text-slate-900">
              Reject Recharge Request (UTR: {selectedRechargeForReject.utrNumber})
            </h4>
            <p className="text-xs text-slate-600">
              Amount: ₹{(selectedRechargeForReject.amountPaise / 100).toFixed(2)} from {selectedRechargeForReject.agentName}
            </p>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Reason for Rejection (Visible to Agent)
              </label>
              <textarea
                value={rejectReason}
                onChange={e => setRejectReason(e.target.value)}
                rows={3}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs text-slate-900"
              />
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => setSelectedRechargeForReject(null)}
                className="px-3 py-1.5 bg-slate-100 text-slate-700 rounded-lg text-xs font-bold"
              >
                Cancel
              </button>
              <button
                onClick={() => handleReviewRecharge(selectedRechargeForReject.id, 'reject', rejectReason)}
                className="px-4 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-xs font-bold transition"
              >
                Confirm Rejection
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: RESET AGENT PASSWORD */}
      {selectedAgentForPasswordReset && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="w-full max-w-md bg-white rounded-2xl shadow-2xl border border-slate-200 p-6 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-amber-500 flex items-center justify-center text-white shadow-md">
                <KeyRound className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-extrabold text-sm text-slate-900">
                  Reset Agent Password
                </h4>
                <p className="text-xs text-slate-500">
                  {selectedAgentForPasswordReset.name} ({selectedAgentForPasswordReset.email})
                </p>
              </div>
            </div>

            <div className="bg-amber-50 border border-amber-200 rounded-xl p-3 text-xs text-amber-900 leading-relaxed">
              As an administrator, you can directly set a new temporary or permanent password for this agent account.
            </div>

            <form onSubmit={handleResetAgentPassword} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  New Password for Agent <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  minLength={6}
                  value={agentNewPassword}
                  onChange={e => setAgentNewPassword(e.target.value)}
                  placeholder="Enter new password (min 6 chars)"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-mono font-bold text-slate-900 focus:outline-hidden focus:border-orange-500"
                />
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setAgentNewPassword(`Pass@${Math.floor(1000 + Math.random() * 9000)}`)}
                  className="text-xs text-orange-600 hover:text-orange-700 font-semibold underline cursor-pointer"
                >
                  Generate Strong Password
                </button>
                <span className="text-slate-300">•</span>
                <button
                  type="button"
                  onClick={() => setAgentNewPassword('agent123')}
                  className="text-xs text-slate-600 hover:text-slate-800 font-semibold underline cursor-pointer"
                >
                  Default (agent123)
                </button>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setSelectedAgentForPasswordReset(null)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isResettingAgentPassword}
                  className="px-4 py-2 bg-orange-600 hover:bg-orange-700 text-white rounded-xl text-xs font-bold transition shadow-md shadow-orange-600/20 disabled:opacity-75 flex items-center gap-1.5 cursor-pointer"
                >
                  <KeyRound className="w-3.5 h-3.5" />
                  <span>{isResettingAgentPassword ? 'Updating...' : 'Save Agent Password'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
