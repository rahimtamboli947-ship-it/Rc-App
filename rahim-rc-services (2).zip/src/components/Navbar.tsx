import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext.js';
import {
  Shield,
  Search,
  LayoutDashboard,
  ShieldCheck,
  Globe,
  LogOut,
  HelpCircle,
  FlaskConical,
  Menu,
  X,
  Smartphone,
  CheckCircle2,
  FileText,
  UserCheck,
  Wallet,
  Plus,
  KeyRound
} from 'lucide-react';

interface NavbarProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  openRechargeModal?: () => void;
  openSearchModal: () => void;
  openSetupGuide: () => void;
  openDownloadModal?: () => void;
  openAgentLogs?: () => void;
  openAgentAuth?: () => void;
  openChangePassword?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  setCurrentTab,
  openSearchModal,
  openSetupGuide,
  openDownloadModal,
  openAgentLogs,
  openAgentAuth,
  openRechargeModal,
  openChangePassword,
}) => {
  const { user, wallet, logout, t, toggleLanguage, publicConfig } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const feeRs = ((publicConfig?.rcLookupPricePaise || 1500) / 100).toFixed(0);
  const walletRs = ((wallet?.balancePaise || 0) / 100).toFixed(2);

  return (
    <header className="sticky top-0 z-40 bg-white border-b border-orange-200/80 shadow-xs">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-orange-600 via-orange-500 to-amber-600 text-white text-xs px-3 sm:px-4 py-1.5 flex items-center justify-between font-medium">
        <div className="flex items-center gap-2 overflow-hidden text-ellipsis whitespace-nowrap">
          <span className="bg-white/20 text-white px-2 py-0.5 rounded-full text-[10px] font-bold tracking-wider uppercase">
            {publicConfig?.isLiveApiEnabled ? t.liveModeBadge : t.demoModeBadge}
          </span>
          <span className="hidden sm:inline">
            Parivahan Vahan National Registry Interface • Official Fee: ₹{feeRs} / Search
          </span>
          <span className="sm:hidden text-[11px]">
            Parivahan Vahan • ₹{feeRs} / Search
          </span>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          {/* Language Toggle Button */}
          <button
            onClick={toggleLanguage}
            className="flex items-center gap-1 bg-white/20 hover:bg-white/30 text-white px-2 py-0.5 rounded-md text-xs font-semibold transition cursor-pointer"
            title="Switch Language / भाषा बदलें"
          >
            <Globe className="w-3.5 h-3.5" />
            <span>{t.switchLanguage}</span>
          </button>
        </div>
      </div>

      {/* Main Navigation Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16 items-center">
          {/* Logo & Brand */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => setCurrentTab('dashboard')}
              className="flex items-center gap-2.5 text-left focus:outline-hidden cursor-pointer"
            >
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-orange-500 to-orange-600 flex items-center justify-center text-white shadow-md shadow-orange-500/20">
                <Shield className="w-6 h-6 stroke-[2.5]" />
              </div>
              <div>
                <span className="font-black text-lg tracking-tight text-slate-900 flex items-center gap-1.5">
                  {t.appName}
                </span>
                <span className="text-[11px] text-orange-700 block -mt-1 font-medium">
                  {t.tagline}
                </span>
              </div>
            </button>
          </div>

          {/* Desktop Navigation Links */}
          <div className="hidden md:flex items-center gap-1.5">
            <button
              onClick={() => setCurrentTab('dashboard')}
              className={`px-3.5 py-2 rounded-lg text-sm font-semibold transition flex items-center gap-1.5 cursor-pointer ${
                currentTab === 'dashboard'
                  ? 'bg-orange-50 text-orange-700 font-bold'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <LayoutDashboard className="w-4 h-4" />
              <span>{t.dashboard}</span>
            </button>

            <button
              onClick={openSearchModal}
              className="px-3.5 py-2 rounded-lg text-sm font-semibold bg-orange-50 text-orange-700 hover:bg-orange-100 transition flex items-center gap-1.5 cursor-pointer"
            >
              <Search className="w-4 h-4 text-orange-600" />
              <span>{t.rcSearch}</span>
            </button>

            {/* Dedicated Agent Log Button */}
            {openAgentLogs && (
              <button
                onClick={openAgentLogs}
                className="px-3.5 py-2 rounded-lg text-sm font-semibold text-slate-700 hover:text-orange-700 hover:bg-orange-50/70 transition flex items-center gap-1.5 border border-slate-200 cursor-pointer"
                title="View Agent RC Search & Audit Logs"
              >
                <FileText className="w-4 h-4 text-orange-600" />
                <span className="font-bold">Agent Log</span>
              </button>
            )}

            <button
              onClick={openSetupGuide}
              className="px-3 py-2 rounded-lg text-sm font-semibold text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition flex items-center gap-1.5 cursor-pointer"
            >
              <HelpCircle className="w-4 h-4 text-sky-600" />
              <span>{t.setupGuide}</span>
            </button>

            {openDownloadModal && (
              <button
                onClick={openDownloadModal}
                className="px-3 py-1.5 rounded-lg text-xs font-bold bg-amber-500 hover:bg-amber-600 text-slate-950 transition flex items-center gap-1.5 shadow-xs cursor-pointer"
              >
                <Smartphone className="w-3.5 h-3.5" />
                <span>Download App</span>
              </button>
            )}

            {/* Admin only views */}
            {user?.role === 'admin' && (
              <>
                <button
                  onClick={() => setCurrentTab('admin')}
                  className={`px-3.5 py-2 rounded-lg text-sm font-semibold transition flex items-center gap-1.5 cursor-pointer ${
                    currentTab === 'admin'
                      ? 'bg-orange-600 text-white shadow-xs'
                      : 'text-orange-700 hover:bg-orange-50'
                  }`}
                >
                  <ShieldCheck className="w-4 h-4" />
                  <span>{t.adminPanel}</span>
                </button>

                <button
                  onClick={() => setCurrentTab('tests')}
                  className={`px-3 py-2 rounded-lg text-sm font-semibold transition flex items-center gap-1.5 cursor-pointer ${
                    currentTab === 'tests'
                      ? 'bg-orange-50 text-orange-700'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                  }`}
                  title="Automated System Tests"
                >
                  <FlaskConical className="w-4 h-4 text-emerald-600" />
                  <span>Tests</span>
                </button>
              </>
            )}
          </div>

          {/* Right side items */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* If logged in as Agent: display wallet balance & quick recharge */}
            {user?.role === 'agent' && (
              <div className="flex items-center gap-2">
                <div className="bg-slate-50 border border-slate-200 px-3 py-1.5 rounded-xl flex items-center gap-2 text-xs">
                  <Wallet className="w-3.5 h-3.5 text-emerald-600" />
                  <div>
                    <span className="text-[10px] text-slate-400 block leading-none">Wallet</span>
                    <span className="font-extrabold text-slate-800">₹{walletRs}</span>
                  </div>
                  {openRechargeModal && (
                    <button
                      onClick={openRechargeModal}
                      className="ml-1 p-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-md transition cursor-pointer"
                      title="Recharge Wallet"
                    >
                      <Plus className="w-3 h-3" />
                    </button>
                  )}
                </div>

                <div className="hidden lg:block text-right">
                  <div className="text-xs font-bold text-slate-800 leading-tight">
                    {user.name}
                  </div>
                  <div className="text-[10px] text-emerald-700 font-bold uppercase tracking-wider">
                    {user.agencyName || 'Authorized Agent'}
                  </div>
                </div>

                {openChangePassword && (
                  <button
                    onClick={openChangePassword}
                    className="flex items-center gap-1 p-1.5 sm:px-2.5 sm:py-1.5 text-xs font-semibold text-slate-600 hover:text-orange-600 hover:bg-orange-50 rounded-lg transition border border-slate-200 cursor-pointer"
                    title="Change Password (पासवर्ड बदलें)"
                  >
                    <KeyRound className="w-3.5 h-3.5 text-orange-600" />
                    <span className="hidden sm:inline">Change Password</span>
                  </button>
                )}

                <button
                  onClick={logout}
                  className="p-1.5 sm:p-2 text-slate-500 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition cursor-pointer"
                  title="Log Out (लॉग आउट)"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            )}

            {user?.role === 'admin' && (
              <div className="flex items-center gap-2 pl-2 border-l border-slate-200">
                <div className="hidden lg:block text-right">
                  <div className="text-xs font-bold text-slate-800 leading-tight">
                    {user.name}
                  </div>
                  <div className="text-[10px] text-orange-700 font-bold uppercase tracking-wider">
                    Staff Administrator
                  </div>
                </div>

                {openChangePassword && (
                  <button
                    onClick={openChangePassword}
                    className="flex items-center gap-1 p-1.5 sm:px-2.5 sm:py-1.5 text-xs font-semibold text-slate-700 hover:text-orange-600 hover:bg-orange-50 rounded-lg transition border border-slate-200 cursor-pointer"
                    title="Change Admin Password (पासवर्ड बदलें)"
                  >
                    <KeyRound className="w-3.5 h-3.5 text-orange-600" />
                    <span className="hidden sm:inline">Change Password</span>
                  </button>
                )}

                <button
                  onClick={logout}
                  className="p-1.5 sm:p-2 text-slate-500 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition cursor-pointer"
                  title="Log Out (लॉग आउट)"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            )}

            {!user && (
              <div className="hidden sm:flex items-center gap-2">
                <div className="flex items-center gap-1.5 bg-emerald-50 border border-emerald-200 text-emerald-800 px-3 py-1.5 rounded-xl text-xs font-semibold">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Public Registry</span>
                </div>
              </div>
            )}

            {/* Mobile Hamburger */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg cursor-pointer"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Navigation Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-white border-b border-orange-200 px-4 pt-2 pb-4 space-y-2">
          <button
            onClick={() => {
              setCurrentTab('dashboard');
              setMobileMenuOpen(false);
            }}
            className="w-full text-left px-3 py-2.5 rounded-lg text-sm font-semibold flex items-center gap-2.5 bg-slate-50 text-slate-800 cursor-pointer"
          >
            <LayoutDashboard className="w-4 h-4 text-orange-600" />
            <span>{t.dashboard}</span>
          </button>

          <button
            onClick={() => {
              openSearchModal();
              setMobileMenuOpen(false);
            }}
            className="w-full text-left px-3 py-2.5 rounded-lg text-sm font-bold flex items-center gap-2.5 bg-orange-600 text-white shadow-xs cursor-pointer"
          >
            <Search className="w-4 h-4 text-white" />
            <span>{t.rcSearch}</span>
          </button>

          {/* Mobile Agent Log Button */}
          {openAgentLogs && (
            <button
              onClick={() => {
                openAgentLogs();
                setMobileMenuOpen(false);
              }}
              className="w-full text-left px-3 py-2.5 rounded-lg text-sm font-bold flex items-center gap-2.5 bg-orange-50 text-orange-800 border border-orange-200 cursor-pointer"
            >
              <FileText className="w-4 h-4 text-orange-600" />
              <span>Agent Log & Records</span>
            </button>
          )}


          <button
            onClick={() => {
              openSetupGuide();
              setMobileMenuOpen(false);
            }}
            className="w-full text-left px-3 py-2.5 rounded-lg text-sm font-semibold flex items-center gap-2.5 text-slate-700 hover:bg-slate-50 cursor-pointer"
          >
            <HelpCircle className="w-4 h-4 text-sky-600" />
            <span>{t.setupGuide}</span>
          </button>

          {openDownloadModal && (
            <button
              onClick={() => {
                openDownloadModal();
                setMobileMenuOpen(false);
              }}
              className="w-full text-left px-3 py-2.5 rounded-lg text-sm font-bold flex items-center gap-2.5 bg-amber-50 text-amber-900 border border-amber-200 cursor-pointer"
            >
              <Smartphone className="w-4 h-4 text-amber-700" />
              <span>Download Mobile App / Shortcut</span>
            </button>
          )}

          {user && (
            <>
              {openChangePassword && (
                <button
                  onClick={() => {
                    openChangePassword();
                    setMobileMenuOpen(false);
                  }}
                  className="w-full text-left px-3 py-2.5 rounded-lg text-sm font-semibold flex items-center gap-2.5 text-slate-800 bg-slate-50 border border-slate-200 cursor-pointer"
                >
                  <KeyRound className="w-4 h-4 text-orange-600" />
                  <span>Change Password (पासवर्ड बदलें)</span>
                </button>
              )}

              <button
                onClick={() => {
                  logout();
                  setMobileMenuOpen(false);
                }}
                className="w-full text-left px-3 py-2.5 rounded-lg text-sm font-semibold flex items-center gap-2.5 text-rose-700 bg-rose-50 cursor-pointer"
              >
                <LogOut className="w-4 h-4 text-rose-600" />
                <span>Logout (लॉग आउट)</span>
              </button>
            </>
          )}
        </div>
      )}
    </header>
  );
};
