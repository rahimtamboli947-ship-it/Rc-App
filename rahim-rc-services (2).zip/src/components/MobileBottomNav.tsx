import React from 'react';
import { useAuth } from '../context/AuthContext.js';
import { LayoutDashboard, Search, ShieldCheck, HelpCircle, Smartphone, FileText } from 'lucide-react';

interface MobileBottomNavProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  openSearchModal: () => void;
  openSetupGuide?: () => void;
  openDownloadModal?: () => void;
  openAgentLogs?: () => void;
}

export const MobileBottomNav: React.FC<MobileBottomNavProps> = ({
  currentTab,
  setCurrentTab,
  openSearchModal,
  openSetupGuide,
  openDownloadModal,
  openAgentLogs,
}) => {
  const { user, t } = useAuth();

  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-white/95 backdrop-blur-md border-t border-slate-200 z-40 py-1.5 px-2 shadow-lg">
      <div className="grid grid-cols-5 gap-1 items-center text-center">
        {/* Tab 1: Dashboard */}
        <button
          onClick={() => setCurrentTab('dashboard')}
          className={`flex flex-col items-center justify-center py-1 text-[10px] font-medium transition cursor-pointer ${
            currentTab === 'dashboard' ? 'text-orange-600 font-bold' : 'text-slate-500'
          }`}
        >
          <LayoutDashboard className="w-4 h-4 mb-0.5" />
          <span>{t.dashboard}</span>
        </button>

        {/* Tab 2: Agent Log Button */}
        <button
          onClick={openAgentLogs}
          className="flex flex-col items-center justify-center py-1 text-[10px] font-medium text-slate-600 hover:text-orange-600 transition cursor-pointer"
        >
          <FileText className="w-4 h-4 mb-0.5 text-orange-600" />
          <span className="font-bold">Agent Log</span>
        </button>

        {/* Tab 3: Prominent Search RC */}
        <button
          onClick={openSearchModal}
          className="flex flex-col items-center justify-center -mt-3.5 cursor-pointer"
        >
          <div className="w-11 h-11 rounded-full bg-gradient-to-tr from-orange-600 to-amber-500 text-white flex items-center justify-center shadow-lg shadow-orange-500/40 border-2 border-white">
            <Search className="w-5 h-5 stroke-[2.5]" />
          </div>
          <span className="text-[10px] font-bold text-orange-700 mt-0.5">
            {t.rcSearch}
          </span>
        </button>

        {/* Tab 4: Setup Guide or Admin (if logged in) */}
        {user?.role === 'admin' ? (
          <button
            onClick={() => setCurrentTab('admin')}
            className={`flex flex-col items-center justify-center py-1 text-[10px] font-medium transition cursor-pointer ${
              currentTab === 'admin' ? 'text-orange-600 font-bold' : 'text-slate-500'
            }`}
          >
            <ShieldCheck className="w-4 h-4 mb-0.5 text-orange-600" />
            <span>Admin</span>
          </button>
        ) : (
          <button
            onClick={openSetupGuide}
            className="flex flex-col items-center justify-center py-1 text-[10px] font-medium text-slate-500 hover:text-slate-900 transition cursor-pointer"
          >
            <HelpCircle className="w-4 h-4 mb-0.5 text-sky-600" />
            <span>Guide</span>
          </button>
        )}

        {/* Tab 5: Download App Shortcut */}
        <button
          onClick={openDownloadModal}
          className="flex flex-col items-center justify-center py-1 text-[10px] font-medium text-slate-500 hover:text-orange-600 transition cursor-pointer"
        >
          <Smartphone className="w-4 h-4 mb-0.5 text-amber-600" />
          <span>App</span>
        </button>
      </div>
    </nav>
  );
};
