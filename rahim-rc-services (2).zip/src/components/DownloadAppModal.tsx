import React, { useState, useEffect } from 'react';
import QRCode from 'qrcode';
import {
  Download,
  X,
  Copy,
  Check,
  Smartphone,
  ExternalLink,
  Share2,
  CheckCircle2,
  QrCode
} from 'lucide-react';

interface DownloadAppModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DownloadAppModal: React.FC<DownloadAppModalProps> = ({ isOpen, onClose }) => {
  const [copied, setCopied] = useState(false);
  const [qrUrl, setQrUrl] = useState('');
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isInstalled, setIsInstalled] = useState(false);

  const appUrl = typeof window !== 'undefined' && window.location.origin
    ? window.location.origin
    : 'https://ais-dev-m6os7o6yn4tj7tlmy7bv4l-180341379105.asia-east1.run.app';

  useEffect(() => {
    QRCode.toDataURL(appUrl, {
      width: 200,
      margin: 1,
      color: {
        dark: '#1e293b',
        light: '#ffffff'
      }
    })
      .then(url => setQrUrl(url))
      .catch(err => console.error(err));

    const handleBeforeInstall = (e: any) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstall);
    return () => window.removeEventListener('beforeinstallprompt', handleBeforeInstall);
  }, [appUrl]);

  if (!isOpen) return null;

  const handleCopy = () => {
    navigator.clipboard.writeText(appUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const [installNotice, setInstallNotice] = useState<string | null>(null);

  const handleInstallClick = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === 'accepted') {
        setIsInstalled(true);
        setDeferredPrompt(null);
      }
    } else {
      setInstallNotice(
        'On mobile Chrome: Tap the 3 dots (⋮) menu at top right, then tap "Create shortcut" (शॉर्टकट बनाएं) or "Install App". The Rahim RC icon will appear on your phone home screen!'
      );
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
      <div className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden my-auto max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="bg-gradient-to-r from-orange-600 to-amber-600 px-5 py-4 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-white/20 flex items-center justify-center text-white">
              <Smartphone className="w-5 h-5 stroke-[2.5]" />
            </div>
            <div>
              <h3 className="font-extrabold text-base leading-tight">
                Download & Install Rahim RC App
              </h3>
              <p className="text-xs text-orange-100 font-medium">
                Install directly on Android phones or open in any browser
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-white/80 hover:text-white hover:bg-white/20 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-4 text-xs sm:text-sm">
          {installNotice && (
            <div className="bg-amber-50 border border-amber-300 text-amber-900 p-3 rounded-xl text-xs font-semibold">
              {installNotice}
            </div>
          )}

          {/* Direct Link Box */}
          <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-2.5">
            <div className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center justify-between">
              <span>Your Official Live App Link:</span>
              <span className="text-emerald-700 font-semibold text-[11px] flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" /> Active & Online
              </span>
            </div>

            <div className="flex items-center gap-2">
              <input
                type="text"
                readOnly
                value={appUrl}
                className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-mono text-slate-800 focus:outline-hidden"
              />
              <button
                onClick={handleCopy}
                className="bg-orange-600 hover:bg-orange-700 text-white px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 shrink-0 shadow-xs"
              >
                {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                <span>{copied ? 'Copied!' : 'Copy'}</span>
              </button>
            </div>

            <div className="flex gap-2 pt-1">
              <a
                href={appUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1 bg-slate-900 hover:bg-slate-800 text-white py-2 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5"
              >
                <span>Open in Browser</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>

              <button
                onClick={handleInstallClick}
                className="flex-1 bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-600 text-slate-950 py-2 rounded-xl text-xs font-black transition flex items-center justify-center gap-1.5 shadow-xs"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Install on Phone</span>
              </button>
            </div>
          </div>

          {/* QR Code to Open on Phone */}
          <div className="bg-gradient-to-b from-orange-50/50 to-amber-50/50 border border-orange-200 rounded-2xl p-4 flex flex-col sm:flex-row items-center gap-4">
            <div className="bg-white p-2 rounded-xl border border-slate-200 shadow-xs shrink-0">
              {qrUrl ? (
                <img src={qrUrl} alt="App QR Code" className="w-28 h-28 rounded-lg" />
              ) : (
                <div className="w-28 h-28 bg-slate-100 flex items-center justify-center">
                  <QrCode className="w-8 h-8 text-slate-400" />
                </div>
              )}
            </div>

            <div className="space-y-1.5 text-center sm:text-left text-xs">
              <div className="font-extrabold text-slate-900 text-sm">
                Scan with Mobile Camera / Google Lens
              </div>
              <p className="text-slate-600 text-xs">
                Scan this QR code using your phone's camera, Google Lens, or Paytm to open the Rahim RC Services portal immediately on your mobile.
              </p>
            </div>
          </div>

          {/* Critical Android Installation Instructions for "This app cannot be installed" */}
          <div className="space-y-2">
            <div className="font-extrabold text-slate-900 text-xs uppercase tracking-wider flex items-center gap-1.5 text-orange-700">
              <Smartphone className="w-4 h-4 text-orange-600" />
              <span>How to Install on Android Mobile:</span>
            </div>
            <div className="bg-amber-50/80 border border-amber-300 rounded-xl p-3 space-y-2 text-xs text-slate-800">
              <div className="font-bold text-amber-950 flex items-center gap-1.5">
                <span>📱 If Chrome says &quot;This app cannot be installed&quot;:</span>
              </div>
              <p className="text-slate-700 leading-relaxed">
                In Chrome menu (three dots <strong>⋮</strong>), tap <strong>&quot;Create shortcut&quot; (शॉर्टकट बनाएं)</strong> and click <strong>&quot;Add&quot;</strong>. This creates the official Rahim RC icon right on your phone home screen, which launches full-screen in 1-tap!
              </p>
            </div>

            <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 space-y-1.5 text-xs text-slate-700">
              <div className="font-bold text-slate-900 mb-1">Standard Steps:</div>
              <div className="flex items-start gap-2">
                <span className="font-bold text-orange-600">1.</span>
                <span>Open the link in <strong>Google Chrome</strong> on your phone.</span>
              </div>
              <div className="flex items-start gap-2">
                <span className="font-bold text-orange-600">2.</span>
                <span>Tap the <strong>three dots (⋮)</strong> at top right.</span>
              </div>
              <div className="flex items-start gap-2">
                <span className="font-bold text-orange-600">3.</span>
                <span>Tap <strong>&quot;Create shortcut&quot; (शॉर्टकट बनाएं)</strong> or <strong>&quot;Install app&quot;</strong>.</span>
              </div>
            </div>

            {/* Note on Google 403 access for agents */}
            <div className="bg-blue-50 border border-blue-200 rounded-xl p-3 text-xs text-blue-900 space-y-1">
              <div className="font-bold">⚠️ If someone sees &quot;403 That&apos;s an error&quot; on another phone:</div>
              <p className="text-[11px] text-blue-800 leading-relaxed">
                The development preview URL is private to your Google account. In the AI Studio top toolbar, click <strong>&quot;Share&quot;</strong> or <strong>&quot;Deploy&quot;</strong> to generate the public link so anyone can open and register!
              </p>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="bg-slate-50 border-t border-slate-200 px-5 py-3 text-right shrink-0">
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-orange-600 hover:bg-orange-700 text-white rounded-lg text-xs font-bold transition"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
