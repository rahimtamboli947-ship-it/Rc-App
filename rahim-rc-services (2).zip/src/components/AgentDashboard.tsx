import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext.js';
import { VehicleRCData } from '../types/index.js';
import {
  Search,
  CheckCircle2,
  Car,
  FileCheck,
  Calendar,
  Sparkles,
  ShieldCheck,
  Fuel,
  Printer,
  HelpCircle,
  Phone,
  Mail,
  AlertCircle,
  Building2,
  FileText,
  KeyRound,
  Wallet
} from 'lucide-react';

interface AgentDashboardProps {
  openSearchModal: () => void;
  openRechargeModal?: () => void;
  openAuthModal?: (mode?: 'login' | 'register' | 'forgot') => void;
  openAgentLogs?: () => void;
  openChangePassword?: () => void;
  initialRCData?: VehicleRCData | null;
}

export const AgentDashboard: React.FC<AgentDashboardProps> = ({
  openSearchModal,
  openAgentLogs,
  openChangePassword,
  openRechargeModal,
  initialRCData,
}) => {
  const { user, wallet, t, publicConfig } = useAuth();
  const [quickPlate, setQuickPlate] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [searchError, setSearchError] = useState<string | null>(null);
  const [rcResult, setRcResult] = useState<VehicleRCData | null>(initialRCData || null);

  // Sync initialRCData if passed from logs
  React.useEffect(() => {
    if (initialRCData) {
      setRcResult(initialRCData);
    }
  }, [initialRCData]);

  const samplePlates = [
    { plate: 'MH12DE1433', label: 'MH 12 DE 1433 (Hero Splendor Plus)' },
    { plate: 'DL01AB1234', label: 'DL 01 AB 1234 (Maruti Dzire Taxi)' },
    { plate: 'KA05MH7788', label: 'KA 05 MH 7788 (Hyundai Creta SX)' },
    { plate: 'RJ14CP4000', label: 'RJ 14 CP 4000 (Tata Ace Gold)' },
    { plate: 'UP32AB9999', label: 'UP 32 AB 9999 (Honda Activa 6G)' }
  ];

  const handleQuickSearch = async (plateToSearch?: string) => {
    const target = (plateToSearch || quickPlate).trim().toUpperCase().replace(/[^A-Za-z0-9]/g, '');
    if (!target) {
      setSearchError('Please enter an Indian vehicle registration number (e.g. MH12DE1433)');
      return;
    }

    setIsSearching(true);
    setSearchError(null);
    setRcResult(null);

    try {
      const res = await fetch('/api/public/rc-lookup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ registrationNumber: target })
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        setSearchError(data.error || 'No vehicle record found for this registration number.');
      } else {
        setRcResult(data.rcData);
      }
    } catch (err: any) {
      setSearchError(err.message || 'Failed to connect to vehicle database.');
    } finally {
      setIsSearching(false);
    }
  };

  const feeRs = ((publicConfig?.rcLookupPricePaise || 1500) / 100).toFixed(0);

  return (
    <div className="space-y-6 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      {/* Clean Public Vehicle RC Search Box */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-sm border border-slate-200">
        <div className="max-w-3xl space-y-3">
          <div className="text-xs font-bold text-orange-700 uppercase tracking-wider flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-orange-600 inline-block animate-pulse"></span>
            <span>Parivahan Vahan National Registry Search</span>
          </div>

          {/* Quick Search Input Form */}
          <div className="bg-slate-50 p-2 sm:p-2.5 rounded-2xl border border-slate-300/80 shadow-xs flex flex-col sm:flex-row gap-2.5">
            <div className="relative flex-1">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none">
                <span className="bg-amber-400 text-slate-950 font-black text-xs px-1.5 py-0.5 rounded-xs tracking-wider">
                  IND
                </span>
              </div>
              <input
                type="text"
                value={quickPlate}
                onChange={e => setQuickPlate(e.target.value.toUpperCase())}
                onKeyDown={e => e.key === 'Enter' && handleQuickSearch()}
                placeholder="Enter Vehicle Registration (e.g. MH12DE1433)"
                className="w-full pl-14 pr-4 py-3 bg-white text-slate-900 font-mono font-bold tracking-wider rounded-xl text-sm sm:text-base border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-orange-500 uppercase placeholder:normal-case placeholder:font-sans placeholder:font-normal placeholder:tracking-normal placeholder:text-slate-400"
              />
            </div>

            <button
              onClick={() => handleQuickSearch()}
              disabled={isSearching}
              className="bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-700 hover:to-amber-700 text-white font-extrabold px-6 py-3 rounded-xl text-sm transition flex items-center justify-center gap-2 shadow-md shadow-orange-600/25 shrink-0 disabled:opacity-75 cursor-pointer"
            >
              <Search className="w-4 h-4" />
              <span>{isSearching ? 'Verifying...' : 'Verify Vehicle RC'}</span>
            </button>
          </div>

          {searchError && (
            <div className="bg-rose-50 border border-rose-200 text-rose-700 px-4 py-2.5 rounded-xl text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
              <span>{searchError}</span>
            </div>
          )}

          {/* Clickable Quick Sample Vehicles */}
          <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 pt-1">
            <span className="text-[11px] font-bold uppercase tracking-wider text-slate-600">
              Sample Vehicles:
            </span>
            {samplePlates.map(item => (
              <button
                key={item.plate}
                onClick={() => {
                  setQuickPlate(item.plate);
                  handleQuickSearch(item.plate);
                }}
                className="bg-slate-100 hover:bg-orange-50 hover:text-orange-700 hover:border-orange-200 text-slate-700 px-2.5 py-1 rounded-lg text-xs font-mono font-bold border border-slate-200 transition cursor-pointer"
              >
                {item.plate}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Verified RC Details Result Card (if searched) */}
      {rcResult && (
        <div className="bg-white rounded-3xl border border-slate-200 shadow-xl overflow-hidden animate-in fade-in duration-300">
          <div className="bg-gradient-to-r from-orange-600 to-amber-600 px-6 py-4 text-white flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center">
                <CheckCircle2 className="w-6 h-6 text-white" />
              </div>
              <div>
                <h3 className="text-lg font-black tracking-tight">{rcResult.registrationNumber}</h3>
                <p className="text-xs text-orange-100 font-medium">{rcResult.makerModel}</p>
              </div>
            </div>

            <button
              onClick={() => window.print()}
              className="bg-white/20 hover:bg-white/30 text-white px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5"
            >
              <Printer className="w-4 h-4" />
              <span>Print RC Slip</span>
            </button>
          </div>

          <div className="p-6 grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Column 1: Core Details */}
            <div className="space-y-4">
              <div className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Registration Specifications
              </div>
              <div className="bg-slate-50 rounded-2xl p-4 space-y-2.5 border border-slate-200/80">
                <div>
                  <div className="text-[11px] text-slate-500">Registered Owner</div>
                  <div className="font-bold text-slate-900 text-sm">{rcResult.maskedOwnerName || rcResult.ownerName}</div>
                </div>
                <div>
                  <div className="text-[11px] text-slate-500">Vehicle Class</div>
                  <div className="font-bold text-slate-800 text-xs">{rcResult.vehicleClass}</div>
                </div>
                <div>
                  <div className="text-[11px] text-slate-500">Fuel & Emission Norms</div>
                  <div className="font-bold text-slate-800 text-xs">{rcResult.fuelType} • {rcResult.emissionNorms}</div>
                </div>
                <div>
                  <div className="text-[11px] text-slate-500">Registration Date</div>
                  <div className="font-bold text-slate-800 text-xs">{rcResult.registrationDate}</div>
                </div>
                <div>
                  <div className="text-[11px] text-slate-500">Registering Authority (RTO)</div>
                  <div className="font-bold text-slate-800 text-xs">{rcResult.rtoName} ({rcResult.rtoState})</div>
                </div>
              </div>
            </div>

            {/* Column 2: Legal & Insurance */}
            <div className="space-y-4">
              <div className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Insurance & Compliance
              </div>
              <div className="bg-slate-50 rounded-2xl p-4 space-y-2.5 border border-slate-200/80">
                <div>
                  <div className="text-[11px] text-slate-500">Insurance Company</div>
                  <div className="font-bold text-slate-900 text-xs">{rcResult.insuranceCompany}</div>
                </div>
                <div>
                  <div className="text-[11px] text-slate-500">Insurance Valid Upto</div>
                  <div className="font-bold text-emerald-700 text-xs">{rcResult.insuranceUpto}</div>
                </div>
                <div>
                  <div className="text-[11px] text-slate-500">Fitness Valid Upto</div>
                  <div className="font-bold text-slate-800 text-xs">{rcResult.fitnessUpto}</div>
                </div>
                <div>
                  <div className="text-[11px] text-slate-500">PUCC Valid Upto</div>
                  <div className="font-bold text-slate-800 text-xs">{rcResult.puccUpto}</div>
                </div>
                <div>
                  <div className="text-[11px] text-slate-500">Road Tax Validity</div>
                  <div className="font-bold text-slate-800 text-xs">{rcResult.taxUpto}</div>
                </div>
              </div>
            </div>

            {/* Column 3: Finance & Challan */}
            <div className="space-y-4">
              <div className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Hypothecation & Security
              </div>
              <div className="bg-slate-50 rounded-2xl p-4 space-y-2.5 border border-slate-200/80">
                <div>
                  <div className="text-[11px] text-slate-500">Hypothecation (Financed)</div>
                  <div className="font-bold text-slate-900 text-xs">
                    {rcResult.isFinanced ? `Financed by ${rcResult.financingBank || 'Bank'}` : 'No Loan / Hypothecation'}
                  </div>
                </div>
                <div>
                  <div className="text-[11px] text-slate-500">Blacklist / Challan Status</div>
                  <div className="font-bold text-xs">
                    {rcResult.blacklistStatus === 'CLEAN' ? (
                      <span className="text-emerald-700">✓ Clean / No Blacklist</span>
                    ) : (
                      <span className="text-amber-700">⚠ {rcResult.blacklistStatus}</span>
                    )}
                  </div>
                </div>
                <div>
                  <div className="text-[11px] text-slate-500">Color & Seating</div>
                  <div className="font-bold text-slate-800 text-xs">{rcResult.color} • {rcResult.seatingCapacity} Seater</div>
                </div>
                <div>
                  <div className="text-[11px] text-slate-500">Engine & Chassis No</div>
                  <div className="font-mono text-[11px] text-slate-700">{rcResult.engineNumber} / {rcResult.chassisNumber}</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Feature Highlights Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
        <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-2">
          <div className="w-10 h-10 rounded-xl bg-orange-100 text-orange-700 flex items-center justify-center">
            <FileCheck className="w-5 h-5" />
          </div>
          <h3 className="font-bold text-slate-900 text-sm">Parivahan Vahan 4.0 Records</h3>
          <p className="text-xs text-slate-600 leading-relaxed">
            Instant search against the verified national register of motor vehicles across all Indian states and union territories.
          </p>
        </div>

        <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-2">
          <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <h3 className="font-bold text-slate-900 text-sm">Insurance & Fitness Validity</h3>
          <p className="text-xs text-slate-600 leading-relaxed">
            Check vehicle policy number, general insurance company, fitness certificate renewal date, and PUCC status.
          </p>
        </div>

        <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-2">
          <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-700 flex items-center justify-center">
            <Calendar className="w-5 h-5" />
          </div>
          <h3 className="font-bold text-slate-900 text-sm">Hypothecation & Challan Check</h3>
          <p className="text-xs text-slate-600 leading-relaxed">
            Verify whether the vehicle is financed under loan hypothecation and inspect pending blacklist status.
          </p>
        </div>
      </div>

      {/* Official Help & Support Card */}
      <div className="bg-gradient-to-r from-orange-50 to-amber-50 border border-orange-200 rounded-2xl p-5 shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="text-xs font-bold text-orange-950 uppercase tracking-wider">
            Authorized Vehicle Information Desk
          </div>
          <div className="text-sm font-extrabold text-slate-900">
            Need Assistance or Official Bulk Verification?
          </div>
          <div className="text-xs text-slate-600">
            Parivahan Vahan verification fee: <span className="font-bold text-emerald-700">₹{feeRs} / search</span>. Contact our dedicated support desk.
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <a
            href={`tel:${(publicConfig?.supportPhone || '+91 7387387748').replace(/\s+/g, '')}`}
            className="px-4 py-2 bg-white border border-orange-200 hover:bg-orange-50 text-slate-800 rounded-xl text-xs font-bold transition flex items-center gap-2 shadow-xs"
          >
            <Phone className="w-3.5 h-3.5 text-orange-600" />
            <span>{publicConfig?.supportPhone || '+91 7387387748'}</span>
          </a>

          {openAgentLogs && (
            <button
              onClick={openAgentLogs}
              className="px-4 py-2 bg-white border border-slate-300 hover:bg-slate-50 text-slate-800 rounded-xl text-xs font-bold transition flex items-center gap-2 shadow-xs cursor-pointer"
            >
              <FileText className="w-3.5 h-3.5 text-orange-600" />
              <span>Agent Log</span>
            </button>
          )}

          <button
            onClick={openSearchModal}
            className="px-4 py-2 bg-orange-600 hover:bg-orange-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-2 shadow-md shadow-orange-600/20 cursor-pointer"
          >
            <Search className="w-3.5 h-3.5" />
            <span>Search Vehicle RC</span>
          </button>
        </div>
      </div>
    </div>
  );
};
