export type UserRole = 'agent' | 'admin';

export type AgentStatus = 'pending_approval' | 'approved' | 'suspended';

export interface User {
  id: string;
  email: string;
  passwordHash?: string; // only stored securely on server
  name: string;
  phone: string;
  role: UserRole;
  agentId?: string; // e.g. RRC-AG-10023
  agencyName?: string;
  state?: string;
  district?: string;
  status: AgentStatus;
  createdAt: string;
  lastLoginAt?: string;
}

export interface WalletAccount {
  userId: string;
  agentId: string;
  balancePaise: number; // Balance stored in integer paise (1 INR = 100 paise)
  totalRechargedPaise: number;
  totalSpentPaise: number;
  successfulLookupsCount: number;
  updatedAt: string;
}

export type TransactionType = 'recharge_credit' | 'rc_lookup_debit' | 'admin_adjustment' | 'refund';

export type TransactionStatus = 'completed' | 'failed' | 'pending' | 'reversed';

export interface WalletTransaction {
  id: string; // TXN-YYYYMMDD-XXXXX
  userId: string;
  agentId: string;
  type: TransactionType;
  amountPaise: number;
  balanceAfterPaise: number;
  description: string;
  referenceId?: string; // UTR or Lookup ID
  status: TransactionStatus;
  createdAt: string;
}

export type RechargeStatus = 'pending' | 'approved' | 'rejected';

export interface RechargeRequest {
  id: string; // RCH-YYYYMMDD-XXXXX
  userId: string;
  agentId: string;
  agentName: string;
  agentPhone: string;
  amountPaise: number;
  utrNumber: string; // 12-digit UTR/reference number
  paymentDate: string;
  notes?: string;
  status: RechargeStatus;
  reviewedBy?: string; // admin user ID
  reviewNotes?: string;
  reviewedAt?: string;
  createdAt: string;
}

export interface VehicleRCData {
  registrationNumber: string;
  chassisNumber?: string;
  engineNumber?: string;
  ownerName: string; // e.g. "R**** T******" or full name
  maskedOwnerName: string;
  ownerSerial?: number;
  makerDescription: string;
  makerModel: string;
  vehicleClass: string;
  fuelType: string;
  emissionNorms: string;
  registrationDate: string;
  fitnessUpto: string;
  insuranceCompany: string;
  insurancePolicyNumber: string;
  insuranceUpto: string;
  taxUpto: string;
  puccUpto: string;
  financingBank?: string;
  isFinanced: boolean;
  rtoName: string;
  rtoState: string;
  color: string;
  unladenWeightKg?: number;
  grossVehicleWeightKg?: number;
  seatingCapacity?: number;
  blacklistStatus: 'CLEAN' | 'CHALLAN_PENDING' | 'BLACKLISTED';
  isCommercial: boolean;
  isDemoRecord: boolean;
}

export interface RCLookupRequest {
  id: string; // RCL-YYYYMMDD-XXXXX
  userId: string;
  agentId: string;
  registrationNumber: string;
  chassisNumberProvided?: string;
  chargedAmountPaise: number;
  status: 'success' | 'not_found' | 'error';
  errorMessage?: string;
  isDemoMode: boolean;
  rcData?: VehicleRCData;
  createdAt: string;
}

export interface ServicePricing {
  rcLookupPricePaise: number; // e.g., 500 = ₹5.00
  minimumRechargePaise: number; // e.g., 10000 = ₹100.00
  updatedAt: string;
  updatedBy: string;
}

export interface AppSettings {
  upiId: string;
  payeeName: string;
  upiNotes: string;
  isLiveApiEnabled: boolean;
  apiProviderName: string;
  apiStatusMessage: string;
  supportPhone: string;
  supportEmail: string;
}

export interface AuditLog {
  id: string;
  action: string;
  performedBy: string;
  targetId?: string;
  details: string;
  ipAddress?: string;
  createdAt: string;
}
