# RAHIM RC SERVICES — Wallet Real Mode Setup
# रहीम आरसी सर्विसेज — वॉलेट रियल मोड सेटअप गाइड

[English Version below / हिंदी संस्करण नीचे देखें]

---

## English Version

### Current Status
The project already includes these fully operational wallet endpoints:
- `GET /api/agent/wallet` — Current agent wallet balance & statistics
- `GET /api/agent/transactions` — Agent transaction ledger & history
- `GET /api/agent/recharges` — Agent recharge request history
- `POST /api/agent/recharge` — Submits a recharge request with amount, 12-digit UTR, and timestamp
- `GET /api/admin/recharges` — Admin review queue for pending/processed recharges
- `POST /api/admin/recharges/:id/review` — Admin approve or reject action
- `POST /api/admin/agents/:id/adjust-wallet` — Direct admin credit/debit adjustment with audit note

> **Critical Security Notice**: Recharge requests are **not** automatic proof of payment. An admin must verify the payment in their receiving bank account (HDFC/ICICI/SBI/Bank statement/UPI App) before approving a request. Never credit a wallet only because a user typed a UTR/reference number or uploaded a screenshot.

### Important: Pre-requisites for Real-Money Production
Do not deploy this project for real customer money until the following items are verified:
1. **Authentication Hardening**: Replace single-session tokens with signed, expiring JWTs or secure HTTP-only session cookies.
2. **Password Security**: Hash passwords with Argon2id or bcrypt; never store plain passwords.
3. **Password Reset Flow**: Implement verified single-use expiring reset tokens sent via SMS/Email OTP.
4. **Database ACID Concurrency**: Enforce atomic balance updates and transactional locks (e.g. PostgreSQL or Cloud SQL) for concurrent debits and credits.
5. **Operational Security**: Enforce HTTPS, strict rate limiting, audit logging, daily backups, RBAC role checks, and secret management.
6. **Payment Gateway Integration**: Connect an authorized Indian payment gateway (Cashfree, Razorpay, PayU, PhonePe PG) using official server-side webhooks for instant automated reconciliation. Keep API secret keys server-side only.
7. **Authorized RC Data Provider**: Connect a licensed Parivahan Vahan aggregator (Surepass, Signzy, Sandbox, IDfy).
8. **Settlement Reconciliation**: Reconcile every wallet credit with the bank settlement batch before making it spendable.

### Recharge API Examples

#### 1. Authenticated Agent Recharge Request
```http
POST /api/agent/recharge
Authorization: Bearer <session-token>
Content-Type: application/json
```
```json
{
  "amountPaise": 50000,
  "utrNumber": "428712345678",
  "paymentDate": "2026-10-27T12:00:00.000Z",
  "notes": "Recharge via PhonePe"
}
```
*Note: `amountPaise` is in paise. `50000` paise = ₹500.00.*

#### 2. Admin Review & Approval
```http
POST /api/admin/recharges/<request-id>/review
Authorization: Bearer <admin-session-token>
Content-Type: application/json
```
```json
{
  "action": "approve",
  "reviewNotes": "Verified against HDFC Bank statement. UTR matched."
}
```

#### 3. Admin Rejection (e.g., Invalid or Uncredited UTR)
```json
{
  "action": "reject",
  "reviewNotes": "UTR not received in bank account. Please check with your bank."
}
```

### Pre-Launch Testing Checklist
- [x] Set unique strong admin credentials; remove default sample accounts.
- [x] Configure production secrets via hosting provider environment variables.
- [x] Run automated test suite (`/api/test/run`) ensuring 6/6 tests pass.
- [x] Test duplicate UTR rejection (attempting to submit the same 12-digit UTR twice must fail).
- [x] Test zero-balance search block (searching without funds should prompt recharge).
- [x] Test concurrent wallet debits to prevent race conditions.

---

## हिंदी संस्करण (Hindi Version)

### वर्तमान स्थिति (Current Status)
इस प्रोजेक्ट में निम्नलिखित वॉलेट एपीआई एंडपॉइंट्स पहले से तैयार और कार्यरत हैं:
- `GET /api/agent/wallet` — एजेंट का वर्तमान वॉलेट बैलेंस और विवरण
- `GET /api/agent/transactions` — एजेंट का पूरा ट्रांजैक्शन लेजर व इतिहास
- `GET /api/agent/recharges` — एजेंट के रीचार्ज आवेदनों की सूची
- `POST /api/agent/recharge` — 12-अंकीय यूटीआर (UTR) और राशि के साथ नया रीचार्ज आवेदन
- `GET /api/admin/recharges` — व्यवस्थापक (Admin) के लिए लंबित रीचार्ज सत्यापन कतार
- `POST /api/admin/recharges/:id/review` — एडमिन द्वारा भुगतान स्वीकृत (Approve) या अस्वीकृत (Reject) करना
- `POST /api/admin/agents/:id/adjust-wallet` — एडमिन द्वारा सीधे वॉलेट क्रेडिट/डेबिट समायोजन

> **महत्वपूर्ण सुरक्षा चेतावनी**: एजेंट द्वारा यूटीआर दर्ज करना भुगतान की पुष्टि नहीं है। व्यवस्थापक को अपने बैंक खाते (नेटबैंकिंग/यूपीआई ऐप) में राशि जमा होने की पुष्टि करने के बाद ही आवेदन को स्वीकृत (Approve) करना चाहिए। बिना बैंक सत्यापन के किसी भी वॉलेट में बैलेंस न जोड़ें।

### असली पैसों (Real Money) के उपयोग से पहले जरूरी कदम
1. **सुरक्षित सत्र (Sessions/Tokens)**: टोकन को एक्सपायरी और सुरक्षित एचटीटीपी-ओनली कुकीज के साथ कॉन्फ़िगर करें।
2. **पासवर्ड एन्क्रिप्शन**: पासवर्ड को केवल सुरक्षित हैश (Bcrypt/Argon2id) में रखें।
3. **डेटाबेस व ट्रांजैक्शन**: बड़े पैमाने पर उपयोग के लिए PostgreSQL/Cloud SQL का उपयोग करें ताकि एक ही समय पर कई लेन-देन होने पर बैलेंस सुरक्षित रहे।
4. **गेटवे इंटीग्रेशन**: त्वरित ऑटो-क्रेडिट के लिए अधिकृत पेमेंट गेटवे (Cashfree / Razorpay / PhonePe) के सर्वर वेबहुक को कनेक्ट करें।
5. **अधिकृत आरसी प्रोवाइडर**: असली आरसी डेटा के लिए अधिकृत प्रोवाइडर (Surepass, Signzy, Sandbox) की लाइव एपीआई कुंजी सेट करें।

### रीचार्ज एपीआई उदाहरण (API Example)

#### 1. एजेंट रीचार्ज आवेदन (POST /api/agent/recharge)
```json
{
  "amountPaise": 50000,
  "utrNumber": "428712345678",
  "paymentDate": "2026-10-27T12:00:00.000Z",
  "notes": "PhonePe द्वारा भुगतान किया गया"
}
```
*(50000 पैसे = ₹500.00)*

#### 2. एडमिन स्वीकृति (POST /api/admin/recharges/:id/review)
```json
{
  "action": "approve",
  "reviewNotes": "बैंक खाते में राशि प्राप्त हुई और यूटीआर सत्यापित हुआ।"
}
```

### लॉन्च से पहले परीक्षण चेकलिस्ट (Testing Checklist)
1. **सिस्टम टेस्ट रन करें**: एडमिन कंसोल में स्वचालित टेस्ट चलाएं और 6/6 टेस्ट पास होने की पुष्टि करें।
2. **डुप्लीकेट यूटीआर जांच**: एक ही यूटीआर को दोबारा दर्ज करके देखें; सिस्टम इसे तुरंत अस्वीकार करना चाहिए।
3. **शून्य बैलेंस जांच**: वॉलेट में बैलेंस न होने पर आरसी सर्च ब्लॉक होना चाहिए और रीचार्ज विंडो खुलनी चाहिए।
4. **सत्यापन फ्लो**: ₹100 का टेस्ट ट्रांसफर करें, बैंक में चेक करें, और अप्रूव करके देखें कि एजेंट के वॉलेट में ₹100 तुरंत जुड़ते हैं या नहीं।
