import express, { Request, Response, NextFunction } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { dbManager } from './server/db.js';
import { rcService, DEMO_VEHICLES } from './server/rcService.js';
import { runSystemTests } from './server/testRunner.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const isProd = process.env.NODE_ENV === 'production';
const PORT = 3000;

const app = express();
app.use(express.json());

// Helper auth middleware
interface AuthenticatedRequest extends Request {
  user?: ReturnType<typeof dbManager.findUserById>;
}

const authMiddleware = (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  const authHeader = req.headers.authorization;
  if (!authHeader) {
    return res.status(401).json({ error: 'Authentication required' });
  }

  // Token is formatted as: Bearer <userId> (or standard token)
  const token = authHeader.replace(/^Bearer\s+/i, '').trim();
  const user = dbManager.findUserById(token) || dbManager.findUserByEmail(token);

  if (!user) {
    return res.status(401).json({ error: 'Invalid or expired session' });
  }

  req.user = user;
  next();
};

const adminOnly = (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  if (!req.user || req.user.role !== 'admin') {
    return res.status(403).json({ error: 'Access denied: Administrator privilege required' });
  }
  next();
};

// ---------------- PUBLIC / CONFIG ROUTES ----------------
app.get('/api/config/public', (req, res) => {
  const settings = dbManager.getSettings();
  const pricing = dbManager.getPricing();
  const apiStatus = rcService.getApiStatus();

  res.json({
    upiId: settings.upiId,
    payeeName: settings.payeeName,
    upiNotes: settings.upiNotes,
    rcLookupPricePaise: pricing.rcLookupPricePaise,
    minimumRechargePaise: pricing.minimumRechargePaise,
    supportPhone: settings.supportPhone,
    supportEmail: settings.supportEmail,
    isLiveApiEnabled: settings.isLiveApiEnabled,
    apiStatus,
    demoVehiclesAvailable: Object.keys(DEMO_VEHICLES)
  });
});

// ---------------- AUTH ROUTES ----------------
app.post('/api/auth/register', (req, res) => {
  try {
    const { email, password, name, phone, agencyName, state, district } = req.body;

    if (!email || !password || !name || !phone) {
      return res.status(400).json({ error: 'Email, password, full name, and phone are required' });
    }

    if (password.length < 6) {
      return res.status(400).json({ error: 'Password must be at least 6 characters' });
    }

    const newUser = dbManager.createUser({
      email,
      passwordHash: password, // In production use bcrypt, plain-hash in demo
      name,
      phone,
      role: 'agent',
      agencyName,
      state,
      district
    });

    const wallet = dbManager.getWallet(newUser.id);

    res.status(201).json({
      user: newUser,
      wallet,
      token: newUser.id,
      message: 'Agent registered successfully. Account is pending admin approval.'
    });
  } catch (err: any) {
    res.status(400).json({ error: err.message || 'Registration failed' });
  }
});

app.post('/api/auth/login', (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password are required' });
    }

    const user = dbManager.findUserByEmail(email);
    if (!user || user.passwordHash !== password) {
      return res.status(401).json({ error: 'Invalid email or password' });
    }

    const { passwordHash, ...safeUser } = user;
    const wallet = user.role === 'agent' ? dbManager.getWallet(user.id) : null;

    res.json({
      user: safeUser,
      wallet,
      token: user.id,
      message: 'Login successful'
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Login failed' });
  }
});

app.get('/api/auth/me', authMiddleware, (req: AuthenticatedRequest, res) => {
  const user = req.user!;
  const { passwordHash, ...safeUser } = user;
  const wallet = user.role === 'agent' ? dbManager.getWallet(user.id) : null;

  res.json({
    user: safeUser,
    wallet
  });
});

// ---------------- PASSWORD MANAGEMENT ROUTES ----------------
// 1. Forgot password - Step 1: Request reset verification code
app.post('/api/auth/forgot-password/request', (req, res) => {
  try {
    const { email } = req.body;
    if (!email || typeof email !== 'string') {
      return res.status(400).json({ error: 'Valid email address is required' });
    }
    const { code, user } = dbManager.createPasswordResetCode(email.trim());
    res.json({
      success: true,
      role: user.role,
      email: user.email,
      code, // Included in response for convenience in preview/demo environment
      message: `Verification code generated for ${user.email}: ${code}`
    });
  } catch (err: any) {
    res.status(400).json({ error: err.message || 'Failed to generate reset code' });
  }
});

// 1. Forgot password - Step 2: Verify code and set new password
app.post('/api/auth/forgot-password/reset', (req, res) => {
  try {
    const { email, code, newPassword } = req.body;
    if (!email || !code || !newPassword) {
      return res.status(400).json({ error: 'Email, verification code, and new password are required' });
    }
    if (typeof newPassword !== 'string' || newPassword.length < 6) {
      return res.status(400).json({ error: 'New password must be at least 6 characters long' });
    }
    const updatedUser = dbManager.resetPasswordWithCode(email.trim(), code.trim(), newPassword);
    res.json({
      success: true,
      role: updatedUser.role,
      message: `Password has been successfully updated for ${updatedUser.email}. You may now log in.`
    });
  } catch (err: any) {
    res.status(400).json({ error: err.message || 'Password reset failed' });
  }
});

// 2. Change password - For authenticated Agent or Admin
app.post('/api/auth/change-password', authMiddleware, (req: AuthenticatedRequest, res) => {
  try {
    const { currentPassword, newPassword } = req.body;
    if (!currentPassword || !newPassword) {
      return res.status(400).json({ error: 'Current password and new password are required' });
    }
    if (typeof newPassword !== 'string' || newPassword.length < 6) {
      return res.status(400).json({ error: 'New password must be at least 6 characters long' });
    }
    const isValid = dbManager.verifyPassword(req.user!.id, currentPassword);
    if (!isValid) {
      return res.status(401).json({ error: 'Incorrect current password. Please check and try again.' });
    }
    if (currentPassword === newPassword) {
      return res.status(400).json({ error: 'New password cannot be the same as your current password' });
    }

    dbManager.updateUserPassword(req.user!.id, newPassword);
    res.json({
      success: true,
      message: 'Your password has been changed successfully.'
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Failed to change password' });
  }
});

// Legacy reset route fallback
app.post('/api/auth/reset-password', (req, res) => {
  const { email } = req.body;
  const user = dbManager.findUserByEmail(email);
  if (!user) {
    return res.status(404).json({ error: 'Account with this email does not exist' });
  }
  user.passwordHash = user.role === 'admin' ? 'admin123' : 'agent123';
  res.json({
    message: `Password has been reset to default '${user.passwordHash}' for ${user.email}.`
  });
});

// ---------------- AGENT WALLET & RECHARGE ROUTES ----------------
app.get('/api/agent/wallet', authMiddleware, (req: AuthenticatedRequest, res) => {
  const wallet = dbManager.getWallet(req.user!.id);
  res.json({ wallet });
});

app.get('/api/agent/transactions', authMiddleware, (req: AuthenticatedRequest, res) => {
  const transactions = dbManager.getTransactions(req.user!.id);
  res.json({ transactions });
});

app.get('/api/agent/recharges', authMiddleware, (req: AuthenticatedRequest, res) => {
  const recharges = dbManager.getRechargeRequests(req.user!.id);
  res.json({ recharges });
});

app.post('/api/agent/recharge', authMiddleware, (req: AuthenticatedRequest, res) => {
  try {
    const { amountPaise, utrNumber, paymentDate, notes } = req.body;

    if (!amountPaise || typeof amountPaise !== 'number' || amountPaise <= 0) {
      return res.status(400).json({ error: 'Valid amount is required' });
    }

    if (!utrNumber || typeof utrNumber !== 'string') {
      return res.status(400).json({ error: '12-digit UPI Reference / UTR Number is required' });
    }

    const recharge = dbManager.createRechargeRequest({
      userId: req.user!.id,
      amountPaise,
      utrNumber,
      paymentDate: paymentDate || new Date().toISOString(),
      notes
    });

    res.status(201).json({
      recharge,
      message: 'Recharge request submitted successfully. Awaiting admin verification.'
    });
  } catch (err: any) {
    res.status(400).json({ error: err.message || 'Failed to submit recharge request' });
  }
});

// ---------------- VEHICLE RC SEARCH ----------------
// Public lookup for normal users (no login required)
app.post('/api/public/rc-lookup', async (req, res) => {
  const { registrationNumber, chassisNumber } = req.body;
  if (!registrationNumber || typeof registrationNumber !== 'string') {
    return res.status(400).json({ error: 'Vehicle registration number is required' });
  }

  const cleanedPlate = rcService.cleanPlate(registrationNumber);
  const lookupId = `RCL-${new Date().toISOString().slice(0, 10).replace(/-/g, '')}-${Math.floor(1000 + Math.random() * 9000)}`;

  try {
    const result = await rcService.fetchRCDetails(cleanedPlate, chassisNumber);

    if (!result.success || !result.data) {
      return res.json({
        success: false,
        notFound: result.notFound,
        invalidFormat: result.invalidFormat,
        error: result.error,
        message: 'No vehicle record found for this registration number.'
      });
    }

    // Mask owner name for public view if needed
    // Record search in database for audit logs and receipts
    dbManager.recordRCLookupRequest({
      id: lookupId,
      userId: 'public-visitor',
      agentId: 'PUBLIC',
      registrationNumber: cleanedPlate,
      chassisNumberProvided: chassisNumber,
      chargedAmountPaise: 0,
      status: 'success',
      isDemoMode: result.isDemoRecord,
      rcData: result.data,
      createdAt: new Date().toISOString()
    });

    res.json({
      success: true,
      rcData: result.data,
      lookupId,
      isDemoMode: result.isDemoRecord
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'RC lookup failed due to internal error' });
  }
});

// Endpoint to find a past search receipt or log entry by Reference ID or Plate number
app.get('/api/public/lookup-receipt/:id', (req, res) => {
  const query = req.params.id.trim().toUpperCase();
  const allRequests = dbManager.getRCLookupRequests();
  const match = allRequests.find(r =>
    r.id.toUpperCase() === query ||
    r.registrationNumber.toUpperCase() === query
  );

  if (!match) {
    const demo = DEMO_VEHICLES[query];
    if (demo) {
      return res.json({
        success: true,
        record: {
          id: `RCL-DEMO-${query}`,
          registrationNumber: query,
          status: 'success',
          chargedAmountPaise: 1500,
          rcData: demo,
          createdAt: new Date().toISOString()
        }
      });
    }
    return res.status(404).json({ success: false, error: 'No search record found for this Reference ID or Vehicle Plate.' });
  }

  res.json({ success: true, record: match });
});

app.post('/api/agent/rc-lookup', authMiddleware, async (req: AuthenticatedRequest, res) => {
  const user = req.user!;

  // 1. Enforce agent approval status
  if (user.role === 'agent' && user.status !== 'approved') {
    return res.status(403).json({
      error: user.status === 'pending_approval'
        ? 'Your agent account is pending approval by the administrator. RC lookups will be unlocked once approved.'
        : 'Your agent account is currently suspended. Please contact administrator.'
    });
  }

  const { registrationNumber, chassisNumber } = req.body;
  if (!registrationNumber || typeof registrationNumber !== 'string') {
    return res.status(400).json({ error: 'Vehicle registration number is required' });
  }

  const cleanedPlate = rcService.cleanPlate(registrationNumber);
  const pricing = dbManager.getPricing();
  const pricePaise = pricing.rcLookupPricePaise;
  const wallet = dbManager.getWallet(user.id);

  // 2. Check wallet balance before calling provider
  if (wallet.balancePaise < pricePaise) {
    return res.status(402).json({
      error: `Insufficient wallet balance. You have ₹${(wallet.balancePaise / 100).toFixed(2)}, but this search requires ₹${(pricePaise / 100).toFixed(2)}. Please recharge your wallet.`,
      currentBalancePaise: wallet.balancePaise,
      requiredPricePaise: pricePaise
    });
  }

  const lookupId = `RCL-${new Date().toISOString().slice(0, 10).replace(/-/g, '')}-${Math.floor(1000 + Math.random() * 9000)}`;

  try {
    // 3. Perform lookup via adapter
    const result = await rcService.fetchRCDetails(cleanedPlate, chassisNumber);

    // 4. Handle lookup failure: DO NOT CHARGE THE AGENT!
    if (!result.success || !result.data) {
      dbManager.recordRCLookupRequest({
        id: lookupId,
        userId: user.id,
        agentId: user.agentId || 'N/A',
        registrationNumber: cleanedPlate,
        chassisNumberProvided: chassisNumber,
        chargedAmountPaise: 0,
        status: result.notFound ? 'not_found' : 'error',
        errorMessage: result.error,
        isDemoMode: result.isDemoRecord,
        createdAt: new Date().toISOString()
      });

      return res.json({
        success: false,
        notFound: result.notFound,
        invalidFormat: result.invalidFormat,
        error: result.error,
        chargedAmountPaise: 0,
        walletBalancePaise: wallet.balancePaise,
        message: 'No charge applied for unverified or non-existent record.'
      });
    }

    // 5. Handle verified success: ATOMICALLY DEBIT exact price and log transaction
    const debitResult = dbManager.atomicDebitForRCLookup(user.id, lookupId, cleanedPlate);

    dbManager.recordRCLookupRequest({
      id: lookupId,
      userId: user.id,
      agentId: user.agentId || 'N/A',
      registrationNumber: cleanedPlate,
      chassisNumberProvided: chassisNumber,
      chargedAmountPaise: pricePaise,
      status: 'success',
      isDemoMode: result.isDemoRecord,
      rcData: result.data,
      createdAt: new Date().toISOString()
    });

    res.json({
      success: true,
      rcData: result.data,
      lookupId,
      chargedAmountPaise: pricePaise,
      newBalancePaise: debitResult.balancePaise,
      transactionId: debitResult.transaction.id,
      isDemoMode: result.isDemoRecord
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'RC lookup failed due to internal error' });
  }
});

app.get('/api/agent/rc-history', authMiddleware, (req: AuthenticatedRequest, res) => {
  const history = dbManager.getRCLookupRequests(req.user!.id);
  res.json({ history });
});

// ---------------- ADMIN PANEL ROUTES ----------------
app.get('/api/admin/stats', authMiddleware, adminOnly, (req, res) => {
  const stats = dbManager.getAdminStats();
  res.json({ stats });
});

app.get('/api/admin/agents', authMiddleware, adminOnly, (req, res) => {
  const users = dbManager.getUsers();
  const wallets = dbManager.getAllWallets();

  const agentsWithWallets = users
    .filter(u => u.role === 'agent')
    .map(agent => ({
      ...agent,
      wallet: wallets[agent.id] || {
        balancePaise: 0,
        totalRechargedPaise: 0,
        totalSpentPaise: 0,
        successfulLookupsCount: 0
      }
    }));

  res.json({ agents: agentsWithWallets });
});

app.patch('/api/admin/agents/:id/status', authMiddleware, adminOnly, (req: AuthenticatedRequest, res) => {
  try {
    const { status } = req.body;
    if (!['approved', 'pending_approval', 'suspended'].includes(status)) {
      return res.status(400).json({ error: 'Invalid agent status' });
    }

    const updated = dbManager.updateAgentStatus(req.params.id, status, req.user!.id);
    res.json({ agent: updated });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

app.post('/api/admin/agents/:id/reset-password', authMiddleware, adminOnly, (req: AuthenticatedRequest, res) => {
  try {
    const { newPassword } = req.body;
    if (!newPassword || typeof newPassword !== 'string' || newPassword.length < 6) {
      return res.status(400).json({ error: 'Password must be at least 6 characters long' });
    }
    const success = dbManager.updateUserPassword(req.params.id, newPassword);
    if (!success) {
      return res.status(404).json({ error: 'Agent not found' });
    }
    res.json({
      success: true,
      message: 'Agent password has been updated successfully.'
    });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

app.post('/api/admin/agents/:id/adjust-wallet', authMiddleware, adminOnly, (req: AuthenticatedRequest, res) => {
  try {
    const { amountPaise, isCredit, reason } = req.body;
    if (!amountPaise || amountPaise <= 0 || !reason) {
      return res.status(400).json({ error: 'Amount and audit reason are required' });
    }

    const result = dbManager.adjustWalletBalance(
      req.params.id,
      amountPaise,
      Boolean(isCredit),
      req.user!.id,
      reason
    );

    res.json({
      message: `Wallet successfully ${isCredit ? 'credited' : 'debited'} by ₹${amountPaise / 100}`,
      wallet: result.wallet,
      transaction: result.transaction
    });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

app.get('/api/admin/recharges', authMiddleware, adminOnly, (req, res) => {
  const recharges = dbManager.getRechargeRequests();
  res.json({ recharges });
});

app.post('/api/admin/recharges/:id/review', authMiddleware, adminOnly, (req: AuthenticatedRequest, res) => {
  try {
    const { action, reviewNotes } = req.body;
    if (!['approve', 'reject'].includes(action)) {
      return res.status(400).json({ error: 'Action must be approve or reject' });
    }

    const reviewed = dbManager.reviewRechargeRequest(
      req.params.id,
      action,
      req.user!.id,
      reviewNotes
    );

    res.json({
      recharge: reviewed,
      message: action === 'approve'
        ? `Recharge approved! ₹${reviewed.amountPaise / 100} credited to agent's wallet.`
        : 'Recharge request rejected.'
    });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

app.get('/api/admin/transactions', authMiddleware, adminOnly, (req, res) => {
  const transactions = dbManager.getTransactions();
  res.json({ transactions });
});

app.get('/api/admin/rc-logs', authMiddleware, adminOnly, (req, res) => {
  const logs = dbManager.getRCLookupRequests();
  res.json({ logs });
});

app.get('/api/admin/pricing', authMiddleware, adminOnly, (req, res) => {
  const pricing = dbManager.getPricing();
  res.json({ pricing });
});

app.put('/api/admin/pricing', authMiddleware, adminOnly, (req: AuthenticatedRequest, res) => {
  try {
    const { rcLookupPricePaise, minimumRechargePaise } = req.body;
    const updated = dbManager.updatePricing({
      rcLookupPricePaise: Number(rcLookupPricePaise),
      minimumRechargePaise: Number(minimumRechargePaise)
    }, req.user!.id);

    res.json({ pricing: updated, message: 'Pricing updated successfully' });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

app.put('/api/admin/settings', authMiddleware, adminOnly, (req: AuthenticatedRequest, res) => {
  try {
    const updated = dbManager.updateSettings(req.body, req.user!.id);
    res.json({ settings: updated, message: 'Settings saved successfully' });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

app.get('/api/admin/audit-logs', authMiddleware, adminOnly, (req, res) => {
  const logs = dbManager.getAuditLogs();
  res.json({ auditLogs: logs });
});

app.post('/api/admin/run-tests', authMiddleware, adminOnly, async (req, res) => {
  try {
    const testResults = await runSystemTests();
    res.json(testResults);
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Test runner failed' });
  }
});

// ---------------- VITE MIDDLEWARE (DEV) OR STATIC FILES (PROD) ----------------
async function startServer() {
  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Rahim RC Services server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch(err => {
  console.error('Failed to start server:', err);
});
